#include "stdafx.h"
#include "in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer.h"
#include "Spectrometer.h"
#include "handle.h"

/*
 * Class:     in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer
 * Method:    Initialize_jni
 * Signature: ()I
 */
JNIEXPORT jint JNICALL Java_in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer_Initialize_1jni
  (JNIEnv *env, jobject obj){
	  CSpectrometer* spectrometer = new CSpectrometer();
	  int nDevices = spectrometer->Initialize();
	  if(nDevices == 0){
		  delete spectrometer;
		  return 0;
	  }
	  setHandle(env,obj,spectrometer);
	  return nDevices;
}

/*
 * Class:     in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer
 * Method:    Uninitialize_jni
 * Signature: ()Z
 */
JNIEXPORT jboolean JNICALL Java_in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer_Uninitialize_1jni
  (JNIEnv *env, jobject obj){
	  CSpectrometer* spectrometer = getHandle<CSpectrometer>(env,obj);
	  if(spectrometer != NULL) {
		  if(spectrometer->Uninitialize()){
			delete spectrometer;
			return true;
		  }
	  }
	  return false;
}

/*
 * Class:     in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer
 * Method:    GetDeviceList_jni
 * Signature: (I)Ljava/util/List;
 */
JNIEXPORT jobject JNICALL Java_in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer_GetDeviceList_1jni
  (JNIEnv *env, jobject obj, jint nDevices){
	  CSpectrometer* spectrometer = getHandle<CSpectrometer>(env,obj);
	  if(spectrometer != NULL) {
		vector<char*> deviceList = spectrometer->GetDeviceList(nDevices);
		jclass clazz = (*env).FindClass("java/util/ArrayList");
		jobject obj = (*env).NewObject(clazz, (*env).GetMethodID(clazz, "<init>", "()V"));
		for (int n=0;n<deviceList.size();n++)
		{
			char* str = (char*) static_cast<char*>(deviceList[n]);
			jstring _str = (*env).NewStringUTF(str);
			(*env).CallVoidMethod(obj, (*env).GetMethodID(clazz, "add", "(java/lang/Object)V"), _str);
		}
		return obj; 
	  }
	  return NULL;
}

/*
 * Class:     in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer
 * Method:    Connect_jni
 * Signature: (Ljava/lang/String;)Z
 */
JNIEXPORT jboolean JNICALL Java_in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer_Connect_1jni
  (JNIEnv *env, jobject obj, jstring serial_no){
	  CSpectrometer* spectrometer = getHandle<CSpectrometer>(env,obj);
	  if(spectrometer != NULL) {
		   const char *nativeString = env->GetStringUTFChars(serial_no, 0);
		   boolean status = spectrometer->Connect(nativeString);
		   env->ReleaseStringUTFChars(serial_no, nativeString);
		   return status;
	  }
	  return false;
}

/*
 * Class:     in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer
 * Method:    Disconnect_jni
 * Signature: ()Z
 */
JNIEXPORT jboolean JNICALL Java_in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer_Disconnect_1jni
  (JNIEnv *env, jobject obj){
	  CSpectrometer* spectrometer = getHandle<CSpectrometer>(env,obj);
	  if(spectrometer != NULL) {
		  return spectrometer->Disconnect();
	  }
	  return false;
}

/*
 * Class:     in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer
 * Method:    GetNoOfPixels_jni
 * Signature: ()I
 */
JNIEXPORT jint JNICALL Java_in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer_GetNoOfPixels_1jni
  (JNIEnv *env, jobject obj){
	  CSpectrometer* spectrometer = getHandle<CSpectrometer>(env,obj);
	  if(spectrometer != NULL) {
		  return spectrometer->GetNoOfPixels();
	  }
	  return 0;
}

/*
 * Class:     in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer
 * Method:    ReadConfigFromDevice_jni
 * Signature: ()Lin/gov/barc/drhr/raman/spectaAcquire/spectrometer/CMeasurementSettings;
 */
JNIEXPORT jobject JNICALL Java_in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer_ReadConfigFromDevice_1jni
  (JNIEnv *env, jobject obj){
	  CSpectrometer* spectrometer = getHandle<CSpectrometer>(env,obj);
	  if(spectrometer != NULL) {
		  CMeasurementSettings* measurementSettings = spectrometer->ReadConfigFromDevice();
		  if(measurementSettings != NULL) {
				jclass settingsClass = env->FindClass("in/gov/barc/drhr/raman/spectaAcquire/spectrometer/CMeasurementSettings");
				if (settingsClass == NULL) {
					return NULL;
				}
				jclass settingsGlobalClass = reinterpret_cast<jclass>(env->NewGlobalRef(settingsClass));
				// info: last argument is Java method signature
				jmethodID settingsConstructor = env->GetMethodID(settingsGlobalClass, "<init>", "");
				if (settingsConstructor == NULL) {
					return NULL;
				}
				jobject settingsObject = env->NewObject(settingsGlobalClass, settingsConstructor, true);
				jmethodID method  = env->GetMethodID( settingsGlobalClass, "setStartPixel", "(I)V");
				env->CallVoidMethod(settingsObject, method, measurementSettings->startPixel());
				method = env->GetMethodID( settingsGlobalClass, "setStopPixel", "(I)V");
				env->CallVoidMethod(settingsObject, method, measurementSettings->stopPixel());
				method = env->GetMethodID( settingsGlobalClass, "setIntegrationTime", "(D)V");
				env->CallVoidMethod(settingsObject, method, measurementSettings->integrationTime());
				method = env->GetMethodID( settingsGlobalClass, "setIntegrationDelay", "(D)V");
				env->CallVoidMethod(settingsObject, method, measurementSettings->integrationDelay());
				method = env->GetMethodID( settingsGlobalClass, "setNrAverages", "(I)V");
				env->CallVoidMethod(settingsObject, method, measurementSettings->nrAverages());
				method = env->GetMethodID( settingsGlobalClass, "setSaturationDetection", "(I)V");
				env->CallVoidMethod(settingsObject, method, measurementSettings->saturationDetection());
				method = env->GetMethodID( settingsGlobalClass, "setCorDynDark", "(D)V");
				env->CallVoidMethod(settingsObject, method, measurementSettings->corDynDark());
				method = env->GetMethodID( settingsGlobalClass, "setSmoothPix", "(I)V");
				env->CallVoidMethod(settingsObject, method, measurementSettings->smoothPix());
				method = env->GetMethodID( settingsGlobalClass, "setSmoothModel", "(I)V");
				env->CallVoidMethod(settingsObject, method, measurementSettings->smoothModel());
				//laser settings
				method = env->GetMethodID( settingsGlobalClass, "setLaserDelay", "(D)V");
				env->CallVoidMethod(settingsObject, method, measurementSettings->laserDelay());
				method = env->GetMethodID( settingsGlobalClass, "setLaserWidth", "(I)V");
				env->CallVoidMethod(settingsObject, method, measurementSettings->laserWidth());
				method = env->GetMethodID( settingsGlobalClass, "setLaserWaveLength", "(I)V");
				env->CallVoidMethod(settingsObject, method, measurementSettings->laserWaveLength());
				//
				method = env->GetMethodID( settingsGlobalClass, "setNrScans", "(I)V");
				env->CallVoidMethod(settingsObject, method, measurementSettings->nrScans());
				delete measurementSettings;
				return settingsObject;
		  }
	  }
	  return NULL;
}

/*
 * Class:     in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer
 * Method:    WriteConfigToDevice_jni
 * Signature: (Lin/gov/barc/drhr/raman/spectaAcquire/spectrometer/CMeasurementSettings;)I
 */
JNIEXPORT jint JNICALL Java_in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer_WriteConfigToDevice_1jni
  (JNIEnv *env, jobject obj, jobject settings){
	  CSpectrometer* spectrometer = getHandle<CSpectrometer>(env,obj);
	  if(spectrometer != NULL) {
		  CMeasurementSettings* measurementSettings = new CMeasurementSettings();
			/* Get a reference to obj's class */
			jclass cls = env->GetObjectClass(obj);
			jclass settingsGlobalClass = reinterpret_cast<jclass>(env->NewGlobalRef(cls));
			jmethodID method  = env->GetMethodID( settingsGlobalClass, "startPixel", "(V)I");
			measurementSettings->setStartPixel(env->CallIntMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "stopPixel", "(V)I");
			measurementSettings->setStopPixel(env->CallIntMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "integrationTime", "(V)D");
			measurementSettings->setIntegrationTime(env->CallDoubleMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "integrationDelay", "(V)D");
			measurementSettings->setIntegrationDelay(env->CallDoubleMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "nrAverages", "(V)I");
			measurementSettings->setNrAverages(env->CallIntMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "saturationDetection", "(V)I");
			measurementSettings->setSaturationDetection(env->CallIntMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "corDynDark", "(V)B");
			measurementSettings->setCorDynDark(env->CallBooleanMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "smoothPix", "(V)I");
			measurementSettings->setSaturationDetection(env->CallIntMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "smoothModel", "(V)I");
			measurementSettings->setSmoothModel(env->CallIntMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "laserDelay", "(V)D");
			measurementSettings->setLaserDelay(env->CallDoubleMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "laserWidth", "(V)I");
			measurementSettings->setLaserWidth(env->CallIntMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "laserWaveLength", "(V)D");
			measurementSettings->setLaserWaveLength(env->CallDoubleMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "nrScans", "(V)I");
			measurementSettings->setNrScans(env->CallIntMethod(settings, method));
			int status = spectrometer->WriteConfigToDevice(measurementSettings);
			delete measurementSettings;
			return status;
	  }
	  return NULL;
}

/*
 * Class:     in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer
 * Method:    IsDataAvailable_jni
 * Signature: ()Z
 */
JNIEXPORT jboolean JNICALL Java_in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer_IsDataAvailable_1jni
  (JNIEnv *env, jobject obj){
	  CSpectrometer* spectrometer = getHandle<CSpectrometer>(env,obj);
	  if(spectrometer != NULL) {
		  return spectrometer->IsDataAvailable();
	  }
	  return false;
}

/*
 * Class:     in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer
 * Method:    PrepareMeasure_jni
 * Signature: (Lin/gov/barc/drhr/raman/spectaAcquire/spectrometer/CMeasurementSettings;)Z
 */
JNIEXPORT jboolean JNICALL Java_in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer_PrepareMeasure_1jni
  (JNIEnv *env, jobject obj, jobject settings){
	  CSpectrometer* spectrometer = getHandle<CSpectrometer>(env,obj);
	  if(spectrometer != NULL) {
		  CMeasurementSettings* measurementSettings = new CMeasurementSettings();
			/* Get a reference to obj's class */
			jclass cls = env->GetObjectClass(obj);
			jclass settingsGlobalClass = reinterpret_cast<jclass>(env->NewGlobalRef(cls));
			jmethodID method  = env->GetMethodID( settingsGlobalClass, "startPixel", "(V)I");
			measurementSettings->setStartPixel(env->CallIntMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "stopPixel", "(V)I");
			measurementSettings->setStopPixel(env->CallIntMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "integrationTime", "(V)D");
			measurementSettings->setIntegrationTime(env->CallDoubleMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "integrationDelay", "(V)D");
			measurementSettings->setIntegrationDelay(env->CallDoubleMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "nrAverages", "(V)I");
			measurementSettings->setNrAverages(env->CallIntMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "saturationDetection", "(V)I");
			measurementSettings->setSaturationDetection(env->CallIntMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "corDynDark", "(V)B");
			measurementSettings->setCorDynDark(env->CallBooleanMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "smoothPix", "(V)I");
			measurementSettings->setSaturationDetection(env->CallIntMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "smoothModel", "(V)I");
			measurementSettings->setSmoothModel(env->CallIntMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "laserDelay", "(V)D");
			measurementSettings->setLaserDelay(env->CallDoubleMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "laserWidth", "(V)I");
			measurementSettings->setLaserWidth(env->CallIntMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "laserWaveLength", "(V)D");
			measurementSettings->setLaserWaveLength(env->CallDoubleMethod(settings, method));
			method  = env->GetMethodID( settingsGlobalClass, "nrScans", "(V)I");
			measurementSettings->setNrScans(env->CallIntMethod(settings, method));
			boolean status = spectrometer->PrepareMeasure(measurementSettings);
			delete measurementSettings;
		  return status;
	  }
	  return false;
}

/*
 * Class:     in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer
 * Method:    GetWavellength_jni
 * Signature: ()[D
 */
JNIEXPORT jdoubleArray JNICALL Java_in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer_GetWavellength_1jni
  (JNIEnv *env, jobject obj){
	  CSpectrometer* spectrometer = getHandle<CSpectrometer>(env,obj);
	  if(spectrometer != NULL) {
		  int pixels = spectrometer->GetNoOfPixels();
		  if(pixels > 0){
			  double* wavelength = new double[pixels];
			  if(spectrometer->GetWavellength(wavelength)){
				  jdoubleArray wavelengthArray = env->NewDoubleArray(pixels);
				  env->SetDoubleArrayRegion(wavelengthArray, 0, pixels,(const jdouble*)wavelength);
				  delete wavelength;
				  return wavelengthArray;
			  }
		  }
	  }
	  return NULL;
}

/*
 * Class:     in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer
 * Method:    GetSpectrumData_jni
 * Signature: ([I)[D
 */
JNIEXPORT jdoubleArray JNICALL Java_in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer_GetSpectrumData_1jni
  (JNIEnv *env, jobject obj){
	   CSpectrometer* spectrometer = getHandle<CSpectrometer>(env,obj);
	  if(spectrometer != NULL) {
		  int pixels = spectrometer->GetNoOfPixels();
		  if(pixels > 0){
			  double* specData = new double[pixels];
			  unsigned int lastPixel = 0;
			  if(spectrometer->GetSpectrumData(&lastPixel, specData)){
				  jdoubleArray spectrumArray = env->NewDoubleArray(pixels);
				  env->SetDoubleArrayRegion(spectrumArray, 0, pixels,(const jdouble*)specData);
				  delete specData;
				  return spectrumArray;
			  }
		  }
	  }
	  return NULL;
}

/*
 * Class:     in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer
 * Method:    StopMeasure_jni
 * Signature: ()Z
 */
JNIEXPORT jboolean JNICALL Java_in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer_StopMeasure_1jni
  (JNIEnv *env, jobject obj){
	   CSpectrometer* spectrometer = getHandle<CSpectrometer>(env,obj);
	  if(spectrometer != NULL) {
		  return spectrometer->StopMeasure();
	  }
	  return false;
}

/*
 * Class:     in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer
 * Method:    GetSaturatedPixels_jni
 * Signature: ()[C
 */
JNIEXPORT jcharArray JNICALL Java_in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer_GetSaturatedPixels_1jni
  (JNIEnv *env, jobject obj){
	  CSpectrometer* spectrometer = getHandle<CSpectrometer>(env,obj);
	  if(spectrometer != NULL) {
		  unsigned char* saturatedPixels = spectrometer->GetSaturatedPixels();
		  if(saturatedPixels != NULL){
			  int pixels = spectrometer->GetNoOfPixels();
			  jcharArray saturatedArray = env->NewCharArray(pixels);
			  env->SetCharArrayRegion(saturatedArray, 0, pixels,(const jchar*)saturatedPixels);
			  delete saturatedPixels;
			  return saturatedArray;
		  }
	  }
	  return NULL;
}

/*
 * Class:     in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer
 * Method:    getDetectorParams_jni
 * Signature: ()Lin/gov/barc/drhr/raman/spectaAcquire/spectrometer/DetectorType;
 */
JNIEXPORT jobject JNICALL Java_in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer_getDetectorParams_1jni
  (JNIEnv *env, jobject obj){
	  CSpectrometer* spectrometer = getHandle<CSpectrometer>(env,obj);
	  if(spectrometer != NULL) {
		  jclass settingsClass = env->FindClass("in/gov/barc/drhr/raman/spectaAcquire/spectrometer/DetectorType");
			if (settingsClass == NULL) {
				return NULL;
			}
			jclass settingsGlobalClass = reinterpret_cast<jclass>(env->NewGlobalRef(settingsClass));
			// info: last argument is Java method signature
			jmethodID settingsConstructor = env->GetMethodID(settingsGlobalClass, "<init>", "");
			if (settingsConstructor == NULL) {
				return NULL;
			}
			jobject settingsObject = env->NewObject(settingsGlobalClass, settingsConstructor, true);
			jmethodID setSensorTypeMethod  = env->GetMethodID( settingsGlobalClass, "setSensorType", "(Ljava/lang/String;)V");
			jmethodID setNrPixelsMethod = env->GetMethodID( settingsGlobalClass, "setNrPixels", "(I)V");
			string deviceInfo = spectrometer->GetDeviceInfo();
			env->CallVoidMethod(settingsObject, setSensorTypeMethod, (env)->NewStringUTF(deviceInfo.c_str()));
			env->CallVoidMethod(settingsObject, setNrPixelsMethod, spectrometer->GetDeviceNrPixels());
			return settingsObject;
	  }
	  return NULL;
}

/*
 * Class:     in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer
 * Method:    getLastError_jni
 * Signature: ()Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL Java_in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer_getLastError_1jni
  (JNIEnv *env, jobject obj){
	  CSpectrometer* spectrometer = getHandle<CSpectrometer>(env,obj);
	  if(spectrometer != NULL) {
		  return (env)->NewStringUTF(spectrometer->GetLastErr().c_str());
	  }
	  return (env)->NewStringUTF("");
}

/*
 * Class:     in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer
 * Method:    LaserOnOff_jni
 * Signature: (Ljava/lang/Boolean;)Z
 */
JNIEXPORT jboolean JNICALL Java_in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer_LaserOnOff_1jni
  (JNIEnv *env, jobject obj, jboolean isOff){
	   CSpectrometer* spectrometer = getHandle<CSpectrometer>(env,obj);
	  if(spectrometer != NULL) {
		  return spectrometer->LaserOnOff(isOff);
	  }
	  return false;
}

/*
 * Class:     in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer
 * Method:    InitializeLaser_jni
 * Signature: ()Z
 */
JNIEXPORT jboolean JNICALL Java_in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer_InitializeLaser_1jni
  (JNIEnv *env, jobject obj){
	   CSpectrometer* spectrometer = getHandle<CSpectrometer>(env,obj);
	  if(spectrometer != NULL) {
		  return spectrometer->InitializeLaserScan();
	  }
	  return false;
}

/*
 * Class:     in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer
 * Method:    SetLaserPower_jni
 * Signature: ([I)[Z
 */
JNIEXPORT jboolean JNICALL Java_in_gov_barc_drhr_raman_spectaAcquire_spectrometer_AvantesSpectrometer_SetLaserPower_1jni
	(JNIEnv *env, jobject obj, jint percent){
		 CSpectrometer* spectrometer = getHandle<CSpectrometer>(env,obj);
	  if(spectrometer != NULL) {
		  return spectrometer->SetLaserPower(percent);
	  }
	  return false;
}