#include "stdafx.h"
#include "Spectrometer.h"


CSpectrometer::CSpectrometer(void)
{
	m_deviceHandle = NULL;
	connectedDevices = NULL;
	nConnectedDevices = 0;
	lastErr = "";
}


CSpectrometer::~CSpectrometer(void)
{
	if(m_deviceHandle != NULL) {
		Disconnect();
	}
	m_deviceHandle = NULL;
}

int CSpectrometer::Initialize() {
	 int nDevices = AVS_Init(0);   //use only USB port
	 if(nDevices < 0) {
		lastErr = MapErrorToString(nDevices);
		return 0;
	 }
	 return nDevices; //no of devices connected
}

boolean CSpectrometer::Uninitialize() {
	int status = AVS_Done();
	if(status == 0) {
		return true;
	}
	lastErr = MapErrorToString(status);
	return false;
}

vector<char*> CSpectrometer::GetDeviceList(int nDevices) {
	unsigned int a_ListSize = nDevices * sizeof(AvsIdentityType);
	unsigned int a_pRequiredSize = 0;
	nDevices = AVS_GetList(a_ListSize, &a_pRequiredSize, NULL);
	if(connectedDevices != NULL) {
		delete connectedDevices;
	}
	connectedDevices = new AvsIdentityType[a_pRequiredSize];
	nConnectedDevices = AVS_GetList(a_ListSize, &a_pRequiredSize, NULL);
	vector<char*> serialNos;
	if(nDevices > 0) {
		for(int i=0;i<nDevices;i++) {
			serialNos.push_back(connectedDevices[i].SerialNumber);
		}
	}
	return serialNos;
}

AvsIdentityType* CSpectrometer::GetDeviceBySerialNo(const char* serialNo) {
	for(int i=0;i<nConnectedDevices;i++) {
		AvsIdentityType device = connectedDevices[i];
		if(strcmp(device.SerialNumber, serialNo)) {
			return &device;
		}
	}
	return NULL;
}

MeasConfigType* CSpectrometer::ConfigureMeasType(CMeasurementSettings* measureSettings) {
	MeasConfigType* l_PrepareMeasData = new MeasConfigType() ;
	l_PrepareMeasData->m_StartPixel = measureSettings->startPixel();
	l_PrepareMeasData->m_StopPixel =  measureSettings->stopPixel();
	l_PrepareMeasData->m_IntegrationTime = measureSettings->integrationTime();
	double l_NanoSec = measureSettings->integrationDelay();
	unsigned int l_FPGAClkCycles = (unsigned int)(6.0*(l_NanoSec+20.84)/125.0);
	l_PrepareMeasData->m_IntegrationDelay = l_FPGAClkCycles;
	l_PrepareMeasData->m_NrAverages = measureSettings->nrAverages();
	l_PrepareMeasData->m_Trigger.m_Mode = measureSettings->trigger_mode();
	l_PrepareMeasData->m_Trigger.m_Source = measureSettings->trigger_source();
	l_PrepareMeasData->m_Trigger.m_SourceType = measureSettings->trigger_sourceType();
	l_PrepareMeasData->m_SaturationDetection = measureSettings->saturationDetection();
	l_PrepareMeasData->m_CorDynDark.m_Enable = measureSettings->corDynDark();
	l_PrepareMeasData->m_CorDynDark.m_ForgetPercentage = measureSettings->forgetPercentage();
	l_PrepareMeasData->m_Smoothing.m_SmoothPix = measureSettings->smoothPix();
	l_PrepareMeasData->m_Smoothing.m_SmoothModel = measureSettings->smoothModel();
	l_PrepareMeasData->m_Control.m_StrobeControl = measureSettings->strobeControl();
	l_NanoSec = measureSettings->laserDelay();
	l_FPGAClkCycles = (unsigned int)(6.0*l_NanoSec/125.0);
	l_PrepareMeasData->m_Control.m_LaserDelay = l_FPGAClkCycles;
	l_NanoSec = measureSettings->laserWidth();
	l_FPGAClkCycles = (unsigned int)(6.0*l_NanoSec/125.0);
	l_PrepareMeasData->m_Control.m_LaserWidth = l_FPGAClkCycles;
	l_PrepareMeasData->m_Control.m_LaserWaveLength = measureSettings->laserWaveLength();
	l_PrepareMeasData->m_Control.m_StoreToRam = measureSettings->storeToRam();
	return l_PrepareMeasData;
}

boolean CSpectrometer::Connect(const char* serialNo) {
	AvsIdentityType* device = GetDeviceBySerialNo(serialNo);
	if(device != NULL) {
		int handle = AVS_Activate(device);
		if(handle == INVALID_AVS_HANDLE_VALUE) {
			lastErr = "Invalid handle";
			return false;
		}
		m_deviceHandle = handle;
		return true;
	}
	return false;
}

boolean CSpectrometer::Disconnect() {
	if(m_deviceHandle != NULL) {
		return AVS_Deactivate(m_deviceHandle);
	}
	return true;
}

boolean CSpectrometer::GetTriggerStatus() {
	unsigned char* a_pDigIn = 0;
	int status = AVS_GetDigIn(m_deviceHandle, 2, a_pDigIn);
	if(status != 0) {
		lastErr = MapErrorToString(status);
	}
	clock_t startTime = clock();
	while(startTime - clock() < 5000) {   //for 5 secs
		if(a_pDigIn) {
			return true;
		}
	}
	return false;
}

boolean CSpectrometer::SetTriggerMode(boolean isHardware, boolean isSync, boolean isLevelTrigger){
	DeviceConfigType*  l_pDeviceData = NULL;
    unsigned int       l_Size;

	int l_Res = AVS_GetParameter(m_deviceHandle, 0, &l_Size, l_pDeviceData);

    if ( l_Res == ERR_INVALID_SIZE)
    {
        l_pDeviceData = (DeviceConfigType*)new char[l_Size];
    }
	l_Res = AVS_GetParameter(m_deviceHandle, l_Size, &l_Size, l_pDeviceData);
    if (ERR_SUCCESS != l_Res)
    {
        delete [] l_pDeviceData;
        return l_Res;
    }
    //Get measurement parameters from main window
    l_pDeviceData->m_StandAlone.m_Meas.m_Trigger.m_Mode = isHardware;
    l_pDeviceData->m_StandAlone.m_Meas.m_Trigger.m_Source = isSync;
    l_pDeviceData->m_StandAlone.m_Meas.m_Trigger.m_SourceType = isLevelTrigger;
/*  
	l_NanoSec = l_pDeviceConfig->laserDelay();
    l_FPGAClkCycles = (unsigned int)(6.0*l_NanoSec/125.0);
    l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_LaserDelay = l_FPGAClkCycles;
    l_NanoSec = l_pDeviceConfig->laserWidth();
    l_FPGAClkCycles = (unsigned int)(6.0*l_NanoSec/125.0);
    l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_LaserWidth = l_FPGAClkCycles;
    l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_LaserWaveLength = l_pDeviceConfig->laserWaveLength();
    l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_StoreToRam = l_pDeviceConfig->storeToRam();
    l_pDeviceData->m_StandAlone.m_Nmsr =  l_pDeviceConfig->nrScans(); 

*/
    //Write measurement parameters
	l_Res = AVS_SetParameter(m_deviceHandle, l_pDeviceData);
    delete [] l_pDeviceData;
    return l_Res;
}

boolean CSpectrometer::GetTriggerMode() {
	DeviceConfigType*  l_pDeviceData = NULL;
    unsigned int       l_Size;

	int l_Res = AVS_GetParameter(m_deviceHandle, 0, &l_Size, l_pDeviceData);

    if ( l_Res == ERR_INVALID_SIZE)
    {
        l_pDeviceData = (DeviceConfigType*)new char[l_Size];
    }
	l_Res = AVS_GetParameter(m_deviceHandle, l_Size, &l_Size, l_pDeviceData);
    if (ERR_SUCCESS != l_Res)
    {
        delete [] l_pDeviceData;
        return l_Res;
    }
	boolean m_mode = l_pDeviceData->m_StandAlone.m_Meas.m_Trigger.m_Mode;
	delete [] l_pDeviceData;
    return m_mode;
}

boolean CSpectrometer::PrepareMeasure(CMeasurementSettings* settings) {
	MeasConfigType* l_PrepareMeasData = ConfigureMeasType(settings);
	int status = AVS_PrepareMeasure(m_deviceHandle, l_PrepareMeasData);
	if(status != 0){
		lastErr = MapErrorToString(status);
		return false;
	}
	return true;
}

CMeasurementSettings* CSpectrometer::ReadConfigFromDevice() {
	CMeasurementSettings* l_pDeviceConfig = new CMeasurementSettings();
    DeviceConfigType*  l_pDeviceData = NULL;
    unsigned int       l_Size;
	int l_Res = AVS_GetParameter(m_deviceHandle, 0, &l_Size, l_pDeviceData);

    if ( l_Res == ERR_INVALID_SIZE)
    {
        l_pDeviceData = (DeviceConfigType*)new char[l_Size];
    }
	l_Res = AVS_GetParameter(m_deviceHandle, l_Size, &l_Size, l_pDeviceData);
    if (ERR_SUCCESS != l_Res)
    {
        delete [] l_pDeviceData;
        return NULL;
    }
    //show measurement settings
    l_pDeviceConfig->setStartPixel(l_pDeviceData->m_StandAlone.m_Meas.m_StartPixel);
    l_pDeviceConfig->setStopPixel(l_pDeviceData->m_StandAlone.m_Meas.m_StopPixel);
    l_pDeviceConfig->setIntegrationTime(l_pDeviceData->m_StandAlone.m_Meas.m_IntegrationTime);
    unsigned int l_FPGAClkCycles = l_pDeviceData->m_StandAlone.m_Meas.m_IntegrationDelay;
    double l_NanoSec = 125.0*(l_FPGAClkCycles-1.0)/6.0;
    l_pDeviceConfig->setIntegrationDelay(l_NanoSec);
    l_pDeviceConfig->setNrAverages(l_pDeviceData->m_StandAlone.m_Meas.m_NrAverages);
    l_pDeviceConfig->setSaturationDetection(l_pDeviceData->m_StandAlone.m_Meas.m_SaturationDetection);
    l_pDeviceConfig->setTrigger_mode(l_pDeviceData->m_StandAlone.m_Meas.m_Trigger.m_Mode);
    l_pDeviceConfig->setTrigger_source(l_pDeviceData->m_StandAlone.m_Meas.m_Trigger.m_Source);
    l_pDeviceConfig->setTrigger_source(l_pDeviceData->m_StandAlone.m_Meas.m_Trigger.m_SourceType);
    l_pDeviceConfig->setCorDynDark(l_pDeviceData->m_StandAlone.m_Meas.m_CorDynDark.m_Enable == 1);
    l_pDeviceConfig->setForgetPercentage(l_pDeviceData->m_StandAlone.m_Meas.m_CorDynDark.m_ForgetPercentage);
    l_pDeviceConfig->setSmoothModel(l_pDeviceData->m_StandAlone.m_Meas.m_Smoothing.m_SmoothModel);
    l_pDeviceConfig->setSmoothPix(l_pDeviceData->m_StandAlone.m_Meas.m_Smoothing.m_SmoothPix);
    l_pDeviceConfig->setStrobeControl(l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_StrobeControl);
    l_FPGAClkCycles = l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_LaserDelay;
    l_NanoSec = 125.0*(l_FPGAClkCycles)/6.0;
    l_pDeviceConfig->setLaserDelay(l_NanoSec);
    l_FPGAClkCycles = l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_LaserWidth;
    l_NanoSec = 125.0*(l_FPGAClkCycles)/6.0;
    l_pDeviceConfig->setLaserWidth(l_NanoSec);
    l_pDeviceConfig->setLaserWaveLength(l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_LaserWaveLength);
    l_pDeviceConfig->setStoreToRam(l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_StoreToRam);
    l_pDeviceConfig->setNrScans(l_pDeviceData->m_StandAlone.m_Nmsr);
    delete [] l_pDeviceData;
    return l_pDeviceConfig;
}

int CSpectrometer::WriteConfigToDevice(CMeasurementSettings *l_pDeviceConfig){
    DeviceConfigType*  l_pDeviceData = NULL;
    unsigned int       l_Size;

	int l_Res = AVS_GetParameter(m_deviceHandle, 0, &l_Size, l_pDeviceData);

    if ( l_Res == ERR_INVALID_SIZE)
    {
        l_pDeviceData = (DeviceConfigType*)new char[l_Size];
    }
	l_Res = AVS_GetParameter(m_deviceHandle, l_Size, &l_Size, l_pDeviceData);
    if (ERR_SUCCESS != l_Res)
    {
        delete [] l_pDeviceData;
        return l_Res;
    }
    //Get measurement parameters from main window
    l_pDeviceData->m_StandAlone.m_Meas.m_StartPixel = l_pDeviceConfig->startPixel();
    l_pDeviceData->m_StandAlone.m_Meas.m_StopPixel =  l_pDeviceConfig->stopPixel();
    l_pDeviceData->m_StandAlone.m_Meas.m_IntegrationTime = l_pDeviceConfig->integrationTime();
    double l_NanoSec = l_pDeviceConfig->integrationDelay();
    unsigned int l_FPGAClkCycles = (unsigned int)(6.0*(l_NanoSec+20.84)/125.0);
    l_pDeviceData->m_StandAlone.m_Meas.m_IntegrationDelay = l_FPGAClkCycles;
    l_pDeviceData->m_StandAlone.m_Meas.m_NrAverages = l_pDeviceConfig->nrAverages();
    l_pDeviceData->m_StandAlone.m_Meas.m_Trigger.m_Mode = l_pDeviceConfig->trigger_mode();
    l_pDeviceData->m_StandAlone.m_Meas.m_Trigger.m_Source = l_pDeviceConfig->trigger_source();
    l_pDeviceData->m_StandAlone.m_Meas.m_Trigger.m_SourceType = l_pDeviceConfig->trigger_sourceType();
    l_pDeviceData->m_StandAlone.m_Meas.m_SaturationDetection = l_pDeviceConfig->saturationDetection();
    l_pDeviceData->m_StandAlone.m_Meas.m_CorDynDark.m_Enable = l_pDeviceConfig->corDynDark();
    l_pDeviceData->m_StandAlone.m_Meas.m_CorDynDark.m_ForgetPercentage = l_pDeviceConfig->forgetPercentage();
    l_pDeviceData->m_StandAlone.m_Meas.m_Smoothing.m_SmoothPix = l_pDeviceConfig->smoothPix();
    l_pDeviceData->m_StandAlone.m_Meas.m_Smoothing.m_SmoothModel = l_pDeviceConfig->smoothModel();
    l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_StrobeControl = l_pDeviceConfig->strobeControl();
    l_NanoSec = l_pDeviceConfig->laserDelay();
    l_FPGAClkCycles = (unsigned int)(6.0*l_NanoSec/125.0);
    l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_LaserDelay = l_FPGAClkCycles;
    l_NanoSec = l_pDeviceConfig->laserWidth();
    l_FPGAClkCycles = (unsigned int)(6.0*l_NanoSec/125.0);
    l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_LaserWidth = l_FPGAClkCycles;
    l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_LaserWaveLength = l_pDeviceConfig->laserWaveLength();
    l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_StoreToRam = l_pDeviceConfig->storeToRam();
    l_pDeviceData->m_StandAlone.m_Nmsr =  l_pDeviceConfig->nrScans();
    //Write measurement parameters
	l_Res = AVS_SetParameter(m_deviceHandle, l_pDeviceData);
    delete [] l_pDeviceData;
    return l_Res;
}


boolean CSpectrometer::GetWavellength(double* a_pWavelength) {
	int status = AVS_GetLambda(m_deviceHandle, a_pWavelength);
	if(status != 0) {
		lastErr = MapErrorToString(status);
		return false;
	}
	return true;
}

unsigned short CSpectrometer::GetNoOfPixels() {
	unsigned short a_pNumPixels = 0;
	int status = AVS_GetNumPixels(m_deviceHandle, &a_pNumPixels);
	if(status != 0) {
		lastErr = MapErrorToString(status);
	}
	return a_pNumPixels;
}

boolean CSpectrometer::IsDataAvailable(){
	int status = AVS_PollScan(m_deviceHandle);
	if(status == 0){
		return false;
	}else if(status == 1) {
		return true;
	}else if(status < 0) {
		lastErr = MapErrorToString(status);
	}else {
	}
	return false;
}

boolean CSpectrometer::GetSpectrumData(unsigned int* a_pTimeLabel, double* a_pSpectrum) {
	int status = AVS_GetScopeData(m_deviceHandle, a_pTimeLabel, a_pSpectrum);
	if(status != 0) {
		lastErr = MapErrorToString(status);
		return false;
	}
	return true;
}

unsigned char* CSpectrometer::GetSaturatedPixels() {
	unsigned char* a_pSaturated = NULL;
	int status = AVS_GetSaturatedPixels(m_deviceHandle, a_pSaturated);
	if(status != 0) {
		lastErr = MapErrorToString(status);
	}
	return NULL;
}

boolean CSpectrometer::StopMeasure() {
	int status = AVS_StopMeasure(m_deviceHandle);
	if(status == 0) {
		return true;
	}
	lastErr = MapErrorToString(status);
	return false;
}

string CSpectrometer::GetLastErr() {
	return lastErr;
}

string CSpectrometer::GetDeviceInfo() {
	DeviceConfigType*  l_pDeviceData = NULL;
	unsigned int    l_Size;
	int l_Res = AVS_GetParameter(m_deviceHandle, 0, &l_Size, l_pDeviceData);
	if ( l_Res == ERR_INVALID_SIZE)
	{
		l_pDeviceData = (DeviceConfigType*)new char[l_Size];
	}

	l_Res = AVS_GetParameter(m_deviceHandle, l_Size, &l_Size, l_pDeviceData);
  
	if (l_Res != ERR_SUCCESS)
	{
		return "???????";
	}

	switch (l_pDeviceData->m_Detector.m_SensorType)
	{
		case SENS_HAMS8378_256 : return "HAMS8378_256";
		case SENS_HAMS8378_1024 : return "HAMS8378_1024";
		case SENS_ILX554   : return "ILX554";
		case SENS_HAMS9201 : return "HAMS9201";
		case SENS_TCD1304  : return "TCD1304";
		case SENS_TSL1301  : return "TSL1301";
		case SENS_TSL1401  : return "TSL1401";
		case SENS_HAMS8378_512 : return "HAMS8378_512";
		case SENS_HAMS9840 : return "HAMS9840";
		case SENS_ILX511   : return "ILX511";
		case SENS_HAMS11071_2048X64  : return "HAMS11071_2048X64";
		case SENS_HAMS7031_1024X58   : return "HAMS7031_1024X58";
		case SENS_HAMS11071_2048X16  : return "HAMS11071_2048X16";
		case SENS_SU256LSB  : return "SU256LSB";
		case SENS_SU512LDB  : return "SU512LDB";
		default            : return "???????";
	}
	return "??????";
}

int CSpectrometer::GetDeviceNrPixels() {
	unsigned short	l_NrOfPixel = 0;
	int status = AVS_GetNumPixels(m_deviceHandle, &l_NrOfPixel);
	if (ERR_SUCCESS == status){
		return l_NrOfPixel;
	}
	lastErr = MapErrorToString(status);
	return 0;
}

boolean CSpectrometer::LaserOnOff(boolean isOff) {
	int status = 100;
	if(isOff) {
		status = AVS_SetAnalogOut(m_deviceHandle, 0,0);
	}else{
		status = AVS_SetAnalogOut(m_deviceHandle, 0 ,5);
	}
	if(status != 0) {
		lastErr = MapErrorToString(status);
		return false;
	}
	return true;
}

//Laser control after spectrometer initialization
boolean CSpectrometer::InitializeLaserScan() {
	unsigned char a_pDigIn = 0;
	int status = AVS_GetDigIn(m_deviceHandle, 2, &a_pDigIn);
	if(status != 0) {
		return false;
	}
	if(a_pDigIn == 1) {
		if(!LaserOnOff(true)) {
			return false;
		}
		if(!SetLaserPower(0)){
			return false;
		}
		clock_t startTime = clock();
		while(startTime - clock() < 5000) {   //for 5 secs
			/*status = AVS_SetDigOut(m_deviceHandle, 5, 1);
			if(status != 0) {
				lastErr = MapErrorToString(status);
				return false;
			} */
		}
		status = AVS_SetDigOut(m_deviceHandle, 5, 0);
		if(status != 0) {
			return false;
		}
	}
	return true;
}

boolean CSpectrometer::SetLaserPower(int percent){
	int status = AVS_SetAnalogOut(m_deviceHandle, 1, MapLaserPercent(percent));
	if(status != 0) {
		lastErr = MapErrorToString(status);
		return false;
	}
	return true;
}

double CSpectrometer::MapLaserPercent(int percent) {
	switch(percent) {
	case 10:
		return 0.55;
	case 20:
		return 0.86;
	case 30:
		return 1.18;
	case 40:
		return 1.5;
	case 50:
		return 1.82;
	case 60:
		return 2.14;
	case 70:
		return 2.46;
	case 80:
		return 2.78;
	case 90:
		return 2.9;
	case 100:
		return 3.1;
	}
	return 0;
}

string CSpectrometer::MapErrorToString(int err) {
	switch(err){
		case ERR_INVALID_PARAMETER:
			return "Function called with invalid parameter value.";
		case ERR_OPERATION_NOT_SUPPORTED:
			return "Function called to use 16bit ADC mode, with 14bit ADC hardware";
		case ERR_DEVICE_NOT_FOUND:
			return "Opening communication failed or time-out during communication occurred.";
		case ERR_INVALID_DEVICE_ID:
			return "Function is called while result of previous call to AVS_Measure() is not received yet";
		case ERR_OPERATION_PENDING:
			return "Operation pending!!!";
		case ERR_TIMEOUT:
			return "No answer received from device";
		case ERR_INVALID_MEAS_DATA:
			return "No measurement data is received at the point AVS_GetScopeData() is called";
		case ERR_INVALID_SIZE:
			return "Allocated buffer size too small";
		case ERR_INVALID_PIXEL_RANGE:
			return "Measurement preparation failed because pixel range is invalid";
		case ERR_INVALID_INT_TIME:
			return "Measurement preparation failed because integration time is invalid (for selected sensor)";
		case ERR_INVALID_COMBINATION:
			return "Measurement preparation failed because of an invalid combination of parameters, e.g. integration time of (600000) and (Navg > 5000)";
		case ERR_NO_MEAS_BUFFER_AVAIL:
			return "Measurement preparation failed because no measurement buffers available";
		case ERR_UNKNOWN:
			return "Unknown error reason received from spectrometer";
		case ERR_COMMUNICATION:
			return "Error in communication or Ethernet connection failure";
		case ERR_NO_SPECTRA_IN_RAM:  
			return "No more spectra available in RAM, all read or measurement not started yet";
		case ERR_INVALID_DLL_VERSION:
			return "Library version information could not be retrieved";
		case ERR_NO_MEMORY: 
			return "Memory allocation error in the Library";
		case ERR_DLL_INITIALISATION: 
			return "Function called before AVS_Init() is called";
		case ERR_INVALID_STATE:
			return "Function failed because AvaSpec is in wrong state (e.g. AVS_Measure() without calling AVS_PrepareMeasurement() first)";
		case ERR_INVALID_REPLY: 
			return "Reply is not a recognized protocol message";
		case ERR_ACCESS: 
			return "Error occurred while opening a bus device on the host. E.g. USB device access denied due to user rights";
		case ERR_INTERNAL_READ:
			return "A read error has occurred. Spectrometer has failed when reading, for example, the Device Configuration settings from the internal flash memory or the temperature value from the onboard temperature sensor";
		case ERR_INTERNAL_WRITE: 
			return "A write error has occurred. Spectrometer has failed when writing, for example, the Device Configuration settings into the internal flash memory";
		case ERR_ETHCONN_REUSE:
			return "Library could not be initialized due to an Ethernet ID: 020381 Revision: 11-03 55 � Avantes BV www.avantes.com info@avantes.com Return code Value Description connection initialization error which is caused by the presence of another Library instance running on the same machine. It also could have been caused by calling the AVS_Init() function too quickly after calling AVS_Done(). In case of ERR_ETHCONN_REUSE, AVS_Init() can be invoked again to retry the initialization.";
		case ERR_INVALID_DEVICE_TYPE:
			return "The device-type information stored in the spectrometer isn�t recognized as one of the known device types";
		case ERR_SECURE_CFG_NOT_READ: 
			return "The AVS_GetDeviceType function is used, but the secure config (holding the device type information) hasn�t been read yet. Most likely the device isn�t initialised correctly.";
		case ERR_UNEXPECTED_MEAS_RESPONSE: 
			return "Unexpected response from spectrometer while getting measurement data. (Most likely, the measurement was stopped.)";
		case ERR_INVALID_PARAMETER_ADC_GAIN:
			return "Gain Setting out of range";
		case ERR_INVALID_PARAMETER_ADC_OFFSET: 
			return "Offset Setting out of range";
		case ERR_INVALID_MEASPARAM_AVG_SAT2:
			return "Use of Saturation Detection Level 2 is not compatible with the Averaging function";
		case ERR_INVALID_MEASPARAM_AVG_RAM:
			return "Use of Averaging is not compatible with the StoreToRam function";
		case ERR_INVALID_MEASPARAM_SYNC_RAM:
			return "Use of the Synchronize setting is not compatible with the StoreToRam function";
		case ERR_INVALID_MEASPARAM_LEVEL_RAM:
			return "Use of Level Triggering is not compatible with the StoreToRam function";
		case ERR_INVALID_MEASPARAM_SAT2_RAM:
			return "Use of Saturation Detection Level 2 Parameter is not compatible with the StoreToRam function";
		case ERR_INVALID_MEASPARAM_FWVER_RAM:
			return "The StoreToRam function is only supported with firmware version 0.20.0.0 or later (AS5216 only).";
		case ERR_INVALID_MEASPARAM_DYNDARK:
			return "Dynamic Dark Correction not supported";
		case ERR_NOT_SUPPORTED_BY_SENSOR_TYPE:
			return "Use of AVS_SetSensitivityMode() not supported by detector type";
		case ERR_NOT_SUPPORTED_BY_FW_VER:
			return "Use of AVS_SetSensitivityMode() not supported by firmware version";
		case ERR_NOT_SUPPORTED_BY_FPGA_VER:
			return "Use of AVS_SetSensitivityMode() not supported by FPGA version";
		case ERR_SL_CALIBRATION_NOT_AVAILABLE:
			return "Spectrometer was not calibrated for stray light correction";
		case ERR_SL_STARTPIXEL_NOT_IN_RANGE:
			return "Incorrect start pixel found in EEPROM ";
		case ERR_SL_ENDPIXEL_NOT_IN_RANGE:
			return "Incorrect end pixel found in EEPROM";
		case ERR_SL_STARTPIX_GT_ENDPIX:
			return "Incorrect start or end pixel found in EEPROM";
		case ERR_SL_MFACTOR_OUT_OF_RANGE:
			return "Factor should be in range 0.0 � 4.0";
		default:
			return "";
	}
}
