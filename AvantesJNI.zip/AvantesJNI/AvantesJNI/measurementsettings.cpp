#include "stdafx.h"
#include "measurementSettings.h"

CMeasurementSettings::CMeasurementSettings()
{

}

void CMeasurementSettings::setStartPixel(int startPixel)
{
    m_startPixel = startPixel;
}

int CMeasurementSettings::stopPixel() const
{
    return m_stopPixel;
}

void CMeasurementSettings::setStopPixel(int stopPixel)
{
    m_stopPixel = stopPixel;
}

void CMeasurementSettings::setIntegrationTime(double integrationTime){
    m_integrationTime = integrationTime;
}

double CMeasurementSettings::integrationTime() const
{
    return m_integrationTime;
}

void CMeasurementSettings::setIntegrationDelay(double integrationDelay){
    m_integrationDelay = integrationDelay;
}

double CMeasurementSettings::integrationDelay() const
{
    return m_integrationDelay;
}

int CMeasurementSettings::nrAverages() const
{
    return m_nrAverages;
}

void CMeasurementSettings::setNrAverages(int nrAverages)
{
    m_nrAverages = nrAverages;
}

bool CMeasurementSettings::trigger_mode() const
{
    return m_trigger_mode;
}

void CMeasurementSettings::setTrigger_mode(bool trigger_mode)
{
    m_trigger_mode = trigger_mode;
}

bool CMeasurementSettings::trigger_source() const
{
    return m_trigger_source;
}

void CMeasurementSettings::setTrigger_source(bool trigger_source)
{
    m_trigger_source = trigger_source;
}

bool CMeasurementSettings::trigger_sourceType() const
{
    return m_trigger_sourceType;
}

void CMeasurementSettings::setTrigger_sourceType(bool trigger_sourceType)
{
    m_trigger_sourceType = trigger_sourceType;
}

int CMeasurementSettings::saturationDetection() const
{
    return m_saturationDetection;
}

void CMeasurementSettings::setSaturationDetection(int saturationDetection)
{
    m_saturationDetection = saturationDetection;
}

bool CMeasurementSettings::corDynDark() const
{
    return m_corDynDark;
}

void CMeasurementSettings::setCorDynDark(bool corDynDark)
{
    m_corDynDark = corDynDark;
}

int CMeasurementSettings::forgetPercentage() const
{
    return m_forgetPercentage;
}

void CMeasurementSettings::setForgetPercentage(int forgetPercentage)
{
    m_forgetPercentage = forgetPercentage;
}

int CMeasurementSettings::smoothPix() const
{
    return m_smoothPix;
}

void CMeasurementSettings::setSmoothPix(int smoothPix)
{
    m_smoothPix = smoothPix;
}

int CMeasurementSettings::smoothModel() const
{
    return m_smoothModel;
}

void CMeasurementSettings::setSmoothModel(int smoothModel)
{
    m_smoothModel = smoothModel;
}

int CMeasurementSettings::strobeControl() const
{
    return m_strobeControl;
}

double CMeasurementSettings::laserDelay() const
{
    return m_laserDelay;
}

void CMeasurementSettings::setLaserDelay(double laserDelay)
{
    m_laserDelay = laserDelay;
}

unsigned int CMeasurementSettings::laserWidth() const
{
    return m_laserWidth;
}

void CMeasurementSettings::setLaserWidth(unsigned int laserWidth)
{
    m_laserWidth = laserWidth;
}

double CMeasurementSettings::laserWaveLength() const
{
    return m_laserWaveLength;
}

void CMeasurementSettings::setLaserWaveLength(double laserWaveLength)
{
    m_laserWaveLength = laserWaveLength;
}

int CMeasurementSettings::storeToRam() const
{
    return m_storeToRam;
}

void CMeasurementSettings::setStoreToRam(int storeToRam)
{
    m_storeToRam = storeToRam;
}

void CMeasurementSettings::setStrobeControl(int strobeControl)
{
    m_strobeControl = strobeControl;
}

int CMeasurementSettings::nrScans() const
{
    return m_nrScans;
}

void CMeasurementSettings::setNrScans(int nrScans)
{
    m_nrScans = nrScans;
}

int CMeasurementSettings::startPixel() const
{
    return m_startPixel;
}
