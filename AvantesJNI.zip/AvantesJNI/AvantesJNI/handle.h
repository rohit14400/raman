#ifndef _HANDLE_H_INCLUDED_
#define _HANDLE_H_INCLUDED_

template <typename T>
T *getHandle(JNIEnv *env, jobject obj)
{
    jlong handle = env->GetLongField(obj, env->GetFieldID(env->GetObjectClass(obj), "nativeHandle", "J"));
    return reinterpret_cast<T *>(handle);
}

template <typename T>
void setHandle(JNIEnv *env, jobject obj, T *t)
{
    jlong handle = reinterpret_cast<jlong>(t);
    env->SetLongField(obj,env->GetFieldID(env->GetObjectClass(obj), "nativeHandle", "J"), handle);
}
#endif