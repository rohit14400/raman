
// RamanCaptureDlg.h : header file
//

#pragma once
#include "Spectrometer.h"

// CRamanCaptureDlg dialog
class CRamanCaptureDlg : public CDialogEx
{
// Construction
public:
	CRamanCaptureDlg(CWnd* pParent = nullptr);	// standard constructor

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_RAMANCAPTURE_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedInitialize();
	afx_msg void OnBnClickedHwTrigger();
	afx_msg void OnBnClickedLaserOn();
	afx_msg void OnBnClickedDark();
	afx_msg void OnBnClickedStart();
	afx_msg void OnBnClickedStop();
	afx_msg void OnBnClickedSaveSpectrum();
	afx_msg void OnBnClickedSaveSettings();
	afx_msg void OnBnClickedEmergencystop();
	// Hardware trigger
	BOOL m_ctrHwTrigger;
	// Laser On
	BOOL m_ctrLaser;
	// dark spectrum check
	BOOL m_ctrDark;
	int m_ctrIntegrationTime;
	int m_ctrNrAverages;
	// Laser power
	CComboBox m_ctrLaserPower;
	CListBox m_ctrLogMessages;
	CStatic m_ctrSpectrumGraph;
	//
	CSpectrometer spectrometer;
private:
	void DrawGraph(CDC* pDC); // Method to draw the graph
public:
	CButton m_ctrHwTriggerBtn;
};
