#pragma once
#include "avaspec.h"
#include <vector>
#include "measurementsettings.h"
#include <string>

using namespace std;

class CSpectrometer
{
private:
	AvsHandle m_deviceHandle;
	MeasConfigType configType;
	AvsIdentityType *connectedDevices;
	int nConnectedDevices;
	basic_string<TCHAR> lastErr;
public:
	CSpectrometer(void);
	~CSpectrometer(void);
	int Initialize();
	boolean Uninitialize();
	vector<char*> GetDeviceList(int nDevices);
	MeasConfigType* ConfigureMeasType(CMeasurementSettings* measureSettings);
	boolean Connect(const char* serialNo);
	boolean Disconnect();
	unsigned short GetNoOfPixels();
	CMeasurementSettings* ReadConfigFromDevice();
	boolean WriteConfigToDevice(CMeasurementSettings *l_pDeviceConfig);
	boolean IsDataAvailable();
	boolean PrepareMeasure(CMeasurementSettings* settings);
	boolean GetWavellength(double* a_pWavelength);
	boolean GetSpectrumData(unsigned int* a_pTimeLabel, double* a_pSpectrum);
	boolean StartMeasure();
	boolean StopMeasure();
	unsigned char* GetSaturatedPixels();
	basic_string<TCHAR> GetLastErr();
	basic_string<TCHAR> GetDeviceInfo();
	int GetDeviceNrPixels();
	boolean LaserOnOff(boolean isOff);
	boolean SetLaserPower(int percent);
	boolean InitializeLaserScan();
	boolean GetTriggerStatus();
	boolean SetTriggerMode(boolean isHardware, boolean isSync, boolean isLevelTrigger);
	boolean GetTriggerMode();
	boolean IsConnected();
private:
	AvsIdentityType* GetDeviceBySerialNo(const char* serialNo);
	double MapLaserPercent(int percent);
	basic_string<TCHAR> MapErrorToString(int err);
};

