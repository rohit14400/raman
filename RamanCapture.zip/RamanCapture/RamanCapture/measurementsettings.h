#ifndef MEASUREMENTSETTINGS_H
#define MEASUREMENTSETTINGS_H


class CMeasurementSettings
{
public:
    CMeasurementSettings();
    int startPixel() const;
    void setStartPixel(int startPixel);
    int stopPixel() const;
    void setStopPixel(int stopPixel);
    void setIntegrationTime(double integrationTime);
    double integrationTime() const;
    void setIntegrationDelay(double integrationDelay);
    double integrationDelay() const;
    int nrAverages() const;
    void setNrAverages(int nrAverages);
    bool trigger_mode() const;
    void setTrigger_mode(bool trigger_mode);
    bool trigger_source() const;
    void setTrigger_source(bool trigger_source);
    bool trigger_sourceType() const;
    void setTrigger_sourceType(bool trigger_sourceType);
    int saturationDetection() const;
    void setSaturationDetection(int saturationDetection);
    bool corDynDark() const;
    void setCorDynDark(bool corDynDark);
    int forgetPercentage() const;
    void setForgetPercentage(int forgetPercentage);
    int smoothPix() const;
    void setSmoothPix(int smoothPix);
    int smoothModel() const;
    void setSmoothModel(int smoothModel);
    int strobeControl() const;
    double laserDelay() const;
    void setLaserDelay(double laserDelay);
    unsigned int laserWidth() const;
    void setLaserWidth(unsigned int laserWidth);
    double laserWaveLength() const;
    void setLaserWaveLength(double laserWaveLength);
    int storeToRam() const;
    void setStoreToRam(int storeToRam);
    void setStrobeControl(int strobeControl);

    int nrScans() const;
    void setNrScans(int nrScans);

private:
    int m_startPixel, m_stopPixel;
    double m_integrationTime, m_integrationDelay;
    int m_nrAverages, m_nrScans;
    bool m_trigger_mode, m_trigger_source, m_trigger_sourceType;
    int m_saturationDetection;
    bool m_corDynDark;
    int m_forgetPercentage;
    int m_smoothPix,m_smoothModel;
    int m_strobeControl;
    double m_laserDelay;
    unsigned int m_laserWidth;
    double m_laserWaveLength;
    int m_storeToRam;
};

#endif // MESAUREMENTSETTINGS_H
