
// RamanCaptureDlg.cpp : implementation file
//

#include "pch.h"
#include "framework.h"
#include "RamanCapture.h"
#include "RamanCaptureDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CRamanCaptureDlg dialog



CRamanCaptureDlg::CRamanCaptureDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_RAMANCAPTURE_DIALOG, pParent)
	, m_ctrHwTrigger(FALSE)
	, m_ctrLaser(FALSE)
	, m_ctrDark(FALSE)
	, m_ctrIntegrationTime(5)
	, m_ctrNrAverages(1)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CRamanCaptureDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_HW_TRIGGER, m_ctrHwTrigger);
	DDX_Check(pDX, IDC_LASER_ON, m_ctrLaser);
	DDX_Check(pDX, IDC_DARK, m_ctrDark);
	DDX_Text(pDX, IDC_INTEGRATION_TIME, m_ctrIntegrationTime);
	DDV_MinMaxInt(pDX, m_ctrIntegrationTime, 1, 10);
	DDX_Text(pDX, IDC_AVERAGES, m_ctrNrAverages);
	DDV_MinMaxInt(pDX, m_ctrNrAverages, 1, 10);
	DDX_Control(pDX, IDC_LASERPOWER, m_ctrLaserPower);
	DDX_Control(pDX, IDC_LOG_MESSAGES, m_ctrLogMessages);
	DDX_Control(pDX, IDC_SPECTRUM_GRAPH, m_ctrSpectrumGraph);
	DDX_Control(pDX, IDC_HW_TRIGGER, m_ctrHwTriggerBtn);
}

BEGIN_MESSAGE_MAP(CRamanCaptureDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_INITIALIZE, &CRamanCaptureDlg::OnBnClickedInitialize)
	ON_BN_CLICKED(IDC_HW_TRIGGER, &CRamanCaptureDlg::OnBnClickedHwTrigger)
	ON_BN_CLICKED(IDC_LASER_ON, &CRamanCaptureDlg::OnBnClickedLaserOn)
	ON_BN_CLICKED(IDC_DARK, &CRamanCaptureDlg::OnBnClickedDark)
	ON_BN_CLICKED(IDC_START, &CRamanCaptureDlg::OnBnClickedStart)
	ON_BN_CLICKED(IDC_STOP, &CRamanCaptureDlg::OnBnClickedStop)
	ON_BN_CLICKED(IDC_SAVE_SPECTRUM, &CRamanCaptureDlg::OnBnClickedSaveSpectrum)
	ON_BN_CLICKED(IDC_SAVE_SETTINGS, &CRamanCaptureDlg::OnBnClickedSaveSettings)
	ON_BN_CLICKED(IDC_EMERGENCYSTOP, &CRamanCaptureDlg::OnBnClickedEmergencystop)
END_MESSAGE_MAP()


// CRamanCaptureDlg message handlers

BOOL CRamanCaptureDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();
	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	m_ctrSpectrumGraph.ModifyStyle(0, SS_OWNERDRAW);
	m_ctrLaserPower.SetCurSel(1);
	//m_ctrSpectrumGraph.SubclassDlgItem(IDC_SPECTRUM_GRAPH, this);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CRamanCaptureDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CRamanCaptureDlg::OnPaint()
{

/*	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();

	}
	*/

	CPaintDC dc(this); // device context for painting
	CRect rect;
	m_ctrSpectrumGraph.GetClientRect(&rect);
	m_ctrSpectrumGraph.ClientToScreen(&rect);
	ScreenToClient(&rect);

	CDC* pDC = GetDC();
	
	DrawGraph(&dc);

	ReleaseDC(pDC);
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CRamanCaptureDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CRamanCaptureDlg::OnBnClickedInitialize()
{
	int nDevices = spectrometer.Initialize();
	if (nDevices > 0) {
		vector<char*> deviceList = spectrometer.GetDeviceList(nDevices);
		char str[500] = "";
		sprintf(str, "Spectrometer %s found", deviceList[0]);
		m_ctrLogMessages.AddString((LPCTSTR)str);
		if (!spectrometer.Connect(deviceList[0])) {
			MessageBox(L"Can't connect to spectrometer!!! \nKindly check connections !!!", L"Spectrometer status", MB_OK);
			m_ctrLogMessages.AddString(L"Can't connect to spectrometer!!!");
			return;
		}
		if (!spectrometer.InitializeLaserScan()) {
			MessageBox(L"Can't initalize laser!!!", L"Laser status", MB_OK);
			return;
		}
		MessageBox(L"Spectrometer and laser initalized!!!", L"Spectrometer status", MB_OK);
	}
	else {
		MessageBox(L"No Spectrometer found!!! \n Kindly check connections !!!", L"Spectrometer status", MB_OK);
		m_ctrLogMessages.AddString(L"No Spectrometer found!!!");
	}
}


void CRamanCaptureDlg::OnBnClickedHwTrigger()
{
	if (spectrometer.IsConnected()) {
		if (spectrometer.SetTriggerMode(m_ctrHwTrigger, false, false)) {
			char str[100] = "";
			sprintf(str, "Hardware trigger mode set to %d!!!", m_ctrHwTrigger);
			m_ctrLogMessages.AddString((LPCTSTR)str);
		}
		else {
			char str[100] = "";
			sprintf(str, "Hardware trigger mode can't be set to %d!!!", m_ctrHwTrigger);
			m_ctrLogMessages.AddString((LPCTSTR)str);
			MessageBox((LPCTSTR)str, L"Hardware trigger status", MB_OK);
		}
	}
	else {
		LPCTSTR	str = L"Spectrometer is not connected!!! \nFirst initialize the spectrometer first and retry!!!";
		m_ctrLogMessages.AddString(str);
		MessageBox(str, L"Hardware trigger status", MB_OK);
		m_ctrHwTriggerBtn.SetCheck(0);
	}
}


void CRamanCaptureDlg::OnBnClickedLaserOn()
{
	if (spectrometer.IsConnected()) {
		if (spectrometer.LaserOnOff(!m_ctrLaser)) {
			char str[100] = "";
			sprintf(str, "Laser state set to %d!!!", m_ctrLaser);
			m_ctrLogMessages.AddString((LPCTSTR)str);
		}
		else {
			char str[100] = "";
			sprintf(str, "Laser state can't be set to %d!!!", m_ctrLaser);
			m_ctrLogMessages.AddString((LPCTSTR)str);
			MessageBox((LPCTSTR)str, L"Laser status", MB_OK);
		}
	}
	else {
		LPCTSTR	str = L"Spectrometer is not connected!!! \nFirst initialize the spectrometer first and retry!!!";
		m_ctrLogMessages.AddString(str);
		MessageBox(str, L"Laser status", MB_OK);
		m_ctrHwTriggerBtn.SetCheck(0);
	}
}

void CRamanCaptureDlg::OnBnClickedEmergencystop()
{
	if (!(spectrometer.SetLaserPower(0) && spectrometer.LaserOnOff(true) && spectrometer.Disconnect())) {
		basic_string<TCHAR> errStr = spectrometer.GetLastErr();
		m_ctrLogMessages.AddString(errStr.c_str());
		MessageBox(errStr.c_str(), L"Emergency stop", MB_OK);
	}
}

void CRamanCaptureDlg::OnBnClickedSaveSettings()
{
	CMeasurementSettings* mesaurementSettings = spectrometer.ReadConfigFromDevice();
	if (mesaurementSettings != NULL) {
		mesaurementSettings->setIntegrationTime(m_ctrIntegrationTime);
		mesaurementSettings->setNrAverages(m_ctrNrAverages);
		if (!spectrometer.WriteConfigToDevice(mesaurementSettings)) {
			basic_string<TCHAR> errStr = spectrometer.GetLastErr();
			m_ctrLogMessages.AddString(errStr.c_str());
			MessageBox(errStr.c_str(), L"Save measurement parameters", MB_OK);
		}
		delete mesaurementSettings;
	}else {
		basic_string<TCHAR> errStr = spectrometer.GetLastErr();
		m_ctrLogMessages.AddString(errStr.c_str());
		MessageBox(errStr.c_str(), L"Read mesaurement settings", MB_OK);
	}
	if (!spectrometer.SetLaserPower(m_ctrLaser)) {
		basic_string<TCHAR> errStr = spectrometer.GetLastErr();
		m_ctrLogMessages.AddString(errStr.c_str());
		MessageBox(errStr.c_str(), L"Laser power set", MB_OK);
	}
}

void CRamanCaptureDlg::OnBnClickedDark()
{
	if (!m_ctrHwTrigger) {

	}
}


void CRamanCaptureDlg::OnBnClickedStart()
{
	// TODO: Add your control notification handler code here
}


void CRamanCaptureDlg::OnBnClickedStop()
{
	// TODO: Add your control notification handler code here
}


void CRamanCaptureDlg::OnBnClickedSaveSpectrum()
{
	// TODO: Add your control notification handler code here
}

void CRamanCaptureDlg::DrawGraph(CDC* pDC) {
	// Get the area where the graph will be drawn (static control area)
	CRect rect;
	m_ctrSpectrumGraph.GetClientRect(&rect);
	m_ctrSpectrumGraph.ClientToScreen(&rect);
	ScreenToClient(&rect);

	// Set graph border padding
	int padding = 10;
	CRect graphArea(rect.left + padding, rect.top + padding, rect.right - padding, rect.bottom - padding);

	// Draw the axes
	pDC->MoveTo(graphArea.left, graphArea.bottom); // Y-axis start
	pDC->LineTo(graphArea.right, graphArea.bottom); // X-axis
	pDC->MoveTo(graphArea.left, graphArea.bottom);  // Y-axis start
	pDC->LineTo(graphArea.left, graphArea.top);     // Y-axis

	// Set the pen color for the grid lines (light gray)
	CPen gridPen(PS_DOT, 1, RGB(200, 200, 200));
	CPen* pOldPen = pDC->SelectObject(&gridPen);

	// Draw grid lines (both vertical and horizontal)
	int numGridLines = 5;
	for (int i = 1; i <= numGridLines; ++i)
	{
		// Vertical grid lines
		int x = graphArea.left + i * (graphArea.Width() / (numGridLines + 1));
		pDC->MoveTo(x, graphArea.bottom);
		pDC->LineTo(x, graphArea.top);

		// Horizontal grid lines
		int y = graphArea.bottom - i * (graphArea.Height() / (numGridLines + 1));
		pDC->MoveTo(graphArea.left, y);
		pDC->LineTo(graphArea.right, y);
	}

	// Restore the original pen
	pDC->SelectObject(pOldPen);

	// Example data (simple line graph)
	int data[] = { 10, 40, 70, 60, 90, 30 }; // Example data points
	int numPoints = sizeof(data) / sizeof(data[0]);

	int maxX = numPoints - 1;
	int maxY = 100;  // Maximum Y value for scaling

	// Set the pen for the graph line (blue)
	CPen linePen(PS_SOLID, 2, RGB(0, 0, 255));
	pOldPen = pDC->SelectObject(&linePen);

	// Plot the data points with lines
	for (int i = 0; i < numPoints; ++i)
	{
		int x = graphArea.left + (i * (graphArea.Width() / maxX));        // Scale X value
		int y = graphArea.bottom - ((data[i] * graphArea.Height()) / maxY); // Scale Y value

		if (i == 0)
			pDC->MoveTo(x, y); // Move to the first data point
		else
			pDC->LineTo(x, y); // Draw a line to the next point
	}

	// Restore the original pen
	pDC->SelectObject(pOldPen);

	// Set the brush for markers (red)
	CBrush markerBrush(RGB(255, 0, 0));

	// Draw markers at each data point (small circles)
	for (int i = 0; i < numPoints; ++i)
	{
		int x = graphArea.left + (i * (graphArea.Width() / maxX));        // Scale X value
		int y = graphArea.bottom - ((data[i] * graphArea.Height()) / maxY); // Scale Y value

		// Draw a small circle as the marker (radius = 3)
		pDC->SelectObject(&markerBrush);
		pDC->Ellipse(x - 3, y - 3, x + 3, y + 3); // Small circle around each data point
	}
}
