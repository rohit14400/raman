// VC_APPDlg.cpp : implementation file
//

#include "stdafx.h"
#include "avaspec.h"
#include "VC_APP.h"
#include "VC_APPDlg.h"
#include "math.h"
#include "DigtalIO.h"
#include "AnalogIO.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// no message handler
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVC_APPDlg dialog

CVC_APPDlg::CVC_APPDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CVC_APPDlg::IDD, pParent)
	, dstrMode(FALSE)
	, nrStoreToRam(100)
	, enableLogging(FALSE)
{
	//{{AFX_DATA_INIT(CVC_APPDlg)
	m_StartPixel = 0;
	m_StopPixel = 0;
	m_IntegrationDelay = 0.0;
	m_IntegrationTime = 0.0;
	m_NrAverages = 0;
	m_SaturationDetection = 0;
	m_ForgetPercentage = 0;
	m_SmoothPix = 0;
	m_SmoothModel = 0;
	m_StrobeControl = 0;
	m_LaserDelay = 0.0;
	m_LaserWidth = 0.0;
	m_LaserWaveLength = 0.0;
	m_Detectorname = L"";
	m_NrOfPixels = 0;
	m_SpecToRAM = 0;
	m_FPGAver = L"";
	m_FWver = L"";
	m_DLLver = L"";
	m_TotalTime = 0.0;
	m_PerformedScans = 0;
	m_Failures = 0;
	m_AvgTimePerScan = 0.0f;
	m_LastScanTime = 0.0f;
	m_NrOfScans = 0;
	m_chkTrigModeHw = FALSE;
	m_chkTrigModeSw = TRUE;
	m_chkTrigSourceSync = FALSE;
	m_chkTrigSourceExtHw = TRUE;
	m_chkTrigTypeEdge = TRUE;
	m_chkTrigTypeLevel = FALSE;
	m_chkEnableDarkCorrection = FALSE;
	m_Status_1 = L"";
	m_Status_2 = L"";
	m_Counts = 0;
	m_Pixelnumber = 0;
	m_UseHighResSet = false;
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CVC_APPDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CVC_APPDlg)
	DDX_Control(pDX, IDC_CHECK1, m_chkPreScan);
	DDX_Control(pDX, IDC_SPIN2, m_SelectPixel);
	DDX_Control(pDX, IDC_BT_START_MEAS, m_btnStartMeasurement);
	DDX_Text(pDX, IDC_EDT_START_PIXEL, m_StartPixel);
	DDX_Text(pDX, IDC_EDT_STOP_PIXEL, m_StopPixel);
	DDX_Text(pDX, IDC_EDT_INT_DELAY, m_IntegrationDelay);
	DDX_Text(pDX, IDC_EDT_INT_TIME, m_IntegrationTime);
	DDX_Text(pDX, IDC_EDT_NR_OF_AVA, m_NrAverages);
	DDX_Text(pDX, IDC_EDT_SATUR_LEVEL, m_SaturationDetection);
	DDX_Text(pDX, IDC_EDT_DARK_HIST, m_ForgetPercentage);
	DDX_Text(pDX, IDC_EDT_SMOOTH_PIX, m_SmoothPix);
	DDX_Text(pDX, IDC_EDT_SMOOTH_MODEL, m_SmoothModel);
	DDX_Text(pDX, IDC_EDT_FLASH_PER_SCAN, m_StrobeControl);
	DDX_Text(pDX, IDC_EDT_LASER_DELAY, m_LaserDelay);
	DDX_Text(pDX, IDC_EDT_LASER_WIDTH, m_LaserWidth);
	DDX_Text(pDX, IDC_EDT_LASER_WL, m_LaserWaveLength);
	DDX_Text(pDX, IDC_EDT_DETECTOR_NAME, m_Detectorname);
	DDX_Text(pDX, IDC_EDT_NR_OF_PIXEL, m_NrOfPixels);
	DDX_Text(pDX, IDC_EDT_SPEC_TO_RAM, m_SpecToRAM);
	DDX_Text(pDX, IDC_EDT_FPGA_VERSION, m_FPGAver);
	DDX_Text(pDX, IDC_EDT_FW_VERSION, m_FWver);
	DDX_Text(pDX, IDC_EDT_DLL_VERSION, m_DLLver);
	DDX_Text(pDX, IDC_EDT_TOTAL_TIME, m_TotalTime);
	DDX_Text(pDX, IDC_EDT_PERFORMED_SCAN, m_PerformedScans);
	DDX_Text(pDX, IDC_EDT_FAILURES, m_Failures);
	DDX_Text(pDX, IDC_EDT_AVG_TIME_PER_SCAN, m_AvgTimePerScan);
	DDX_Text(pDX, IDC_EDT_LAST_SACN_TIME, m_LastScanTime);
	DDX_Text(pDX, IDC_EDT_NR_OF_SCAN, m_NrOfScans);
	DDX_Check(pDX, IDC_CB_TRIG_MOD_HW, m_chkTrigModeHw);
	DDX_Check(pDX, IDC_CB_TIG_MOD_SW, m_chkTrigModeSw);
	DDX_Check(pDX, IDC_CB_TRIG_SRC_SYC, m_chkTrigSourceSync);
	DDX_Check(pDX, IDC_CB_TRIG_SRC_EXT, m_chkTrigSourceExtHw);
	DDX_Check(pDX, IDC_CB_TRIG_TYP_EDGE, m_chkTrigTypeEdge);
	DDX_Check(pDX, IDC_CB_TRIG_TYP_LEVEL, m_chkTrigTypeLevel);
	DDX_Check(pDX, IDC_CB_DARK_COR, m_chkEnableDarkCorrection);
	DDX_Text(pDX, IDC_STATUS_1, m_Status_1);
	DDX_Text(pDX, IDC_STATUS_2, m_Status_2);
	DDX_Text(pDX, IDC_EDT_COUNT, m_Counts);
	DDX_Text(pDX, IDC_EDT_PIXELNR, m_Pixelnumber);
	//}}AFX_DATA_MAP
	DDX_Check(pDX, IDC_CHK_DSTR, dstrMode);
	DDX_Control(pDX, IDC_PROGRESS_DSTR, progressDSTR);
	DDX_Control(pDX, IDC_LBL_DSTRCOUNT, lblDstrStatusCount);
	DDX_Text(pDX, IDC_EDIT_NRSTR, nrStoreToRam);
	DDX_Control(pDX, IDC_EDIT_NRSTR, editStoreToRam);
	DDX_Check(pDX, IDC_CHECK_LOGGING, enableLogging);
}

BEGIN_MESSAGE_MAP(CVC_APPDlg, CDialog)
	//{{AFX_MSG_MAP(CVC_APPDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BT_START_MEAS, OnbtnStartMeasurementClick)
	ON_BN_CLICKED(IDC_BT_STOP_MEAS, OnbtnStopMeasurementClick)
	ON_BN_CLICKED(IDC_CB_TRIG_MOD_HW, OnChkTrigModeHwClick)
	ON_BN_CLICKED(IDC_CB_TIG_MOD_SW, OnChkTrigModeSwClick)
	ON_BN_CLICKED(IDC_CB_TRIG_SRC_EXT, OnChkTrigSourceExtHwClick)
	ON_BN_CLICKED(IDC_CB_TRIG_SRC_SYC, OnChkTrigSourceSyncClick)
	ON_BN_CLICKED(IDC_CB_TRIG_TYP_EDGE, OnChkTrigTypeEdgeClick)
	ON_BN_CLICKED(IDC_CB_TRIG_TYP_LEVEL, OnChkTrigTypeLevelClick)
	ON_MESSAGE(WM_MEAS_READY, DataReceived)
	ON_MESSAGE(WM_DSTR_STATUS, DSTRStatusReceived)
	ON_BN_CLICKED(IDC_BTN_READ_EEPROM, OnBtnReadMeasFromEEPromClick)
	ON_BN_CLICKED(IDC_BTN_WRITE_EEPROM, OnBtnWriteMeasToEEPromClick)
	ON_BN_CLICKED(IDC_BTN_DIGIO, OnBtnDigioClick)
	ON_BN_CLICKED(IDC_BTN_ANIO, OnBtnAnioClick)
	ON_WM_VSCROLL()
	ON_BN_CLICKED(IDC_CHECK1, OnCheckPrescan1)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_CHK_DSTR, &CVC_APPDlg::OnBnClickedChkDstr)
	ON_BN_CLICKED(IDC_CHECK_LOGGING, &CVC_APPDlg::OnBnClickedCheckLogging)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVC_APPDlg message handlers

BOOL CVC_APPDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{	
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}
	SetIcon(m_hIcon, TRUE);			
	SetIcon(m_hIcon, FALSE);		
	m_SelectPixel.SetBase(10);
	m_SelectPixel.SetRange(0, 1);
	m_SelectPixel.SetPos(0);
	
	OnBnClickedChkDstr();

	/*******************************************************************************
                            Looks for connected spectrometers
	*******************************************************************************/
	AvsIdentityType l_Active ;
    AvsHandle l_hDevice ;
	
	m_Status_1 = "Open communication busy";
    
	int l_Port = AVS_Init(0);

    AVS_Register(m_hWnd);
    
	if (l_Port > 0)
    {
        m_Status_1 = "Connected: USB";
		
        GetActiveSpec(&l_Active);
    }
    else
    {
        AVS_Done();
		Sleep(250);
        l_Port = AVS_Init(-1);   //try Ethernet autodetect
        if (l_Port > 0)
        {
          m_Status_1 = "Connected: Ethernet" ;
          GetActiveSpec(&l_Active);
        }
        else
        {
            m_Status_1 = "Open communication failed";
			m_DeviceHandle =INVALID_AVS_HANDLE_VALUE;
            AVS_Done();
        }
    }

	UpdateData(false);

	/*******************************************************************************
                                 Activate Spectrometer
	*******************************************************************************/
	if (l_Port > 0)
    {
 		l_hDevice = AVS_Activate(&l_Active);
		if (INVALID_AVS_HANDLE_VALUE == l_hDevice)
		{
			AfxMessageBox(L"Error opening device ", MB_OK|MB_ICONSTOP, 0 );
		}
		else
		{
			    m_DeviceHandle = l_hDevice;
				GetActiveSpec(&l_Active);
				ConnectGui();
			    OnBtnReadMeasFromEEPromClick();
   		}
	}
	return TRUE;  
}

void CVC_APPDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CVC_APPDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); 

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}


HCURSOR CVC_APPDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CVC_APPDlg::OnClose() 
{

	if (m_DeviceHandle!=INVALID_AVS_HANDLE_VALUE)
    {
      int l_Res = AVS_StopMeasure(m_DeviceHandle);
      if (ERR_SUCCESS != l_Res)
      {
          wchar_t buf[80];
          wsprintf(buf, L"Error in AVS_StopMeasure, code: %d", l_Res);
          AfxMessageBox(buf, MB_OK|MB_ICONSTOP );
      }
    }

    if (m_pLambda != NULL)
    {
        delete [] m_pLambda;
        m_pLambda = NULL;
        m_NrOfPixels = 0;
    }
    AVS_Done();
	
	CDialog::OnClose();
	
}
//---------------------------------------------------------------------------
void CVC_APPDlg::GetActiveSpec(AvsIdentityType* l_Active)
{
	unsigned int        l_Size = 0;
    unsigned int        l_RequiredSize = 0;
    int                 l_NrDevices;
    char*               l_pData = NULL;
    AvsIdentityType*    l_pId;
	
     l_NrDevices = AVS_GetNrOfDevices();
 
	 l_RequiredSize = l_NrDevices * sizeof(AvsIdentityType);
     
	 if (l_RequiredSize > 0)
     {
            delete [] l_pData;
            l_pData = new char[l_RequiredSize];
            l_Size = l_RequiredSize;
            l_pId = (AvsIdentityType*)l_pData;
			l_NrDevices = AVS_GetList(l_Size, &l_RequiredSize, l_pId);
			

            for (int i = 0; i < l_NrDevices; i++)
            {
                switch (l_pId->Status)
                {
                   case UNKNOWN                  : m_Status_1 = "UNKNOWN";
                                                   break;
                   case USB_AVAILABLE            : m_Status_1 = "USB_AVAILABLE";
											       strcpy(l_Active->SerialNumber, l_pId->SerialNumber);
											       strcpy(l_Active->UserFriendlyName, l_pId->UserFriendlyName);
											       l_Active->Status = l_pId->Status ;					   
                                                   break;
                   case USB_IN_USE_BY_APPLICATION: m_Status_1 = "USB_IN_USE_BY_APPLICATION";
											       strcpy(l_Active->SerialNumber, l_pId->SerialNumber);
											       strcpy(l_Active->UserFriendlyName, l_pId->UserFriendlyName);
											       l_Active->Status = l_pId->Status ;					   	
                                                   break;
                   case USB_IN_USE_BY_OTHER      : m_Status_1 = "USB_IN_USE_BY_OTHER";
                                                   break;
				   case ETH_AVAILABLE			 : m_Status_1 = "ETH_AVAILABLE";
												   strcpy(l_Active->SerialNumber, l_pId->SerialNumber);
												   strcpy(l_Active->UserFriendlyName, l_pId->UserFriendlyName);
												   l_Active->Status = l_pId->Status;
												   break;
                   default                       : m_Status_1 = "??????";
                                                   break;
                }
                l_pId++;
            }
            delete [] l_pData;

     }
}

//---------------------------------------------------------------------------
void CVC_APPDlg::ConnectGui(void)
{
	
    DeviceConfigType*  l_pDeviceData = NULL;
	unsigned short	l_NrOfPixel = 0;
    unsigned int    l_Size;
	
    char a_Fpga[16];
    char a_As5216[16];
    char a_Dll[16];
	
	m_pLambda = NULL;

    int l_Res = AVS_GetVersionInfo(m_DeviceHandle, a_Fpga, a_As5216, a_Dll);
    
	if (ERR_SUCCESS == l_Res)
    {
        m_FPGAver = a_Fpga;
        m_FWver = a_As5216;
        m_DLLver = a_Dll;
    }

    if (ERR_SUCCESS == AVS_GetNumPixels(m_DeviceHandle, &l_NrOfPixel))
    {
        m_NrOfPixels = l_NrOfPixel;
    }

    l_Res = AVS_GetParameter(m_DeviceHandle, 0, &l_Size, l_pDeviceData);

    if ( l_Res == ERR_INVALID_SIZE)
    {
        l_pDeviceData = (DeviceConfigType*)new char[l_Size];
    }

    l_Res = AVS_GetParameter(m_DeviceHandle, l_Size, &l_Size, l_pDeviceData);
  
	if (l_Res != ERR_SUCCESS)
    {
        DisconnectGui();
        return;
    }

    switch (l_pDeviceData->m_Detector.m_SensorType)
    {
        case SENS_HAMS8378_256: m_Detectorname = "HAMS8378_256";
                                break;
        case SENS_HAMS8378_1024: m_Detectorname = "HAMS8378_1024";
                                 break;
        case SENS_ILX554: m_Detectorname = "ILX554";
                          break;
        case SENS_HAMS9201: m_Detectorname = "HAMS9201";
                            break;
        case SENS_TCD1304: m_Detectorname = "TCD1304";
						   m_chkPreScan.ShowWindow(SW_SHOW);
						   m_chkPreScan.SetCheck(BST_CHECKED);
						   l_Res = AVS_SetPrescanMode(m_DeviceHandle,(m_chkPreScan.GetCheck()==BST_CHECKED));
                           break;
        case SENS_TSL1301: m_Detectorname = "TSL1301";
                           break;
        case SENS_TSL1401: m_Detectorname = "TSL1401";
                           break;
        case SENS_HAMS8378_512: m_Detectorname  = "HAMS8378_512";
                                break;
        case SENS_HAMS9840: m_Detectorname  = "HAMS9840";
                            break;
		case SENS_ILX511: m_Detectorname = "ILX511";
                          break;
        case SENS_HAMS10420_11850: m_Detectorname = "HAMS10420_11850";
                                     break;
        case SENS_HAMS11071_2048X64: m_Detectorname = "HAMS11071_2048X64";
                                     break;
        case SENS_HAMS7031_11501: m_Detectorname = "HAMS7031_11501";
                                  break;
        case SENS_HAMS7031_1024X58: m_Detectorname = "HAMS7031_1024X58";
                                    break;
        case SENS_HAMS11071_2048X16: m_Detectorname = "HAMS11071_2048X16";
                                     break;
        case SENS_HAMS11155_2048: m_Detectorname = "HAMS11155";
                                  break;
        case SENS_SU256LSB: m_Detectorname = "SU256LSB";
                            break;
        case SENS_SU512LDB: m_Detectorname = "SU512LDB";
                            break;
        case SENS_HAMS11638: m_Detectorname = "HAMS11638";
                             break;
        case SENS_HAMS11639: m_Detectorname = "HAMS11639";
                             break;
        case SENS_HAMS12443: m_Detectorname = "HAMS12443";
                             break;
        case SENS_HAMG9208_512: m_Detectorname = "HAMG9208_512";
                                break;
        case SENS_HAMG13913: m_Detectorname = "HAMG13913";
                             break;
        case SENS_HAMS13496: m_Detectorname = "HAMS13496";
                             break;
        default: m_Detectorname = "???????";
                 break;
    }

    m_StartPixel = l_pDeviceData->m_StandAlone.m_Meas.m_StartPixel;
    m_StopPixel = l_pDeviceData->m_StandAlone.m_Meas.m_StopPixel;

    if (NULL != m_pLambda)
    {
        // delete old structure because number of pixels can be changed.
        delete [] m_pLambda;
        m_pLambda = NULL;
    }
    m_pLambda = new double[m_NrOfPixels];

    if (ERR_SUCCESS == AVS_GetLambda(m_DeviceHandle, m_pLambda))
    {
       
    }
    delete [] l_pDeviceData;
	
	UpdateData(false);
}
//---------------------------------------------------------------------------
void CVC_APPDlg::DisconnectGui(void)
{
	
    if (NULL != m_pLambda)
    {
        delete [] m_pLambda;
        m_pLambda = NULL;
    }
    
	m_Detectorname = L"";
    m_NrOfPixels = 0;
    m_FPGAver = L"";
    m_FWver = L"";
    m_DLLver = L"";

	UpdateData(false);
	
}
void CVC_APPDlg::OnbtnStartMeasurementClick() 
{
	
	UpdateData(true);
    // prevent second StartMeasurementClick before sequence ends.
    m_btnStartMeasurement.ShowWindow(SW_HIDE);
	m_DstrStatusCount = 0;

    // set to 16 bits
	int l_Res;
	
	if (!m_UseHighResSet) {
		l_Res = AVS_UseHighResAdc(m_DeviceHandle, 1);
		if (ERR_SUCCESS != l_Res)
		{
			wchar_t buf[80];
			wsprintf(buf, L"AVS_UseHighResAdc failed, code: %d", l_Res);
			AfxMessageBox(buf, MB_OK | MB_ICONSTOP, 0);
			m_btnStartMeasurement.EnableWindow(false);
			return;
		}
		m_UseHighResSet = true;
	}
    //Prepare Measurement
    MeasConfigType   l_PrepareMeasData;
    CString l_Line;

    l_PrepareMeasData.m_StartPixel = m_StartPixel;
    l_PrepareMeasData.m_StopPixel =  m_StopPixel;
    l_PrepareMeasData.m_IntegrationTime = m_IntegrationTime;
    //double l_NanoSec = edtIntegrationDelay->Text.ToDouble();
    l_PrepareMeasData.m_IntegrationDelay = (unsigned int)(6.0*(m_IntegrationDelay + 20.84)/125.0);
     
    l_PrepareMeasData.m_NrAverages = m_NrAverages;
    l_PrepareMeasData.m_Trigger.m_Mode = m_chkTrigModeHw;
    l_PrepareMeasData.m_Trigger.m_Source = m_chkTrigSourceSync;
    l_PrepareMeasData.m_Trigger.m_SourceType = m_chkTrigTypeLevel;
    l_PrepareMeasData.m_SaturationDetection = m_SaturationDetection;
    l_PrepareMeasData.m_CorDynDark.m_Enable = m_chkEnableDarkCorrection;
    l_PrepareMeasData.m_CorDynDark.m_ForgetPercentage = m_ForgetPercentage;
    l_PrepareMeasData.m_Smoothing.m_SmoothPix = m_SmoothPix;
    l_PrepareMeasData.m_Smoothing.m_SmoothModel = m_SmoothModel;
    l_PrepareMeasData.m_Control.m_StrobeControl = m_StrobeControl;
    //l_NanoSec = edtLaserDelay->Text.ToDouble();
    
    l_PrepareMeasData.m_Control.m_LaserDelay = (unsigned int)(6.0*m_LaserDelay/125.0);
    l_PrepareMeasData.m_Control.m_LaserWidth = (unsigned int)(6.0*m_LaserWidth/125.0);
    l_PrepareMeasData.m_Control.m_LaserWaveLength = m_LaserWaveLength;

	l_PrepareMeasData.m_Control.m_StoreToRam = dstrMode ? nrStoreToRam : 0;

    l_Res = AVS_PrepareMeasure(m_DeviceHandle, &l_PrepareMeasData);
    if (ERR_SUCCESS != l_Res)
    {	
        wchar_t buf[80];
        wsprintf(buf, L"AVS_PrepareMeasure failed, code: %d", l_Res);
		AfxMessageBox(buf, MB_OK|MB_ICONSTOP, 0);
		m_btnStartMeasurement.EnableWindow(false);
		return;
    }
   
	//Start Measurement
    m_StartTicks = GetTickCount();
    m_Measurements = 0;
    m_Failures = 0;
    m_TotalTime = 0.0;
    m_PerformedScans = 0;
    m_StartPixel = l_PrepareMeasData.m_StartPixel;
    m_StopPixel = l_PrepareMeasData.m_StopPixel;

	m_SelectPixel.SetRange( m_StartPixel, m_StopPixel );
	m_SelectPixel.SetPos(m_StartPixel);

	if (dstrMode) {
		m_NrOfScans = -2;
		l_Res = AVS_SetDstrStatus(m_DeviceHandle, m_hWnd);
		if (ERR_SUCCESS != l_Res)
		{
			wchar_t buf[80];
			wsprintf(buf, L"AVS_SetDstrStatus failed, code: %d", l_Res);
			AfxMessageBox(buf, MB_OK | MB_ICONSTOP, 0);
		}
	}
    l_Res = AVS_Measure(m_DeviceHandle, m_hWnd, m_NrOfScans);

    if (ERR_SUCCESS != l_Res)
    {
        switch (l_Res)
        {
        case ERR_INVALID_PARAMETER:
            m_Status_2 = "Meas.Status: invalid parameter";
            break;
        default:
            m_Status_2 = "Meas.Status: start failed, code: " + l_Res;
            break;
        }
    }
    else
    {
		m_Status_2 = "Meas.Status: pending"; 
    }	
	UpdateData(false);
}

//---------------------------------------------------------------------------
void CVC_APPDlg::OnbtnStopMeasurementClick() 
{
	int l_Res = AVS_StopMeasure(m_DeviceHandle);

    if (ERR_SUCCESS == l_Res)
    {
		m_btnStartMeasurement.ShowWindow(SW_SHOW);
	}
	else {
		wchar_t buf[80];
		wsprintf(buf, L"AVS_StopMeasure FAILED, code: %d", l_Res);
		AfxMessageBox(buf, MB_OK | MB_ICONSTOP, 0);
	}
}

//---------------------------------------------------------------------------
void CVC_APPDlg::OnChkTrigModeHwClick() 
{
	UpdateData(true);
	m_chkTrigModeSw = !m_chkTrigModeHw;
	UpdateData(false);
}

//---------------------------------------------------------------------------
void CVC_APPDlg::OnChkTrigModeSwClick() 
{
	UpdateData(true);
	m_chkTrigModeHw = !m_chkTrigModeSw;	
	UpdateData(false);
}

//---------------------------------------------------------------------------
void CVC_APPDlg::OnChkTrigSourceExtHwClick() 
{
	UpdateData(true);
	m_chkTrigSourceSync = !m_chkTrigSourceExtHw;	
	UpdateData(false);
}

//---------------------------------------------------------------------------
void CVC_APPDlg::OnChkTrigSourceSyncClick() 
{
	UpdateData(true);
	m_chkTrigSourceExtHw = !m_chkTrigSourceSync;
	UpdateData(false);
}

//---------------------------------------------------------------------------
void CVC_APPDlg::OnChkTrigTypeEdgeClick() 
{
	UpdateData(true);
	m_chkTrigTypeLevel = !m_chkTrigTypeEdge;
	UpdateData(false);
}

//---------------------------------------------------------------------------
void CVC_APPDlg::OnChkTrigTypeLevelClick() 
{
	UpdateData(true);
	m_chkTrigTypeEdge = !m_chkTrigTypeLevel;
	UpdateData(false);
}

//---------------------------------------------------------------------------
LRESULT CVC_APPDlg::DataReceived(WPARAM wParam, LPARAM lParam)
{
	DWORD			l_Ticks;
    CString			l_Line;
    
    if (ERR_SUCCESS == wParam)
    {
        double* l_pSpectrum;
        unsigned char* l_pSaturated;
       
		UpdateData(true);

        m_Status_2 = "Meas.Status: success";

        if (m_NrOfPixels > 0)
        {
            l_pSpectrum = new double[m_NrOfPixels];
            l_pSaturated = new unsigned char[m_NrOfPixels];

            if (NULL == m_pLambda)
            {
                m_pLambda = new double[m_NrOfPixels];
            }
            if (0 == AVS_GetLambda(m_DeviceHandle, m_pLambda))
            {
                ;
            }

            unsigned int l_Time;

            if (ERR_SUCCESS == AVS_GetScopeData(m_DeviceHandle, &l_Time, l_pSpectrum))
            {
                uint32 l_Dif = l_Time - m_PreviousTimeStamp;  //l_Time in 10 us ticks
                m_PreviousTimeStamp = l_Time;

                if (l_Dif != 0)
                {
                    m_LastScanTime = l_Dif/100.0f;//millisec
                }

                AVS_GetSaturatedPixels(m_DeviceHandle, l_pSaturated);
				//display data
				m_Counts = l_pSpectrum[m_Pixelnumber];
            }
            else
            {
				m_Status_2 = "Meas.Status: no data avail.";
            }

            delete [] l_pSpectrum;
            delete [] l_pSaturated;
        }
        m_Measurements++;

        if ((m_NrOfScans > 0) && (m_NrOfScans == (int) m_Measurements))
           m_btnStartMeasurement.ShowWindow(SW_SHOW); //= (StrToInt(edtNrOfScans->Text)== m_Measurements);
    }
    else
    {
		m_Status_2 = "Meas.Status: failed. Error "+ wParam;
        m_Failures++;
    }
    l_Ticks = GetTickCount();
    m_TotalTime =  (l_Ticks - m_StartTicks)/ 1000;
    m_PerformedScans = m_Measurements;
    m_AvgTimePerScan = (float)(1.0*(l_Ticks - m_StartTicks)/m_Measurements);//,ffFixed,7,2);
    UpdateData(false);
	return LRESULT();
}

//---------------------------------------------------------------------------
void CVC_APPDlg::OnBtnReadMeasFromEEPromClick() 
{
	DeviceConfigType*  l_pDeviceData = NULL;
    unsigned int       l_Size;


    int l_Res = AVS_GetParameter(m_DeviceHandle, 0, &l_Size, l_pDeviceData);

    if ( l_Res == ERR_INVALID_SIZE)
    {
        l_pDeviceData = (DeviceConfigType*)new char[l_Size];
    }
    l_Res = AVS_GetParameter(m_DeviceHandle, l_Size, &l_Size, l_pDeviceData);
    if (ERR_SUCCESS != l_Res)
    {
        wchar_t buf[80];
        wsprintf(buf, L"AVS_GetParameter FAILED, code: %d", l_Res);
        AfxMessageBox(buf, MB_OK|MB_ICONSTOP, 0);
        delete [] l_pDeviceData;
        return;
    }

    //show measurement settings
    m_StartPixel = l_pDeviceData->m_StandAlone.m_Meas.m_StartPixel;
    m_StopPixel = l_pDeviceData->m_StandAlone.m_Meas.m_StopPixel;
    m_IntegrationTime = l_pDeviceData->m_StandAlone.m_Meas.m_IntegrationTime;
    unsigned int l_FPGAClkCycles = l_pDeviceData->m_StandAlone.m_Meas.m_IntegrationDelay;
    m_IntegrationDelay = floor(125.0*(l_FPGAClkCycles-1.0)/6.0); 
    m_NrAverages = l_pDeviceData->m_StandAlone.m_Meas.m_NrAverages;
    m_SaturationDetection = l_pDeviceData->m_StandAlone.m_Meas.m_SaturationDetection;
    m_chkTrigModeHw =  (l_pDeviceData->m_StandAlone.m_Meas.m_Trigger.m_Mode == 1);
    m_chkTrigModeSw =  (l_pDeviceData->m_StandAlone.m_Meas.m_Trigger.m_Mode == 0);
    m_chkTrigSourceExtHw =  (l_pDeviceData->m_StandAlone.m_Meas.m_Trigger.m_Source == 0);
    m_chkTrigSourceSync =   (l_pDeviceData->m_StandAlone.m_Meas.m_Trigger.m_Source == 1);
    m_chkTrigTypeEdge = (l_pDeviceData->m_StandAlone.m_Meas.m_Trigger.m_SourceType == 0);
    m_chkTrigTypeLevel = (l_pDeviceData->m_StandAlone.m_Meas.m_Trigger.m_SourceType == 1);
    m_chkEnableDarkCorrection = (l_pDeviceData->m_StandAlone.m_Meas.m_CorDynDark.m_Enable == 1);
    m_ForgetPercentage = l_pDeviceData->m_StandAlone.m_Meas.m_CorDynDark.m_ForgetPercentage;
    m_SmoothModel = l_pDeviceData->m_StandAlone.m_Meas.m_Smoothing.m_SmoothModel;
    m_SmoothPix = l_pDeviceData->m_StandAlone.m_Meas.m_Smoothing.m_SmoothPix;
    m_StrobeControl = l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_StrobeControl;
    l_FPGAClkCycles = l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_LaserDelay;
    m_LaserDelay = 125.0*(l_FPGAClkCycles)/6.0;
    l_FPGAClkCycles = l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_LaserWidth;
    m_LaserWidth = 125.0*(l_FPGAClkCycles)/6.0;
    m_LaserWaveLength = l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_LaserWaveLength;
    m_SpecToRAM= 0; //IntToStr(l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_StoreToRam);
                             //prepared for future version
    m_NrOfScans = l_pDeviceData->m_StandAlone.m_Nmsr;

	m_SelectPixel.SetRange( m_StartPixel, m_StopPixel );
	m_SelectPixel.SetPos(m_StartPixel);

    delete [] l_pDeviceData;

	UpdateData(false);
}

//---------------------------------------------------------------------------
void CVC_APPDlg::OnBtnWriteMeasToEEPromClick() 
{
		DeviceConfigType*  l_pDeviceData = NULL;
    unsigned int       l_Size;

	UpdateData(true);

    int l_Res = AVS_GetParameter(m_DeviceHandle, 0, &l_Size, l_pDeviceData);

    if ( l_Res == ERR_INVALID_SIZE)
    {
        l_pDeviceData = (DeviceConfigType*)new char[l_Size];
    }
    l_Res = AVS_GetParameter(m_DeviceHandle, l_Size, &l_Size, l_pDeviceData);
    if (ERR_SUCCESS != l_Res)
    {
        wchar_t buf[80];
        wsprintf(buf, L"AVS_GetParameter, code: %d", l_Res);
        AfxMessageBox(buf, MB_OK|MB_ICONSTOP, 0);
        delete [] l_pDeviceData;
        return;
    }
    //Get measurement parameters from main window
    l_pDeviceData->m_StandAlone.m_Meas.m_StartPixel = m_StartPixel;
    l_pDeviceData->m_StandAlone.m_Meas.m_StopPixel =  m_StopPixel;
    l_pDeviceData->m_StandAlone.m_Meas.m_IntegrationTime = m_IntegrationTime;
    unsigned int l_FPGAClkCycles = (unsigned int)(6.0*(m_IntegrationDelay+20.84)/125.0);
    l_pDeviceData->m_StandAlone.m_Meas.m_IntegrationDelay = (unsigned int)l_FPGAClkCycles;
    l_pDeviceData->m_StandAlone.m_Meas.m_NrAverages = m_NrAverages;
    l_pDeviceData->m_StandAlone.m_Meas.m_Trigger.m_Mode = m_chkTrigModeHw;
    l_pDeviceData->m_StandAlone.m_Meas.m_Trigger.m_Source = m_chkTrigSourceSync;
    l_pDeviceData->m_StandAlone.m_Meas.m_Trigger.m_SourceType = m_chkTrigTypeLevel;
    l_pDeviceData->m_StandAlone.m_Meas.m_SaturationDetection = m_SaturationDetection;
    l_pDeviceData->m_StandAlone.m_Meas.m_CorDynDark.m_Enable = m_chkEnableDarkCorrection;
    l_pDeviceData->m_StandAlone.m_Meas.m_CorDynDark.m_ForgetPercentage = m_ForgetPercentage;
    l_pDeviceData->m_StandAlone.m_Meas.m_Smoothing.m_SmoothPix = m_SmoothPix;
    l_pDeviceData->m_StandAlone.m_Meas.m_Smoothing.m_SmoothModel = m_SmoothModel;
    l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_StrobeControl = m_StrobeControl;
    l_FPGAClkCycles = (unsigned int)(6.0*m_LaserDelay/125.0);
    l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_LaserDelay = (unsigned int)m_LaserDelay;
    l_FPGAClkCycles = (unsigned int)(6.0*m_LaserWidth/125.0);
    l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_LaserWidth = l_FPGAClkCycles;
    l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_LaserWaveLength = m_LaserWaveLength;
    l_pDeviceData->m_StandAlone.m_Meas.m_Control.m_StoreToRam = 0; //edtRamSpectra->Text.ToInt();
                                                                   //prepared for future version
    l_pDeviceData->m_StandAlone.m_Nmsr =  m_NrOfScans;

    //Write measurement parameters
    l_Res = AVS_SetParameter(m_DeviceHandle, l_pDeviceData);
    if (ERR_SUCCESS != l_Res)
    {
        wchar_t buf[80];
        wsprintf(buf, L"AVS_SetParameter, code: %d", l_Res);
        AfxMessageBox(buf, MB_OK|MB_ICONSTOP, 0);
    }
    delete [] l_pDeviceData;
}

void CVC_APPDlg::OnBtnDigioClick() 
{
	DigtalIO dlgDigtalIO;
	dlgDigtalIO.m_DeviceHandle = m_DeviceHandle;
	dlgDigtalIO.DoModal();	
}

void CVC_APPDlg::OnBtnAnioClick() 
{
	AnalogIO dlgAnalogIO;
	dlgAnalogIO.m_DeviceHandle = m_DeviceHandle;
	dlgAnalogIO.DoModal();	
}

void CVC_APPDlg::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	UpdateData(true);

	CSpinButtonCtrl *spnCtrl;
	
	spnCtrl = reinterpret_cast<CSpinButtonCtrl *>(GetDlgItem(IDC_SPIN2));

	if(reinterpret_cast<CSpinButtonCtrl *>(pScrollBar) == spnCtrl)
	{
		m_Pixelnumber = nPos;	
	}

	UpdateData(false);

	CDialog::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CVC_APPDlg::OnCheckPrescan1() 
{
	int l_Res = AVS_SetPrescanMode(m_DeviceHandle,(m_chkPreScan.GetCheck()==BST_CHECKED));
	if (ERR_SUCCESS != l_Res)
    {
        wchar_t buf[80];
        wsprintf(buf, L"AVS_SetPrescanMode, code: %d", l_Res);
        AfxMessageBox(buf, MB_OK|MB_ICONSTOP, 0);
    }	
}

LRESULT CVC_APPDlg::DSTRStatusReceived(WPARAM wParam, LPARAM lParam)
{
	DstrStatusType l_Status;

	m_DstrStatusCount++;
	wchar_t buf[80];
	wsprintf(buf, L"DSTR status count: %d", m_DstrStatusCount);
	lblDstrStatusCount.SetWindowText(buf);
	
	int l_Res = AVS_GetDstrStatus(m_DeviceHandle, &l_Status);
	if (ERR_SUCCESS == l_Res)
	{
		if (l_Status.m_TotalScans > 0) {
			progressDSTR.SetRange(0, l_Status.m_TotalScans);
			progressDSTR.SetPos(l_Status.m_UsedScans);
		}
	}

	if (wParam > 0) {
		// wParam>0 => DSTR reported an error
		m_btnStartMeasurement.ShowWindow(SW_SHOW);
	}

	return LRESULT();
}


void CVC_APPDlg::OnBnClickedChkDstr()
{
	UpdateData();
	progressDSTR.ShowWindow(dstrMode ? SW_SHOW : SW_HIDE);
	lblDstrStatusCount.ShowWindow(dstrMode ? SW_SHOW : SW_HIDE);
	editStoreToRam.ShowWindow(dstrMode ? SW_SHOW : SW_HIDE);
}


void CVC_APPDlg::OnBnClickedCheckLogging()
{
	UpdateData();
	AVS_EnableLogging(enableLogging);
}
