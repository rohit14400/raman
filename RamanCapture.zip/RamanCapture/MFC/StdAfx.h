// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently

#if !defined(AFX_STDAFX_H__F640070A_0FCB_4F6F_AA50_8C3B3B110AC0__INCLUDED_)
#define AFX_STDAFX_H__F640070A_0FCB_4F6F_AA50_8C3B3B110AC0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#define _WIN32_WINNT NTDDI_VISTA
#define VC_EXTRALEAN		// Do not include infrequently uses parts of the Windows header

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation extensions
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__F640070A_0FCB_4F6F_AA50_8C3B3B110AC0__INCLUDED_)
