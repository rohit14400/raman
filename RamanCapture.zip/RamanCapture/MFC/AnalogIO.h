#if !defined(AFX_ANALOGIO_H__7F478928_03D4_44F9_96AC_FA39598E30E7__INCLUDED_)
#define AFX_ANALOGIO_H__7F478928_03D4_44F9_96AC_FA39598E30E7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "avaspec.h"
// AnalogIO.h : Header file
//

/////////////////////////////////////////////////////////////////////////////
// AnalogIO dialog

class AnalogIO : public CDialog
{
// Construction
public:
	AnalogIO(CWnd* pParent = NULL);   // Standard constructor

// Dialog Data
	//{{AFX_DATA(AnalogIO)
	enum { IDD = IDD_AN_IO };
	float	m_AI0;
	float	m_AI1;
	float	m_AI2;
	float	m_AI3;
	float	m_AI4;
	float	m_AI5;
	float	m_AI6;
	float	m_AI7;
	float	m_AO0;
	float	m_AO1;
	//}}AFX_DATA
	long m_DeviceHandle;


// overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(AnalogIO)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(AnalogIO)
	afx_msg void OnBtnSetAnalogOutClick();
	afx_msg void OnBtnGetAnalogInClick();
	afx_msg void OnBtnGetOnboardClick();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // AFX_ANALOGIO_H__7F478928_03D4_44F9_96AC_FA39598E30E7__INCLUDED_
