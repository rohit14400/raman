// VC_APP.h : main header file for the VC_APP application
//

#if !defined(AFX_VC_APP_H__107E7415_500D_48CA_82EF_7804991F2882__INCLUDED_)
#define AFX_VC_APP_H__107E7415_500D_48CA_82EF_7804991F2882__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CVC_APPApp:
// See VC_APP.cpp for the implementation of this class
//

class CVC_APPApp : public CWinApp
{
public:
	CVC_APPApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVC_APPApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CVC_APPApp)
		// NOTE - The ClassWizard will add and remove member functions here.
		// DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VC_APP_H__107E7415_500D_48CA_82EF_7804991F2882__INCLUDED_)
