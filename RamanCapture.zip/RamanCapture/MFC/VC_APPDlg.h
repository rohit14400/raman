// VC_APPDlg.h : Header file
//

#if !defined(AFX_VC_APPDLG_H__7E195F8E_E93E_4ACA_A4D2_14C9C349D3FA__INCLUDED_)
#define AFX_VC_APPDLG_H__7E195F8E_E93E_4ACA_A4D2_14C9C349D3FA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "avaspec.h"
/////////////////////////////////////////////////////////////////////////////
// CVC_APPDlg Dialogfeld

class CVC_APPDlg : public CDialog
{
// Construction
public:

	long			m_DeviceHandle;
	double			*m_pLambda;
    unsigned long	m_StartTicks;
    unsigned int    m_Measurements;
    bool            m_GraphicsDisabled;
    unsigned int    m_PreviousTimeStamp;

	void GetActiveSpec(AvsIdentityType* l_Active);
	void ConnectGui();
	void DisconnectGui();

	CVC_APPDlg(CWnd* pParent = NULL);	// Standard constructor

// Dialog Data
	//{{AFX_DATA(CVC_APPDlg)
	enum { IDD = IDD_VC_APP_DIALOG };
	CButton	m_chkPreScan;
	CSpinButtonCtrl	m_SelectPixel;
	CListCtrl	m_ShowList;
	CButton	m_btnStartMeasurement;
	UINT	m_StartPixel;
	UINT	m_StopPixel;
	double	m_IntegrationDelay;
	float	m_IntegrationTime;
	UINT	m_NrAverages;
	BYTE	m_SaturationDetection;
	BYTE	m_ForgetPercentage;
	UINT	m_SmoothPix;
	BYTE	m_SmoothModel;
	UINT	m_StrobeControl;
	double	m_LaserDelay;
	double	m_LaserWidth;
	float	m_LaserWaveLength;
	CString	m_Detectorname;
	UINT	m_NrOfPixels;
	UINT	m_SpecToRAM;
	CString	m_FPGAver;
	CString	m_FWver;
	CString	m_DLLver;
	double	m_TotalTime;
	UINT	m_PerformedScans;
	UINT	m_Failures;
	float	m_AvgTimePerScan;
	float	m_LastScanTime;
	int		m_NrOfScans;
	BOOL	m_chkTrigModeHw;
	BOOL	m_chkTrigModeSw;
	BOOL	m_chkTrigSourceSync;
	BOOL	m_chkTrigSourceExtHw;
	BOOL	m_chkTrigTypeEdge;
	BOOL	m_chkTrigTypeLevel;
	BOOL	m_chkEnableDarkCorrection;
	CString	m_Status_1;
	CString	m_Status_2;
	double	m_Counts;
	int		m_Pixelnumber;
	int		m_DstrStatusCount;
	bool	m_UseHighResSet;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVC_APPDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CVC_APPDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	afx_msg void OnbtnStartMeasurementClick();
	afx_msg void OnbtnStopMeasurementClick();
	afx_msg void OnChkTrigModeHwClick();
	afx_msg void OnChkTrigModeSwClick();
	afx_msg void OnChkTrigSourceExtHwClick();
	afx_msg void OnChkTrigSourceSyncClick();
	afx_msg void OnChkTrigTypeEdgeClick();
	afx_msg void OnChkTrigTypeLevelClick();
	afx_msg	LRESULT DataReceived(WPARAM wParam, LPARAM lParam);
	afx_msg	LRESULT DSTRStatusReceived(WPARAM wParam, LPARAM lParam);
	afx_msg void OnBtnReadMeasFromEEPromClick();
	afx_msg void OnBtnWriteMeasToEEPromClick();
	afx_msg void OnBtnDigioClick();
	afx_msg void OnBtnAnioClick();
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnCheckPrescan1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	BOOL dstrMode;
	CProgressCtrl progressDSTR;
	CStatic lblDstrStatusCount;
	int nrStoreToRam;
	afx_msg void OnBnClickedChkDstr();
	CEdit editStoreToRam;
	BOOL enableLogging;
	afx_msg void OnBnClickedCheckLogging();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VC_APPDLG_H__7E195F8E_E93E_4ACA_A4D2_14C9C349D3FA__INCLUDED_)
