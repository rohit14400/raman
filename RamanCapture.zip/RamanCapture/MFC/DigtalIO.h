#if !defined(AFX_DIGTALIO_H__CB445FB6_974D_4DFD_9E9D_E2E245B14B37__INCLUDED_)
#define AFX_DIGTALIO_H__CB445FB6_974D_4DFD_9E9D_E2E245B14B37__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "avaspec.h"

// DigtalIO.h : Header file
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld DigtalIO 

class DigtalIO : public CDialog
{
// Construction
public:
	DigtalIO(CWnd* pParent = NULL);   // Standardkonstruktor

// Dialog Data
	//{{AFX_DATA(DigtalIO)
	enum { IDD = IDD_DIG_IO };
	BYTE	m_Duty1;
	BYTE	m_Duty2;
	BYTE	m_Duty3;
	BYTE	m_Duty5;
	BYTE	m_Duty6;
	BYTE	m_Duty7;
	long	m_Freq123;
	long	m_Freq567;
	BOOL	m_chkDO1;
	BOOL	m_chkDO10;
	BOOL	m_chkDO2;
	BOOL	m_chkDO3;
	BOOL	m_chkDO4;
	BOOL	m_chkDO5;
	BOOL	m_chkDO6;
	BOOL	m_chkDO7;
	BOOL	m_chkDO8;
	BOOL	m_chkDO9;
	BOOL	m_chkPWM1;
	BOOL	m_chkPWM2;
	BOOL	m_chkPWM3;
	BOOL	m_chkPWM5;
	BOOL	m_chkPWM6;
	BOOL	m_chkPWM7;
	BOOL	m_chkDI1;
	BOOL	m_chkDI2;
	BOOL	m_chkDI3;
	//}}AFX_DATA
	long m_DeviceHandle;


// overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(DigtalIO)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void OutputClick(unsigned char a_Id, BOOL a_Value);
	// Generated message map functions
	//{{AFX_MSG(DigtalIO)
	afx_msg void OnBtnGetDigInClick();
	afx_msg void OnChkDo1Click();
	afx_msg void OnChkDo2Click();
	afx_msg void OnChkDo3Click();
	afx_msg void OnChkDo4Click();
	afx_msg void OnChkDo5Click();
	afx_msg void OnChkDo6Click();
	afx_msg void OnChkDo7Click();
	afx_msg void OnChkDo8Click();
	afx_msg void OnChkDo9Click();
	afx_msg void OnChkDo10Click();
	afx_msg void OnChkPwm1Click();
	afx_msg void OnChkPwm2Click();
	afx_msg void OnChkPwm3Click();
	afx_msg void OnChkPwm5Click();
	afx_msg void OnChkPwm6Click();
	afx_msg void OnChkPwm7Click();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // AFX_DIGTALIO_H__CB445FB6_974D_4DFD_9E9D_E2E245B14B37__INCLUDED_
