// DigtalIO.cpp: implementation file
//

#include "stdafx.h"
#include "VC_APP.h"
#include "DigtalIO.h"
#include "avaspec.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// DigtalIO dialog

DigtalIO::DigtalIO(CWnd* pParent /*=NULL*/)
	: CDialog(DigtalIO::IDD, pParent)
{
	//{{AFX_DATA_INIT(DigtalIO)
	m_Duty1 = 50;
	m_Duty2 = 50;
	m_Duty3 = 50;
	m_Duty5 = 50;
	m_Duty6 = 50;
	m_Duty7 = 50;
	m_Freq123 = 1000;
	m_Freq567 = 1000;
	m_chkDO1 = FALSE;
	m_chkDO10 = FALSE;
	m_chkDO2 = FALSE;
	m_chkDO3 = FALSE;
	m_chkDO4 = FALSE;
	m_chkDO5 = FALSE;
	m_chkDO6 = FALSE;
	m_chkDO7 = FALSE;
	m_chkDO8 = FALSE;
	m_chkDO9 = FALSE;
	m_chkPWM1 = FALSE;
	m_chkPWM2 = FALSE;
	m_chkPWM3 = FALSE;
	m_chkPWM5 = FALSE;
	m_chkPWM6 = FALSE;
	m_chkPWM7 = FALSE;
	m_chkDI1 = FALSE;
	m_chkDI2 = FALSE;
	m_chkDI3 = FALSE;
	//}}AFX_DATA_INIT
}

void DigtalIO::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(DigtalIO)
	DDX_Text(pDX, IDC_EDT_DUTY1, m_Duty1);
	DDX_Text(pDX, IDC_EDT_DUTY2, m_Duty2);
	DDX_Text(pDX, IDC_EDT_DUTY3, m_Duty3);
	DDX_Text(pDX, IDC_EDT_DUTY5, m_Duty5);
	DDX_Text(pDX, IDC_EDT_DUTY6, m_Duty6);
	DDX_Text(pDX, IDC_EDT_DUTY7, m_Duty7);
	DDX_Text(pDX, IDC_EDT_FREQU1, m_Freq123);
	DDX_Text(pDX, IDC_EDT_FREQU2, m_Freq567);
	DDX_Check(pDX, IDC_CHK_DO1, m_chkDO1);
	DDX_Check(pDX, IDC_CHK_DO10, m_chkDO10);
	DDX_Check(pDX, IDC_CHK_DO2, m_chkDO2);
	DDX_Check(pDX, IDC_CHK_DO3, m_chkDO3);
	DDX_Check(pDX, IDC_CHK_DO4, m_chkDO4);
	DDX_Check(pDX, IDC_CHK_DO5, m_chkDO5);
	DDX_Check(pDX, IDC_CHK_DO6, m_chkDO6);
	DDX_Check(pDX, IDC_CHK_DO7, m_chkDO7);
	DDX_Check(pDX, IDC_CHK_DO8, m_chkDO8);
	DDX_Check(pDX, IDC_CHK_DO9, m_chkDO9);
	DDX_Check(pDX, IDC_CHK_PWM1, m_chkPWM1);
	DDX_Check(pDX, IDC_CHK_PWM2, m_chkPWM2);
	DDX_Check(pDX, IDC_CHK_PWM3, m_chkPWM3);
	DDX_Check(pDX, IDC_CHK_PWM5, m_chkPWM5);
	DDX_Check(pDX, IDC_CHK_PWM6, m_chkPWM6);
	DDX_Check(pDX, IDC_CHK_PWM7, m_chkPWM7);
	DDX_Check(pDX, IDC_CHK_DI1, m_chkDI1);
	DDX_Check(pDX, IDC_CHK_DI2, m_chkDI2);
	DDX_Check(pDX, IDC_CHK_DI3, m_chkDI3);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(DigtalIO, CDialog)
	//{{AFX_MSG_MAP(DigtalIO)
	ON_BN_CLICKED(IDC_BTN_GET_DIG_IN, OnBtnGetDigInClick)
	ON_BN_CLICKED(IDC_CHK_DO1, OnChkDo1Click)
	ON_BN_CLICKED(IDC_CHK_DO2, OnChkDo2Click)
	ON_BN_CLICKED(IDC_CHK_DO3, OnChkDo3Click)
	ON_BN_CLICKED(IDC_CHK_DO4, OnChkDo4Click)
	ON_BN_CLICKED(IDC_CHK_DO5, OnChkDo5Click)
	ON_BN_CLICKED(IDC_CHK_DO6, OnChkDo6Click)
	ON_BN_CLICKED(IDC_CHK_DO7, OnChkDo7Click)
	ON_BN_CLICKED(IDC_CHK_DO8, OnChkDo8Click)
	ON_BN_CLICKED(IDC_CHK_DO9, OnChkDo9Click)
	ON_BN_CLICKED(IDC_CHK_DO10, OnChkDo10Click)
	ON_BN_CLICKED(IDC_CHK_PWM1, OnChkPwm1Click)
	ON_BN_CLICKED(IDC_CHK_PWM2, OnChkPwm2Click)
	ON_BN_CLICKED(IDC_CHK_PWM3, OnChkPwm3Click)
	ON_BN_CLICKED(IDC_CHK_PWM5, OnChkPwm5Click)
	ON_BN_CLICKED(IDC_CHK_PWM6, OnChkPwm6Click)
	ON_BN_CLICKED(IDC_CHK_PWM7, OnChkPwm7Click)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
//
void DigtalIO::OnBtnGetDigInClick() 
{
	#define NR_OF_DIGITAL_INPUTS    3
	#define DIG_IN0                 0
	#define DIG_IN1                 1
	#define DIG_IN2                 2

    unsigned char   l_Value[NR_OF_DIGITAL_INPUTS];
    bool            l_bNoError = true;

    for (int i = 0; (i < NR_OF_DIGITAL_INPUTS) && l_bNoError; ++i)
    {
        l_bNoError = (ERR_SUCCESS == AVS_GetDigIn(m_DeviceHandle, i, &l_Value[i]));
    }

    if (l_bNoError)
    {     
        m_chkDI1 = l_Value[DIG_IN0];
        m_chkDI2 = l_Value[DIG_IN1];
        m_chkDI3 = l_Value[DIG_IN2];
    }
    else
    {
		AfxMessageBox(L"Communication Error",MB_OK|MB_ICONSTOP, 0);
    }

	UpdateData(false);
	
}

void DigtalIO::OutputClick(unsigned char a_Id, BOOL a_Value)
{
    int l_Res;

	UpdateData(true);

    if (((a_Id==0)||(a_Id==1)||(a_Id==2)||(a_Id==4)||(a_Id==5)||(a_Id==6)) && (a_Value==1))
    {
       switch (a_Id)
       {
              case 0 : if (m_chkPWM1)
                       {
                          l_Res = AVS_SetPwmOut(m_DeviceHandle, a_Id, m_Freq123, m_Duty1);
                       }
                       else
                          l_Res = AVS_SetDigOut(m_DeviceHandle, a_Id, a_Value);
                       break;
              case 1 : if (m_chkPWM2)
                       {
                          l_Res = AVS_SetPwmOut(m_DeviceHandle, a_Id, m_Freq123, m_Duty2);
                       }
                       else
                          l_Res = AVS_SetDigOut(m_DeviceHandle, a_Id, a_Value);
                       break;
              case 2 : if (m_chkPWM3)
                       {
                          l_Res = AVS_SetPwmOut(m_DeviceHandle, a_Id, m_Freq123, m_Duty3);
                       }
                       else
                          l_Res = AVS_SetDigOut(m_DeviceHandle, a_Id, a_Value);
                       break;
              case 4 : if (m_chkPWM5)
                       {
                          l_Res = AVS_SetPwmOut(m_DeviceHandle, a_Id, m_Freq567, m_Duty5);
                       }
                       else
                          l_Res = AVS_SetDigOut(m_DeviceHandle, a_Id, a_Value);
                       break;
              case 5 : if (m_chkPWM6)
                       {
                          l_Res = AVS_SetPwmOut(m_DeviceHandle, a_Id, m_Freq567, m_Duty6);
                       }
                       else
                          l_Res = AVS_SetDigOut(m_DeviceHandle, a_Id, a_Value);
                       break;
              case 6 : if (m_chkPWM7)
                       {
                           l_Res = AVS_SetPwmOut(m_DeviceHandle, a_Id, m_Freq567, m_Duty7);
                       }
                       else
                          l_Res = AVS_SetDigOut(m_DeviceHandle, a_Id, a_Value);
                       break;
       }
    }
    else
    {
        l_Res = AVS_SetDigOut(m_DeviceHandle, a_Id, a_Value);
    }
    if (l_Res != ERR_SUCCESS)
    {
            wchar_t buf[80];
            wsprintf(buf, L"Error: %d", l_Res);
            AfxMessageBox(buf,MB_OK|MB_ICONSTOP, 0);
    }
	UpdateData(false);
}

void DigtalIO::OnChkDo1Click() 
{
	UpdateData(true);
	OutputClick(0, m_chkDO1);
	UpdateData(false);
}

void DigtalIO::OnChkDo2Click() 
{
	UpdateData(true);
	OutputClick(1, m_chkDO2);
	UpdateData(false);
}

void DigtalIO::OnChkDo3Click() 
{
	UpdateData(true);
	OutputClick(2, m_chkDO3);
	UpdateData(false);
}

void DigtalIO::OnChkDo4Click() 
{
	UpdateData(true);
	OutputClick(3, m_chkDO4);
	UpdateData(false);
}

void DigtalIO::OnChkDo5Click() 
{
	UpdateData(true);
	OutputClick(4, m_chkDO5);
	UpdateData(false);
}

void DigtalIO::OnChkDo6Click() 
{
	UpdateData(true);
	OutputClick(5, m_chkDO6);
	UpdateData(false);
}

void DigtalIO::OnChkDo7Click() 
{
	UpdateData(true);
	OutputClick(6, m_chkDO7);
	UpdateData(false);
}

void DigtalIO::OnChkDo8Click() 
{
	UpdateData(true);
	OutputClick(7, m_chkDO8);
	UpdateData(false);
}

void DigtalIO::OnChkDo9Click() 
{
	UpdateData(true);
	OutputClick(8, m_chkDO9);
	UpdateData(false);
}

void DigtalIO::OnChkDo10Click() 
{
	UpdateData(true);
	OutputClick(9, m_chkDO10);	
	UpdateData(false);
}

void DigtalIO::OnChkPwm1Click() 
{
	UpdateData(true);
	OutputClick(0, m_chkDO1);
	UpdateData(false);
}

void DigtalIO::OnChkPwm2Click() 
{
	UpdateData(true);
	OutputClick(1, m_chkDO2);
	UpdateData(false);
}

void DigtalIO::OnChkPwm3Click() 
{
	UpdateData(true);
	OutputClick(2, m_chkDO3);
	UpdateData(false);
}

void DigtalIO::OnChkPwm5Click() 
{
	UpdateData(true);
	OutputClick(4, m_chkDO5);
	UpdateData(false);
}

void DigtalIO::OnChkPwm6Click() 
{
	UpdateData(true);
	OutputClick(5, m_chkDO6);
	UpdateData(false);
}

void DigtalIO::OnChkPwm7Click() 
{
	UpdateData(true);
	OutputClick(6, m_chkDO7);	
	UpdateData(false);
}
