// VC_APP.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "VC_APP.h"
#include "VC_APPDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CVC_APPApp

BEGIN_MESSAGE_MAP(CVC_APPApp, CWinApp)
	//{{AFX_MSG_MAP(CVC_APPApp)
		// NOTE - The ClassWizard will add and remove member functions here.
		// DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVC_APPApp construction

CVC_APPApp::CVC_APPApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CVC_APPApp object

CVC_APPApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CVC_APPApp initialization


BOOL CVC_APPApp::InitInstance()
{
	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need

#ifdef _AFXDLL
	Enable3dControls();			// should be used when linking to the MFC DLLs
#else
	Enable3dControlsStatic();	// should be used when statically linking to the MFC libraries
#endif

	CVC_APPDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cance
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
