// AnalogIO.cpp: implementation file
//

#include "stdafx.h"
#include "VC_APP.h"
#include "AnalogIO.h"
#include "avaspec.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// AnalogIO dialog


AnalogIO::AnalogIO(CWnd* pParent /*=NULL*/)
	: CDialog(AnalogIO::IDD, pParent)
{
	//{{AFX_DATA_INIT(AnalogIO)
	m_AI0 = 0.0f;
	m_AI1 = 0.0f;
	m_AI2 = 0.0f;
	m_AI3 = 0.0f;
	m_AI4 = 0.0f;
	m_AI5 = 0.0f;
	m_AI6 = 0.0f;
	m_AI7 = 0.0f;
	m_AO0 = 0.0f;
	m_AO1 = 0.0f;
	//}}AFX_DATA_INIT
}


void AnalogIO::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(AnalogIO)
	DDX_Text(pDX, IDC_EDT_AI0, m_AI0);
	DDX_Text(pDX, IDC_EDT_AI1, m_AI1);
	DDX_Text(pDX, IDC_EDT_AI2, m_AI2);
	DDX_Text(pDX, IDC_EDT_AI3, m_AI3);
	DDX_Text(pDX, IDC_EDT_AI4, m_AI4);
	DDX_Text(pDX, IDC_EDT_AI5, m_AI5);
	DDX_Text(pDX, IDC_EDT_AI6, m_AI6);
	DDX_Text(pDX, IDC_EDT_AI7, m_AI7);
	DDX_Text(pDX, IDC_EDT_AO0, m_AO0);
	DDX_Text(pDX, IDC_EDT_AO1, m_AO1);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(AnalogIO, CDialog)
	//{{AFX_MSG_MAP(AnalogIO)
	ON_BN_CLICKED(IDC_BTN_SET_ANALOG_OUT, OnBtnSetAnalogOutClick)
	ON_BN_CLICKED(IDC_BTN_GET_ANALOG_IN, OnBtnGetAnalogInClick)
	ON_BN_CLICKED(IDC_BTN_GET_ONBOARD, OnBtnGetOnboardClick)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// AnalogIO message handlers

void AnalogIO::OnBtnSetAnalogOutClick() 
{
	#define NR_OF_ANALOG_OUTPUTS     2

	float   l_Value[NR_OF_ANALOG_OUTPUTS];
    bool    l_bNoError = true;

	UpdateData(true);

    l_Value[0] = m_AO0;
    l_Value[1] = m_AO1;
		
    for (int i = 0; (i < NR_OF_ANALOG_OUTPUTS) && l_bNoError; ++i)
    {
        int l_Res = AVS_SetAnalogOut(m_DeviceHandle, i, l_Value[i]);
        if (l_Res != ERR_SUCCESS)
        {
            l_bNoError = false;
            wchar_t buf[80];
            wsprintf(buf, L"Error: %d", l_Res);
			AfxMessageBox(buf, MB_OK|MB_ICONSTOP, 0);
        }
    }	
}

void AnalogIO::OnBtnGetAnalogInClick() 
{
	#define NR_OF_ANALOG_INPUTS     2

    float   l_Value[NR_OF_ANALOG_INPUTS];

    int l_Res = AVS_GetAnalogIn(m_DeviceHandle, 5, &l_Value[0]);
    if (l_Res != ERR_SUCCESS)
    {
            wchar_t buf[80];
            wsprintf(buf, L"Error ID=5 (pin 9): %d", l_Res);
            AfxMessageBox(buf, MB_OK|MB_ICONSTOP, 0);
    }
    else
        m_AI5 = l_Value[0];
    
	l_Res = AVS_GetAnalogIn(m_DeviceHandle, 4, &l_Value[1]);
    
	if (l_Res != ERR_SUCCESS)
    {
            wchar_t buf[80];
            wsprintf(buf, L"Error ID=4 (pin 18): %d", l_Res);
            AfxMessageBox(buf, MB_OK|MB_ICONSTOP, 0);
    }
    else
        m_AI4 = l_Value[1];


	UpdateData(false);
}

void AnalogIO::OnBtnGetOnboardClick() 
{
    float   l_Value;
    int l_Res = AVS_GetAnalogIn(m_DeviceHandle, 0, &l_Value);
    if (l_Res != ERR_SUCCESS)
    {
            wchar_t buf[80];
            wsprintf(buf, L"Error ID=0: %d", l_Res);
            AfxMessageBox(buf, MB_OK|MB_ICONSTOP, 0);
    }
    else
       m_AI0 = l_Value;

    l_Res = AVS_GetAnalogIn(m_DeviceHandle, 1, &l_Value);
    if (l_Res != ERR_SUCCESS)
    {
            wchar_t buf[80];
            wsprintf(buf, L"Error ID=1: %d", l_Res);
            AfxMessageBox(buf, MB_OK|MB_ICONSTOP, 0);
    }
    else
        m_AI1 = l_Value;

    l_Res = AVS_GetAnalogIn(m_DeviceHandle, 2, &l_Value);
    if (l_Res != ERR_SUCCESS)
    {
            wchar_t buf[80];
            wsprintf(buf, L"Error ID=2: %d", l_Res);
            AfxMessageBox(buf, MB_OK|MB_ICONSTOP, 0);
    }
    else
        m_AI2 = l_Value;

    l_Res = AVS_GetAnalogIn(m_DeviceHandle, 3, &l_Value);
    if (l_Res != ERR_SUCCESS)
    {
            wchar_t buf[80];
            wsprintf(buf, L"Error ID=3: %d", l_Res);
            AfxMessageBox(buf, MB_OK|MB_ICONSTOP, 0);
    }
    else
        m_AI3 = l_Value;

    l_Res = AVS_GetAnalogIn(m_DeviceHandle, 6, &l_Value);
    if (l_Res != ERR_SUCCESS)
    {
            wchar_t buf[80];
            wsprintf(buf, L"Error ID=6: %d", l_Res);
            AfxMessageBox(buf, MB_OK|MB_ICONSTOP, 0);
    }
    else
        m_AI6 = l_Value;

    l_Res = AVS_GetAnalogIn(m_DeviceHandle, 7, &l_Value);
    if (l_Res != ERR_SUCCESS)
    {
            wchar_t buf[80];
            wsprintf(buf, L"Error ID=7: %d", l_Res);
            AfxMessageBox(buf, MB_OK|MB_ICONSTOP, 0);
    }
    else
        m_AI7 = l_Value;

	UpdateData(false);
}
