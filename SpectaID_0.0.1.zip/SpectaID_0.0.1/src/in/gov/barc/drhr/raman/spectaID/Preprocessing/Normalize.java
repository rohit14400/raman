package in.gov.barc.drhr.raman.spectaID.Preprocessing;

public class Normalize {
	public double[] normalizeData(double[] data,double min, double max){
		double[] tempData = new double[data.length];
		for(int i=0;i<data.length;i++){
			tempData[i] = (data[i] - min) / max;
		}
		return tempData;
	}
}
