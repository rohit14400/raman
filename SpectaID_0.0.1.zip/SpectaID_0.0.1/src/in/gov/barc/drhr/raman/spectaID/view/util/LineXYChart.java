package in.gov.barc.drhr.raman.spectaID.view.util;

import java.util.Objects;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.Axis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;

public class LineXYChart<X,Y> extends LineChart<X, Y> {
	private ObservableList<Data<X, Y>> horizontalMarkers;
    private ObservableList<Data<X, Y>> verticalMarkers;
    private ObservableList<Data<X, X>> verticalRangeMarkers;
    private ObservableList<Data<Y, Y>> horizontalRangeMarkers;

    private Data<X, Y> horizontalLines;
    private Data<X, Y> verticalLines;
    private Data<X, X> verticalRangeRect;
    private Data<Y, Y> horizontalRangeRect;


    public LineXYChart(Axis<X> xAxis, Axis<Y> yAxis, ObservableList<XYChart.Series<X,Y>> data){
    	super(xAxis, yAxis,data);
    }

    public LineXYChart(Axis<X> xAxis, Axis<Y> yAxis) {
        super(xAxis, yAxis);
        horizontalMarkers = FXCollections.observableArrayList(data -> new Observable[] {data.YValueProperty()});
        horizontalMarkers.addListener((InvalidationListener)observable -> layoutPlotChildren());
        verticalMarkers = FXCollections.observableArrayList(data -> new Observable[] {data.XValueProperty()});
        verticalMarkers.addListener((InvalidationListener)observable -> layoutPlotChildren());
        verticalRangeMarkers = FXCollections.observableArrayList(data -> new Observable[] {data.XValueProperty()});
        verticalRangeMarkers = FXCollections.observableArrayList(data -> new Observable[] {data.YValueProperty()}); // 2nd type of the range is X type as well
        verticalRangeMarkers.addListener((InvalidationListener)observable -> layoutPlotChildren());
        horizontalRangeMarkers = FXCollections.observableArrayList(data -> new Observable[] {data.YValueProperty()});
        horizontalRangeMarkers = FXCollections.observableArrayList(data -> new Observable[] {data.XValueProperty()}); // 2nd type of the range is X type as well
        horizontalRangeMarkers.addListener((InvalidationListener)observable -> layoutPlotChildren());
    }

    public void addHorizontalValueMarker(Data<X, Y> marker) {
        Objects.requireNonNull(marker, "the marker must not be null");
        if (horizontalMarkers.contains(marker)) return;
        Line line = new Line();
        marker.setNode(line);
        getPlotChildren().add(line);
        horizontalMarkers.add(marker);
    }

    public void removeHorizontalValueMarker(Data<X, Y> marker) {
        Objects.requireNonNull(marker, "the marker must not be null");
        if (marker.getNode() != null) {
            getPlotChildren().remove(marker.getNode());
            marker.setNode(null);
        }
        horizontalMarkers.remove(marker);
    }

    public void addVerticalValueMarker(Data<X, Y> marker) {
        Objects.requireNonNull(marker, "the marker must not be null");
       if (verticalMarkers.contains(marker)) return;
        Line line = new Line();
        marker.setNode(line );
        getPlotChildren().add(line);
        verticalMarkers.add(marker);
    }

    public void removeVerticalValueMarker(Data<X, Y> marker) {
        Objects.requireNonNull(marker, "the marker must not be null");
        if (marker.getNode() != null) {
            getPlotChildren().remove(marker.getNode());
            marker.setNode(null);
        }
        verticalMarkers.remove(marker);
    }

    public void addVerticalRangeMarker(Data<X, X> marker) {
        Objects.requireNonNull(marker, "the marker must not be null");
        if (verticalRangeMarkers.contains(marker)) return;

        Rectangle rectangle = new Rectangle(0,0,0,0);
        rectangle.setStroke(Color.TRANSPARENT);
        rectangle.setFill(Color.BLUE.deriveColor(1, 1, 1, 0.2));

        marker.setNode( rectangle);
        getPlotChildren().add(rectangle);
        verticalRangeMarkers.add(marker);
    }

    public void removeVerticalRangeMarker(Data<X, X> marker) {
        Objects.requireNonNull(marker, "the marker must not be null");
        if (marker.getNode() != null) {
            getPlotChildren().remove(marker.getNode());
            marker.setNode(null);
        }
        verticalRangeMarkers.remove(marker);
    }

    public void addHorizontalRangeMarker(Data<Y, Y> marker) {
        Objects.requireNonNull(marker, "the marker must not be null");
        if (horizontalRangeMarkers.contains(marker)) return;
        Rectangle rectangle = new Rectangle(0,0,0,0);
        rectangle.setStroke(Color.TRANSPARENT);
        rectangle.setFill(Color.BLUE.deriveColor(1, 1, 1, 0.2));
        marker.setNode( rectangle);
        getPlotChildren().add(rectangle);
        horizontalRangeMarkers.add(marker);
    }

    public void removeHorizontalRangeMarker(Data<Y, Y> marker) {
        Objects.requireNonNull(marker, "the marker must not be null");
        if (marker.getNode() != null) {
            getPlotChildren().remove(marker.getNode());
            marker.setNode(null);
        }
        horizontalRangeMarkers.remove(marker);
    }

    public void setHorizontalLine(Data<X,Y> marker){
    	Line horzLine = new Line();
    	marker.setNode(horzLine);
    	getPlotChildren().add(horzLine);
    	horizontalLines = marker;
    	layoutPlotChildren();
    }

    public void resetHorizontalLine(Data<X,Y> marker){
    	Objects.requireNonNull(marker, "the marker must not be null");
        if (marker.getNode() != null) {
            getPlotChildren().remove(marker.getNode());
            marker.setNode(null);
        }
        horizontalLines = null;
        layoutPlotChildren();
    }

    public void setVerticalLine(Data<X,Y> marker){
    	Line vertLine = new Line();
    	marker.setNode(vertLine);
    	getPlotChildren().add(vertLine);
    	verticalLines = marker;
    	layoutPlotChildren();
    }

    public void resetVerticalLine(Data<X,Y> marker){
    	Objects.requireNonNull(marker, "the marker must not be null");
        if (marker.getNode() != null) {
            getPlotChildren().remove(marker.getNode());
            marker.setNode(null);
        }
        verticalLines = null;
        layoutPlotChildren();
    }

    public void setHorizontalRect(Data<Y,Y> marker){
    	Rectangle selRect = new Rectangle(0,0,0,0);
        selRect.setStroke(Color.TRANSPARENT);
        selRect.setFill(Color.BLUE.deriveColor(1, 1, 1, 0.2));
        marker.setNode(selRect);
        getPlotChildren().add(selRect);
        horizontalRangeRect = marker;
        layoutPlotChildren();
    }

    public void resetHorizontalRect(Data<Y,Y> marker){
    	Objects.requireNonNull(marker, "the marker must not be null");
        if (marker.getNode() != null) {
            getPlotChildren().remove(marker.getNode());
            marker.setNode(null);
        }
        horizontalRangeRect = null;
    }

    public void setVerticalRect(Data<X,X> marker){
    	Rectangle selRect = new Rectangle(0,0,0,0);
        selRect.setStroke(Color.TRANSPARENT);
        selRect.setFill(Color.BLUE.deriveColor(1, 1, 1, 0.2));
        marker.setNode(selRect);
        getPlotChildren().add(selRect);
        verticalRangeRect = marker;
        layoutPlotChildren();
    }

    public void resetverticalRect(Data<X,X> marker){
    	Objects.requireNonNull(marker, "the marker must not be null");
        if (marker.getNode() != null) {
            getPlotChildren().remove(marker.getNode());
            marker.setNode(null);
        }
        verticalRangeRect = null;
    }

    @Override
    protected void layoutPlotChildren() {
        super.layoutPlotChildren();
        for (Data<X, Y> horizontalMarker : horizontalMarkers) {
            Line line = (Line) horizontalMarker.getNode();
            line.setStartX(0);
            line.setEndX(getBoundsInLocal().getWidth());
            line.setStartY(getYAxis().getDisplayPosition(horizontalMarker.getYValue()) + 0.5); // 0.5 for crispness
            line.setEndY(line.getStartY());
            line.toFront();
        }
        for (Data<X, Y> verticalMarker : verticalMarkers) {
            Line line = (Line) verticalMarker.getNode();
            line.setStartX(getXAxis().getDisplayPosition(verticalMarker.getXValue()) + 0.5);  // 0.5 for crispness
            line.setEndX(line.getStartX());
            line.setStartY(0d);
            line.setEndY(getBoundsInLocal().getHeight());
            line.toFront();
        }
        for (Data<Y, Y> hroizontalRangeMarker : horizontalRangeMarkers) {
            Rectangle rectangle = (Rectangle) hroizontalRangeMarker.getNode();
            rectangle.setX(0d);  // 0.5 for crispness
            rectangle.setWidth(getBoundsInLocal().getWidth());
            rectangle.setY(getYAxis().getDisplayPosition(hroizontalRangeMarker.getYValue()) + 0.5);
            rectangle.setHeight(getYAxis().getDisplayPosition(hroizontalRangeMarker.getXValue()) - getYAxis().getDisplayPosition(hroizontalRangeMarker.getYValue()));
            rectangle.toBack();
        }
        for (Data<X, X> verticalRangeMarker : verticalRangeMarkers) {
            Rectangle rectangle = (Rectangle) verticalRangeMarker.getNode();
            rectangle.setX( getXAxis().getDisplayPosition(verticalRangeMarker.getXValue()) + 0.5);  // 0.5 for crispness
            rectangle.setWidth( getXAxis().getDisplayPosition(verticalRangeMarker.getYValue()) - getXAxis().getDisplayPosition(verticalRangeMarker.getXValue()));
            rectangle.setY(0d);
            rectangle.setHeight(getBoundsInLocal().getHeight());
            rectangle.toBack();
        }
        if(horizontalRangeRect != null){
        	Rectangle selRect = (Rectangle) horizontalRangeRect.getNode();
        	selRect.setX(0d);  // 0.5 for crispness
        	selRect.setWidth(getBoundsInLocal().getWidth());
        	selRect.setY(getYAxis().getDisplayPosition(horizontalRangeRect.getYValue()) + 0.5);
        	selRect.setHeight(getYAxis().getDisplayPosition(horizontalRangeRect.getXValue()) - getYAxis().getDisplayPosition(horizontalRangeRect.getYValue()));
        	selRect.toBack();
        }
        if(verticalRangeRect != null){
        	Rectangle selRect = (Rectangle) verticalRangeRect.getNode();
        	selRect.setX( getXAxis().getDisplayPosition(verticalRangeRect.getXValue()) + 0.5);  // 0.5 for crispness
        	selRect.setWidth( getXAxis().getDisplayPosition(verticalRangeRect.getYValue()) - getXAxis().getDisplayPosition(verticalRangeRect.getXValue()));
        	selRect.setY(0d);
        	selRect.setHeight(getBoundsInLocal().getHeight());
        	selRect.toBack();
        }

        if(horizontalLines != null){
        	Line horzLine = (Line) horizontalLines.getNode();
        	horzLine.setStartX(0);
        	horzLine.setEndX(getBoundsInLocal().getWidth());
        	horzLine.setStartY(getYAxis().getDisplayPosition(horizontalLines.getYValue()) + 0.5); // 0.5 for crispness
        	horzLine.setEndY(horzLine.getStartY());
        	horzLine.toFront();
        }
        if(verticalLines != null){
        	Line vertLine = (Line) verticalLines.getNode();
        	vertLine.setStartX(getXAxis().getDisplayPosition(verticalLines.getXValue()) + 0.5);  // 0.5 for crispness
        	vertLine.setEndX(vertLine.getStartX());
        	vertLine.setStartY(0d);
        	vertLine.setEndY(getBoundsInLocal().getHeight());
        	vertLine.toFront();
        }
    }
}
