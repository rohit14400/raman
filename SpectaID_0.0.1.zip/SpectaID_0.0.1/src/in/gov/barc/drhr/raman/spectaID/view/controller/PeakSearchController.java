package in.gov.barc.drhr.raman.spectaID.view.controller;

import in.gov.barc.drhr.raman.spectaID.Main;
import javafx.fxml.FXML;

public class PeakSearchController {
	private Main mainApp;

	public void setMainApp(Main mainApp){
		this.mainApp = mainApp;
	}

	@FXML private void initialize() {
    }
}
