package in.gov.barc.drhr.raman.spectaAcquire.spectrometer;

import java.util.List;

public interface Spectrometer {
	int initialize();
	boolean uninitialize();
	boolean isConnected();
	List<String> getDeviceListTest(int nDevices);
	List<String> getDeviceList(int nDevices);
	boolean connect(String serialNo);
	boolean disconnect();
	int getNoOfPixels();
	CMeasurementSettings readConfigFromDevice();
	int writeConfigToDevice(CMeasurementSettings deviceConfig);
	boolean isDataAvailable();
	boolean prepareMeasure(CMeasurementSettings settings);
	double[] getWavellength();
	double[] getSpectrumData(int[] a_pTimeLabel);
	boolean stopMeasure();
	char[] getSaturatedPixels();
	DetectorType getDetectorParams();
	String getLastError();
	boolean isLaserConnected();
	boolean laserOnOff(boolean isOff);
	boolean initializeLaser();
	boolean setLaserPower(int percent);
	int getLaserPower();
}
