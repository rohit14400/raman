package in.gov.barc.drhr.raman.spectaID.model.dao;

import java.util.List;

import in.gov.barc.drhr.raman.spectaID.model.Spectrum;

public class SpectrumDAOImpl implements ISpectrumDAO {

	@Override
	public List<Spectrum> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Spectrum> getByName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Spectrum> getById() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insertSpectrum(Spectrum spc) {
	    	return false;
	}
	@Override
	public boolean updateSpectrum(Spectrum spc) {
		return false;
	}

	@Override
	public boolean removeSpectrum(Spectrum spc) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean batchInsertSpectrum(List<Spectrum> spcList) {
		return false;
	}

}
