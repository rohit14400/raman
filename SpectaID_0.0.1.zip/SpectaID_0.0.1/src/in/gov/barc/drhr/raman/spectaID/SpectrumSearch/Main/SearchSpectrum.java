package in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections.CorrectionNames;
import in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections.HorizontalOffset;
import in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections.ICorrection;
import in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections.OptimizeCorrectionsThread;
import in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections.VerticalClipping;
import in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections.VerticalOffset;
import in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections.BaseLine.BaselineFactory;
import in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections.BaseLine.BaselineNames;
import in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections.BaseLine.IBaseLineCorrection;
import in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Distance.DistanceMetrics;
import in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Distance.SpectralDistanceFactory;
import in.gov.barc.drhr.raman.spectaID.model.SpectraDatabase;
import in.gov.barc.drhr.raman.spectaID.model.Spectrum;
import in.gov.barc.drhr.raman.spectaID.model.dao.ISpectraDatabaseDAO;
import in.gov.barc.drhr.raman.spectaID.model.dao.SpcDatabaseDAOImpl;

public class SearchSpectrum {
	private DistanceMetrics distanceMetric;
	private List<SpectraDatabase> dbList;
	private IBaseLineCorrection baselineObj;
	private List<ICorrection> spcCorrList = new ArrayList<>();
	private SpectralDistanceFactory distanceFact = SpectralDistanceFactory.createSpectralDistanceFactory();
	private AtomicBoolean isStopSearch = new AtomicBoolean();

	public void setDistanceMode(DistanceMetrics distaneMetric){
		this.distanceMetric = distaneMetric;
	}

	public void setSpectraLibrary(List<SpectraDatabase> dbList){
		this.dbList = dbList;
	}

	public void setBaselineCorrection(boolean status){
		if(status){
			BaselineFactory baselineFact = new BaselineFactory();
			baselineObj = baselineFact.getBaselineObj(BaselineNames.LINEAR);
		}else{
			baselineObj = null;
		}
	}

	public void setCorrections(Map<String,Boolean> corrNames){
		Iterator<Entry<String, Boolean>> mapIt = corrNames.entrySet().iterator();
		while(mapIt.hasNext()){
			Entry<String, Boolean> keyValue = mapIt.next();
			if(keyValue.getValue() && keyValue.getKey().compareTo(CorrectionNames.HORIZONTAL_OFFSET.toString()) == 0){
				spcCorrList.add(new HorizontalOffset());
			}else if(keyValue.getValue() && keyValue.getKey().compareTo(CorrectionNames.VERTICAL_OFFSET.toString()) == 0){
				spcCorrList.add(new VerticalOffset());
			}else if(keyValue.getValue() && keyValue.getKey().compareTo(CorrectionNames.VERTICAL_CLIPPING.toString()) == 0){
				spcCorrList.add(new VerticalClipping());
			}
		}
	}

	public List<HitSpectrum> getHitList(Spectrum unknowSpc,int hitListSize){
		List<HitSpectrum> hitList = new ArrayList<HitSpectrum>();
		ISpectraDatabaseDAO dbDAO = new SpcDatabaseDAOImpl();
		Iterator<SpectraDatabase> dbIt = dbList.iterator();
		ExecutorService executor = Executors.newFixedThreadPool(5);	//create a thread pool of 5 threads
		int i=0;
		long start = System.currentTimeMillis();
		while(dbIt.hasNext()){
			SpectraDatabase database = dbIt.next();
			long size = dbDAO.getSpectrumCount(database);
			//for(int offset=0;offset<=size;offset+=limit){
				List<Spectrum> spcList = database.getSpectrums(); //dbDAO.getSpcsFromDB(database, 0, limit);
				Iterator<Spectrum> spcIt = spcList.iterator();
				while(spcIt.hasNext()){
					Spectrum libSpc = spcIt.next();
					HitSpectrum spcHit = new HitSpectrum();
					spcHit.setSpc(libSpc);
					spcHit.setSpcDatabase(database);
					hitList.add(spcHit);
					Runnable optimizeCorrections = new OptimizeCorrectionsThread(spcCorrList, distanceFact.getSpectralDistance(distanceMetric),unknowSpc,spcHit);
					executor.execute(optimizeCorrections);
					i++;
					//System.out.println("Spectrum Count="+i);
					if(isStopSearch.get()) {
						break;
					}
				}
				executor.shutdown();
		        while (!executor.isTerminated()) {
		        	if(isStopSearch.get()) {
		        		executor.shutdownNow();
		        	}
		        }
				Collections.sort(hitList, Collections.reverseOrder(Comparator.comparing(HitSpectrum::getScore)));
				if(hitList.size() > 50){
					hitList = hitList.subList(0, hitListSize);
				}
				spcList = null;
				if(isStopSearch.get()) {
					break;
				}
				//}
		}
		long diff = System.currentTimeMillis() - start;
		System.out.println("Total Time spent="+diff);
		return hitList;
	}
	
	public void stopSearch() {
		isStopSearch.set(true);
	}
}
