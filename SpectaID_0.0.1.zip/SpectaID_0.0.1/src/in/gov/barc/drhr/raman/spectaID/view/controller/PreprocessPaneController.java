package in.gov.barc.drhr.raman.spectaID.view.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import in.gov.barc.drhr.raman.spectaID.Main;
import in.gov.barc.drhr.raman.spectaID.Preprocessing.PreprocessingTypes;
import in.gov.barc.drhr.raman.spectaID.Preprocessing.Denoising.DenoisingAlgo;
import in.gov.barc.drhr.raman.spectaID.Preprocessing.Denoising.DenoisingFactory;
import in.gov.barc.drhr.raman.spectaID.Preprocessing.Denoising.IFilter;
import in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections.BaseLine.BaselineFactory;
import in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections.BaseLine.BaselineNames;
import in.gov.barc.drhr.raman.spectaID.model.Point;
import in.gov.barc.drhr.raman.spectaID.model.Spectrum;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;

public class PreprocessPaneController {

	@FXML private TableView<String> preprocessTable;
	@FXML private TableColumn<String, String> stepNameCol;
	@FXML private TableColumn<String, Boolean> fixCol;
	@FXML private Button applyBtn;
	@FXML private Button resetBtn;
	@FXML private CheckBox showProcessBtn;
	private Map<String, Boolean> preprocessMap = new LinkedHashMap<String, Boolean>();
	private Main mainApp;

	public void setMainApp(Main mainApp){
		this.mainApp = mainApp;
	}

	@FXML private void initialize() {
		List<String> preprocessList = PreprocessingTypes.ALL.getPreprocessNames();
		for(String str:preprocessList){
			preprocessMap.put(str, false);
		}
		preprocessTable.getItems().addAll(preprocessList);

		fixCol.setCellValueFactory( new PropertyValueFactory<String,Boolean>( "checkBoxValue" ) );
		fixCol.setCellFactory(CheckBoxTableCell.forTableColumn(fixCol));
		fixCol.setCellValueFactory(new Callback<CellDataFeatures<String, Boolean>, ObservableValue<Boolean>>() {
            @Override
            public ObservableValue<Boolean> call(CellDataFeatures<String, Boolean> param) {
                String corrStr = param.getValue();
                SimpleBooleanProperty booleanProp = new SimpleBooleanProperty(preprocessMap.get(corrStr));
                // CheckBoxTableCell..
                booleanProp.addListener(new ChangeListener<Boolean>() {
                    @Override
                    public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue,
                            Boolean newValue) {
                    	preprocessMap.replace(corrStr, newValue);
                    }
                });
                return booleanProp;
            }
        });
		fixCol.setEditable(true);
		preprocessTable.setEditable(true);
		stepNameCol.setCellValueFactory(new Callback<CellDataFeatures<String, String>, ObservableValue<String>>() {
		     public ObservableValue<String> call(CellDataFeatures<String, String> p) {
		         return new SimpleStringProperty(p.getValue());
		     }
		  });
    }

	@FXML public void onBtnClickApply(){
		Iterator<Entry<String, Boolean>> preprocessIt = preprocessMap.entrySet().iterator();
		Spectrum unknownSpc = mainApp.getUnknownSpectrum();
		if(unknownSpc == null){

		}
		while(preprocessIt.hasNext()){
			Entry<String, Boolean> keyValue = preprocessIt.next();
			String key = keyValue.getKey();
			if(keyValue.getValue()){
				if(key.compareTo(PreprocessingTypes.DENOSING.toString()) == 0){
					DenoisingFactory factory = new DenoisingFactory();
					IFilter filterAlgo = factory.getDenoisingAlgo(DenoisingAlgo.SAVITZKY_GOLAY);
					unknownSpc.getCorrectedData().setYData(filterAlgo.smooth(unknownSpc.getCorrectedData().getYData()));
				}else if(key.compareTo(PreprocessingTypes.BASELINE.toString()) == 0){
					BaselineFactory factory = new BaselineFactory();
					factory.getBaselineObj(BaselineNames.LINEAR).correctSpectrum(unknownSpc, new ArrayList<Point<Double>>());
				}else if(key.compareTo(PreprocessingTypes.NORMALIZE.toString()) == 0){

				}else if(key.compareTo(PreprocessingTypes.BKGRND_SUBSTRACT.toString()) == 0){

				}
			}
		}
		showProcessBtn.setSelected(true);
		onBtnClickShowPreprocessSpc();
	}

	@FXML public void onBtnClickReset(){
		preprocessTable.getItems().clear();
		List<String> preprocessList = PreprocessingTypes.ALL.getPreprocessNames();
		for(String str:preprocessList){
			preprocessMap.put(str, false);
		}
		preprocessTable.getItems().addAll(preprocessList);
		if(mainApp.getUnknownSpectrum() != null){
			mainApp.getUnknownSpectrum().getCorrectedData().setYData(mainApp.getUnknownSpectrum().getOriginalData().getYData());
		}
	}

	@FXML public void onBtnClickShowPreprocessSpc(){
		mainApp.showProcessedSpecturm(showProcessBtn.isSelected());
	}
}
