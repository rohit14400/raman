package in.gov.barc.drhr.raman.spectaID.model.dao;

import java.io.File;
import java.util.List;

import in.gov.barc.drhr.raman.spectaID.model.SpectraDatabase;
import in.gov.barc.drhr.raman.spectaID.model.Spectrum;

public interface ISpectraDatabaseDAO {
	List<SpectraDatabase> getAll(File path);
	List<SpectraDatabase> getByName();
	List<SpectraDatabase> getById();
	boolean insertDatabase(SpectraDatabase spcDatabase);
	boolean updateDatabase(SpectraDatabase spcDatabase);
	boolean removeDatabase(SpectraDatabase spcDatabase);
	boolean addSPCsToDB(SpectraDatabase database,List<Spectrum> spcList);
	boolean removeSPCsFromDB(SpectraDatabase database,List<Spectrum> spcList);
	List<Spectrum> getSpcsFromDB(SpectraDatabase spcDatabase,int offset,int limit);
	Long getSpectrumCount(SpectraDatabase spcDatabase);
	void close();
}
