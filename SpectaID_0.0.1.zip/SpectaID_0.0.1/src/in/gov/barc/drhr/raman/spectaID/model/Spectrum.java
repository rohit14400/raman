package in.gov.barc.drhr.raman.spectaID.model;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.Serializable;

public class Spectrum implements Serializable{

	private static final long serialVersionUID = -3991765612435158600L;
	private String spectrumId;
	private String spectrumFormat;
	private String spectrumDescription;
	private String filePath;
	private boolean isBaselineCorrected = false;
	private Instrument instrument;
	private SpectrumData origData;
	private transient SpectrumData correctedData;
	private Compound compound;

	public String getSpectrumId() {
		return spectrumId;
	}

	public void setSpectrumId(String spectrumId) {
		this.spectrumId = spectrumId;
	}

	public String getSpectrumFormat() {
		return spectrumFormat;
	}

	public void setSpectrumFormat(String spectrumFormat) {
		this.spectrumFormat = spectrumFormat;
	}

	public String getSpectrumDescription() {
		return spectrumDescription;
	}

	public void setSpectrumDescription(String spectrumDescription) {
		this.spectrumDescription = spectrumDescription;
	}

	public void setFilePath(String filePath){
		this.filePath = filePath;
	}

	public String getFilePath(){
		return filePath;
	}

	public boolean isBaselineCorrected() {
		return isBaselineCorrected;
	}

	public void setBaselineCorrected(boolean isBaselineCorrected) {
		this.isBaselineCorrected = isBaselineCorrected;
	}

	public SpectrumData getOriginalData(){
		if(origData == null){
			origData = new SpectrumData();
		}
		return origData;
	}

	public SpectrumData getCorrectedData(){
		if(correctedData == null){
			correctedData = new SpectrumData();
			correctedData.copySpectrumData(origData);
		}
		return correctedData;
	}

	public Instrument getInstrument(){
		if(instrument == null){
			instrument = new Instrument();
		}
		return instrument;
	}

	public Compound getCompound(){
		if(compound == null){
			compound = new Compound();
		}
		return compound;
	}
	
	public boolean saveSpectrum(String fileName) {
		try (PrintWriter writer = new PrintWriter(fileName)) {
			for(int i=0;i<origData.getYData().length;i++) {
				 StringBuilder sb = new StringBuilder();
				 sb.append(origData.getXData()[i]);
				 sb.append(',');
				 sb.append(origData.getYData()[i]);
				 sb.append('\n');
				 writer.write(sb.toString());
			}
			writer.close();
			return true;
		}catch (FileNotFoundException e) {
		      System.out.println(e.getMessage());
		}
		
		return false;
	}
};
