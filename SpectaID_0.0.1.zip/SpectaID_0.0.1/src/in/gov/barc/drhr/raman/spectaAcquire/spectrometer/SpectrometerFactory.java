package in.gov.barc.drhr.raman.spectaAcquire.spectrometer;

public class SpectrometerFactory {
	private static Spectrometer spectrometer = null;
	
	private SpectrometerFactory() {
	
	}
	
	public static Spectrometer getSpectrometer() {
		if(spectrometer == null) {
			spectrometer = new AvantesSpectrometer();
			//spectrometer = new DummySpectrometer();
		}
		return spectrometer;
	}
}
