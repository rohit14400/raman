package in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Distance;

import java.util.Arrays;

import in.gov.barc.drhr.raman.spectaID.model.SpectrumData;

public class AbsoluteValue extends SpectralDistance {

	@Override
	public double getDistance(SpectrumData spcUnk, SpectrumData spcLib) {
		double[] xDataLib = spcLib.getXData();
		double absDistance = 0.0;
		int count = 0;
		double[] yUnkNormalized = normalizeData(spcUnk);
		double[] yLibNormalized = normalizeData(spcLib);

		calculateRange(spcUnk, spcLib);
		interpolate.interpolate(Arrays.copyOfRange(spcUnk.getXData(), startIdx, endIdx),
				Arrays.copyOfRange(yUnkNormalized, startIdx, endIdx));
		for(int i=0;i<xDataLib.length;i++){
			if(xDataLib[i] < xStart){
				continue;
			}
			if(xDataLib[i] > xEnd){
				break;
			}
			double currUnkVal = interpolate.getValue(xDataLib[i]);
			double currLibVal = yLibNormalized[i];
			absDistance += Math.abs(currLibVal - currUnkVal);
			count++;
		}
		return (1 - (absDistance / count)) * 100;
	}
}
