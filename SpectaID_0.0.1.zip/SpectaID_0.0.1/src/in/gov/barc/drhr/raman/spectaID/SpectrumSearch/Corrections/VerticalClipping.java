package in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections;

import in.gov.barc.drhr.raman.spectaID.model.SpectrumData;

public class VerticalClipping implements ICorrection{
	private double clipValue;

	private void clipVertically(SpectrumData spc){
		double[] yData = spc.getYData();
		for(int i=0;i<yData.length;i++){
			if(yData[i] > clipValue){
				yData[i] = clipValue;
			}
		}
	}

	@Override
	public void applyCorrection(SpectrumData spc) {
		clipVertically(spc);
	}

	@Override
	public void setCorrectionValues(double val){
		this.clipValue = val;
	}

	@Override
	public double[] getInitialInterval() {
		double[] interval = {0.3333, 0.4387, 0.7598, 0.9000, 1.0};
		return interval;
	}

	@Override
	public double getMinimumVal() {
		return (1/3);
	}

	@Override
	public double getCorrectionValue() {
		return clipValue;
	}
}
