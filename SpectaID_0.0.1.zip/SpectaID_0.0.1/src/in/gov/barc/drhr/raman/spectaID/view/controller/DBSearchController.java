package in.gov.barc.drhr.raman.spectaID.view.controller;

import java.io.File;
import java.util.List;

import in.gov.barc.drhr.raman.PropertiesService;
import in.gov.barc.drhr.raman.spectaID.Main;
import in.gov.barc.drhr.raman.spectaID.model.SpectraDatabase;
import in.gov.barc.drhr.raman.spectaID.model.dao.ISpectraDatabaseDAO;
import in.gov.barc.drhr.raman.spectaID.model.dao.SpcDatabaseDAOImpl;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.layout.VBox;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;

public class DBSearchController {
	@FXML private ComboBox<String> dbTypes;
	@FXML private TableView<SpectraDatabase> availableDBsTable;
	@FXML private TableView<SpectraDatabase> selectedDBsTable;
	@FXML private Button addAllDBBtn;
	@FXML private Button addDBBtn;
	@FXML private Button removeDBBtn;
	@FXML private Button removeAllBtn;
	@FXML private Button selectBtn;
	@FXML private TableColumn<SpectraDatabase, String> availNameCol;
	@FXML private TableColumn<SpectraDatabase, String> availIdCol;
	@FXML private TableColumn<SpectraDatabase, String> availVersionCol;

	@FXML private TableColumn<SpectraDatabase, String> selectNameCol;
	@FXML private TableColumn<SpectraDatabase, String> selectIdCol;
	@FXML private TableColumn<SpectraDatabase, String> selectVersionCol;

	private Stage dialogStage;
	private Main mainApp;
	private ISpectraDatabaseDAO dbDao = new SpcDatabaseDAOImpl();
	private List<SpectraDatabase> searchDBList;

	public void setDialogStage(Stage dialoStage){
		this.dialogStage = dialoStage;
	}

	public void setMainApp(Main mainApp){
		this.mainApp = mainApp;
	}

	@FXML private void initialize(){
		addAllDBBtn.setDisable(true);
		addDBBtn.setDisable(true);
		removeAllBtn.setDisable(true);
		removeDBBtn.setDisable(true);
		selectBtn.setDisable(true);
		dbTypes.getItems().addAll("None","Raman");
		dbTypes.getSelectionModel().selectFirst();
		dbTypes.valueProperty().addListener(new ChangeListener<String>() {
	        @Override public void changed(ObservableValue ov, String t, String t1) {
	        	availableDBsTable.getItems().clear();
	        	if(dbTypes.getSelectionModel().getSelectedItem() == "Raman") {
		        	File absolutePath = PropertiesService.getRamanDbPath().length() > 0? new File(PropertiesService.getRamanDbPath()):null;
		        	if(absolutePath == null) {
		            	DirectoryChooser fileChooser = new DirectoryChooser();
		        		fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));
		        		File chosenFile = fileChooser.showDialog(dialogStage);
		        		if(chosenFile == null) {
		        			return;
		        		}
		        		absolutePath = chosenFile;
		        	}
		        	final File dbPath = absolutePath;
		    		Task<List<SpectraDatabase>> fetchDbTask = new Task<List<SpectraDatabase>>() {
		    			@Override
		    			protected List<SpectraDatabase> call() throws Exception {
		    				return dbDao.getAll(dbPath);
		    			}
		    		};
		        	Stage progressStage = showProgressBar();
		    		fetchDbTask.setOnSucceeded(new EventHandler<WorkerStateEvent>() {
		    			@Override
		    			public void handle(WorkerStateEvent arg0) {
		    				progressStage.close();
		    				List<SpectraDatabase> spcDBList = fetchDbTask.getValue();
		    				if(spcDBList.size() > 0) {
			    				Platform.runLater(()->{
			    					availableDBsTable.getItems().addAll(FXCollections.observableArrayList(spcDBList));
			    		    		if(availableDBsTable.getItems().size() > 0){
			    		    			addAllDBBtn.setDisable(false);
			    		    		}
			    				});
		    				}
		    			}
		    		});
		    		
		    		new Thread(fetchDbTask).start();
		    		progressStage.showAndWait();
		        }
	        }
	      });

		availableDBsTable.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		selectedDBsTable.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

		availNameCol.setCellValueFactory(new Callback<CellDataFeatures<SpectraDatabase, String>, ObservableValue<String>>() {
		     public ObservableValue<String> call(CellDataFeatures<SpectraDatabase, String> p) {
		         return new SimpleStringProperty(p.getValue().getDbName());
		     }
		  });

		availIdCol.setCellValueFactory(new Callback<CellDataFeatures<SpectraDatabase, String>, ObservableValue<String>>() {
		     public ObservableValue<String> call(CellDataFeatures<SpectraDatabase, String> p) {
		         return new SimpleStringProperty(p.getValue().getDbId());
		     }
		  });

		availVersionCol.setCellValueFactory(new Callback<CellDataFeatures<SpectraDatabase, String>, ObservableValue<String>>() {
		     public ObservableValue<String> call(CellDataFeatures<SpectraDatabase, String> p) {
		         return new SimpleStringProperty(p.getValue().getDbVersion());
		     }
		  });

		availableDBsTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
		    if(availableDBsTable.getSelectionModel().getSelectedIndices().size() > 0){
		    	addDBBtn.setDisable(false);
		    }else{
		    	addDBBtn.setDisable(true);
		    }
		});

		selectNameCol.setCellValueFactory(new Callback<CellDataFeatures<SpectraDatabase, String>, ObservableValue<String>>() {
		     public ObservableValue<String> call(CellDataFeatures<SpectraDatabase, String> p) {
		         return new SimpleStringProperty(p.getValue().getDbName());
		     }
		  });

		selectIdCol.setCellValueFactory(new Callback<CellDataFeatures<SpectraDatabase, String>, ObservableValue<String>>() {
		     public ObservableValue<String> call(CellDataFeatures<SpectraDatabase, String> p) {
		         return new SimpleStringProperty(p.getValue().getDbId());
		     }
		  });

		selectVersionCol.setCellValueFactory(new Callback<CellDataFeatures<SpectraDatabase, String>, ObservableValue<String>>() {
		     public ObservableValue<String> call(CellDataFeatures<SpectraDatabase, String> p) {
		         return new SimpleStringProperty(p.getValue().getDbVersion());
		     }
		  });

		selectedDBsTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
			if(selectedDBsTable.getSelectionModel().getSelectedIndices().size() > 0){
				removeDBBtn.setDisable(false);
			}else{
				removeDBBtn.setDisable(true);
			}
		});
	}

	@FXML public void onBtnClickAddAllDB(){
		selectedDBsTable.getItems().clear();
		selectedDBsTable.getItems().addAll(availableDBsTable.getItems());
		removeAllBtn.setDisable(false);
		selectBtn.setDisable(false);
	}

	@FXML public void onBtnClickAddDB(){
		if(availableDBsTable.getSelectionModel().getSelectedItems().size() > 0){
			selectedDBsTable.getItems().addAll(availableDBsTable.getSelectionModel().getSelectedItems());
			removeAllBtn.setDisable(false);
			selectBtn.setDisable(false);
		}
	}

	@FXML public void onBtnClickRemoveDB(){
		selectedDBsTable.getItems().remove(selectedDBsTable.getSelectionModel().getSelectedIndex());
		if(selectedDBsTable.getItems().size() == 0){
			removeAllBtn.setDisable(true);
			removeDBBtn.setDisable(true);
			selectBtn.setDisable(true);
		}else if(selectedDBsTable.getSelectionModel().getSelectedItems().size() == 0){
			removeDBBtn.setDisable(true);
		}
	}

	@FXML public void onBtnClickRemoveAllDB(){
		selectedDBsTable.getItems().clear();
		removeAllBtn.setDisable(true);
		removeDBBtn.setDisable(true);
		selectBtn.setDisable(true);
	}

	@FXML public void onBtnClickRefresh(){

	}

	@FXML public void onBtnClickSelect(){
		searchDBList = selectedDBsTable.getItems().subList(0, selectedDBsTable.getItems().size());
		dbDao.close();
		mainApp.setSpectrumLibrary(searchDBList);
		dialogStage.close();
	}

	@FXML public void onBtnClickCancel(){
		dbDao.close();
		dialogStage.close();
	}

	public List<SpectraDatabase> getSearchableDBList(){
		return searchDBList;
	}

	@FXML public void onBtnClickSelectByBrowsing(){
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Select database");
		fileChooser.setInitialDirectory(
			new File(System.getProperty("user.home")));
			fileChooser.getExtensionFilters().addAll(
			new FileChooser.ExtensionFilter("All Files", "*.*")
			);
		List<File> files = fileChooser.showOpenMultipleDialog(dialogStage);
		if(files == null){
			return;
		}
		for(File currentfile:files){
			System.out.println(currentfile.getName());
		}
	}
	
	private Stage showProgressBar() {
		ProgressBar bar = new ProgressBar();
		Button stopButton = new Button("Stop");
		stopButton.setPrefWidth(80);
		stopButton.setPrefHeight(25);
		VBox vbox = new VBox(bar, stopButton);
		vbox.setAlignment(Pos.CENTER);
		vbox.setSpacing(10.0);
		bar.prefWidthProperty().bind(vbox.widthProperty());
//		stopButton.setOnAction(new EventHandler<ActionEvent>() {
//			@Override
//			public void handle(ActionEvent arg0) {
//				stopSearchTask();
//			}
//		});
		Stage stage = new Stage();
		stage.setScene(new Scene(vbox));
		stage.setTitle("Loading database...");
		stage.setHeight(100);
		stage.setWidth(400);
		stage.setResizable(false);
		stage.initOwner(dialogStage);
		stage.initModality(Modality.APPLICATION_MODAL);
		return stage;
	}
}
