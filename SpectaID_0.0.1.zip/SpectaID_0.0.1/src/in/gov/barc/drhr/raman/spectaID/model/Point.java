package in.gov.barc.drhr.raman.spectaID.model;

import java.io.Serializable;

public class Point<T> implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -2279725131997295171L;
	private T x;
	private T y;

	public Point(T x,T y) {
		this.x = x;
		this.y = y;
	}

	public T getX(){
		return x;
	}

	public T getY(){
		return y;
	}

	public void setX(T x){
		this.x = x;
	}

	public void setY(T y){
		this.y = y;
	}
}
