package in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Main;

import java.util.ArrayList;
import java.util.List;

import in.gov.barc.drhr.raman.spectaID.model.SpectraDatabase;
import in.gov.barc.drhr.raman.spectaID.model.Spectrum;

public class HitSpectrum {
	private Spectrum spc;
	private double score;
	private SpectraDatabase spcDatabase;
	private List<HitSpectrum> hitSpcList = new ArrayList<HitSpectrum>();
	private double weight;
	private String spcId;

	public Spectrum getSpc() {
		return spc;
	}

	public void setSpc(Spectrum spc) {
		this.spc = spc;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

	public SpectraDatabase getSpcDatabase() {
		return spcDatabase;
	}

	public void setSpcDatabase(SpectraDatabase spcDatabase) {
		this.spcDatabase = spcDatabase;
	}

	public void addCompositeHitSpectrum(HitSpectrum spcHit){
		hitSpcList.add(spcHit);
	}

	public List<HitSpectrum> getCompositeSpectrum(){
		return hitSpcList;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public void setSpectrumId(String id){
		spcId = id;
	}

	public String getSpectrumId(){
		return spcId;
	}
}
