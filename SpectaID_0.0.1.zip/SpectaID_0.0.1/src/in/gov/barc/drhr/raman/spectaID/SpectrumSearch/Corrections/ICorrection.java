package in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections;

import in.gov.barc.drhr.raman.spectaID.model.SpectrumData;

public interface ICorrection {
	public void applyCorrection(SpectrumData spc);
	public void setCorrectionValues(double val);
	public double getCorrectionValue();
	public double[] getInitialInterval();
	public double getMinimumVal();
}
