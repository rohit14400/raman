package in.gov.barc.drhr.raman.spectaID.view.controller;

import in.gov.barc.drhr.raman.spectaID.Main;
import in.gov.barc.drhr.raman.spectaID.model.Spectrum;
import in.gov.barc.drhr.raman.spectaID.view.util.LineXYChart;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Point2D;
import javafx.scene.Node;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.ToolBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

public class SpectrumViewController {
	@FXML private ToggleGroup selGroup;
	@FXML private ToggleButton btnSelection;
	@FXML private ToggleButton btnHorzZoom;
	@FXML private ToggleButton btnVertZoom;
	@FXML private ToggleButton btnPanMode;
	@FXML private ToggleButton btnViewOriginal;
	@FXML private ToggleGroup peakGroup;
	@FXML private ToggleButton btnShowPeaksAll;
	@FXML private ToggleButton btnShowPeaksActive;
	@FXML private ToggleGroup spectraviewGroup;
	@FXML private ToggleButton btnOverlaySpectra;
	@FXML private ToggleButton btnStackedSpectra;
	@FXML private Button btnFlipXAxis;
	@FXML private VBox chartBox;
	@FXML private ToolBar toolBar;

	private enum eModes { NONE, SELECTION, HORZ_ZOOM, VERT_ZOOM, PANE, ORIGINAL };
	private enum eDisplayMode { STACKED, OVERLAY, OFFSET };

	private eModes modeState;
	private double rangeEnd1,rangeEnd2;
	private Data<Number, Number> data = null;
	private Main mainApp;
	private double xMin,xMax,yMin,yMax;
	private double oldX = 0.0;
	ObservableList<XYChart.Series<Number, Number>> seriesList;
	ObservableList<Spectrum> spectList;
	private eDisplayMode displayMode = eDisplayMode.OVERLAY;
	
	 /**
     * The constructor.
     * The constructor is called before the initialize() method.
     */
    public SpectrumViewController() {
    	modeState = eModes.SELECTION;
    	displayMode = eDisplayMode.OVERLAY;
    	rangeEnd1 = rangeEnd2 = 0.0;
    	xMin = yMin = Double.POSITIVE_INFINITY;
    	yMax = xMax = Double.NEGATIVE_INFINITY;
    }

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
    	try{
    		Image image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/cursor.png"));
    		btnSelection.setGraphic(new ImageView(image));
    		image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/spcHorzZoom.png"));
    		btnHorzZoom.setGraphic(new ImageView(image));
    		image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/spcVertZoom.png"));
    		btnVertZoom.setGraphic(new ImageView(image));
    		image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/spcFlipAxis.png"));
    		btnFlipXAxis.setGraphic(new ImageView(image));
    		image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/spcPane.png"));
    		btnPanMode.setGraphic(new ImageView(image));
    		image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/spcNormal.png"));
    		btnOverlaySpectra.setGraphic(new ImageView(image));
    		image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/spcStacked.png"));
    		btnStackedSpectra.setGraphic(new ImageView(image));
    		image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/spcNormal.png"));
    		btnViewOriginal.setGraphic(new ImageView(image));
    		image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/spcPeakAll.png"));
    		btnShowPeaksAll.setGraphic(new ImageView(image));
    		image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/spcPeakActive.png"));
    		btnShowPeaksActive.setGraphic(new ImageView(image));
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	seriesList = FXCollections.observableArrayList();
    	spectList = FXCollections.observableArrayList();

    	seriesList.addListener(new ListChangeListener<XYChart.Series<Number,Number>>() {
			@Override
			public void onChanged(javafx.collections.ListChangeListener.Change<? extends Series<Number, Number>> arg0) {
				boolean listAddState = false;
				while(arg0.next()){
					if(arg0.wasAdded() || arg0.wasRemoved()){
						listAddState = true;
						break;
					}
				}
				if(listAddState){
					displayLineCharts();
				}
			}
    	 });

    	selGroup.selectedToggleProperty().addListener(
                new ChangeListener<Toggle>() {
                    public void changed(ObservableValue<? extends Toggle> ov,
                            Toggle oldToggle, Toggle newToggle) {
                        if (null == newToggle){
                            selGroup.selectToggle(oldToggle);
                        }
                    }
                });
    	peakGroup.selectedToggleProperty().addListener(
                new ChangeListener<Toggle>() {
                    public void changed(ObservableValue<? extends Toggle> ov,
                            Toggle oldToggle, Toggle newToggle) {
                        if (null == newToggle)
                           peakGroup.selectToggle(oldToggle);
                    }
                });
    	spectraviewGroup.selectedToggleProperty().addListener(
                new ChangeListener<Toggle>() {
                    public void changed(ObservableValue<? extends Toggle> ov,
                            Toggle oldToggle, Toggle newToggle) {
                        if (null == newToggle)
                            spectraviewGroup.selectToggle(oldToggle);
                    }
                });
    	toolBar.setDisable(true);
    	selGroup.selectToggle(btnSelection);
    	peakGroup.selectToggle(btnShowPeaksAll);
    	spectraviewGroup.selectToggle(btnOverlaySpectra);
    }
    /**
     * Is called by the main application to give a reference back to itself.
     *
     * @param mainApp
     */
    public void setMainApp(Main mainApp) {
        this.mainApp = mainApp;
    }

    public void clearData(){
    	spectList.clear();
    	seriesList.clear();
    	xMin = yMin = Double.POSITIVE_INFINITY;
    	yMax = xMax = Double.NEGATIVE_INFINITY;
    }

    public void addSpectrumData(Spectrum unknownSpect,boolean isViewProcessed, boolean isClear){
    	double yData[] = isViewProcessed?unknownSpect.getCorrectedData().getYData():unknownSpect.getOriginalData().getYData();
    	if(yData == null){
    		Alert errDlg = new Alert(AlertType.ERROR);
    		errDlg.setTitle("Spectrum Data error");
    		errDlg.setHeaderText("Processed Spectrum data not found");
    		errDlg.showAndWait();
    		return;
    	}
		toolBar.setDisable(false);
   	 	//creating the chart
    	XYChart.Series<Number, Number> series = new XYChart.Series<Number, Number>();
    	series.setName(unknownSpect.getCompound().getCompoundName());
    	double xData[] = isViewProcessed?unknownSpect.getCorrectedData().getXData():unknownSpect.getOriginalData().getXData();
    	for(int i=0;i<xData.length;i++){
    		series.getData().add(new XYChart.Data<Number,Number>(xData[i],yData[i]));
    		if(xData[i] < xMin) xMin = xData[i];
    		if(xData[i] > xMax) xMax = xData[i];
    		if(yData[i] < yMin) yMin = yData[i];
    		if(yData[i] > yMax) yMax = yData[i];
    	}
    	if(isClear) {
    		spectList.clear();
        	seriesList.clear();
    	}
	   	spectList.add(unknownSpect); //mind the sequence
	   	seriesList.add(series);
    }

    public void removeSpectrumData(Spectrum unknownSpect){
    	int idx = spectList.indexOf(unknownSpect);
    	if(idx == -1){
    		return;
    	}
    	spectList.remove(unknownSpect);
    	seriesList.remove(idx);
    }

    private LineXYChart<Number, Number> createSpectrumGraph(Spectrum spectrum,XYChart.Series<Number, Number> series){
    	NumberAxis xAxis = new NumberAxis(xMin,xMax,1.0);
        NumberAxis yAxis = new NumberAxis(yMin,yMax,1.0);
       // xAxis.setLabel(spectrum.getxUnit());
       // yAxis.setLabel(spectrum.getyUnit());
        LineXYChart<Number, Number> unknownSpec = new LineXYChart<>(xAxis, yAxis);
        unknownSpec.setCreateSymbols(false);
        unknownSpec.setPrefHeight(606.0);
        unknownSpec.setPrefWidth(897.0);
        if(series != null){
        	unknownSpec.getData().add(series);
        }
        setChartEventHandlers(unknownSpec);
    	return unknownSpec;
    }

    private void displayLineCharts(){
    	if(spectList.size() != seriesList.size()){
    		Alert alrt = new Alert(AlertType.ERROR);
    		alrt.setTitle("Spectrum Display Error");
    		alrt.setHeaderText("Report Bug");
    		alrt.setContentText("Data mismatch occured between Spectrum List and Series List..");
    		return;
    	}
    	switch (displayMode) {
		case STACKED:
			chartBox.getChildren().clear();
			for(int i=0;i<spectList.size();i++){
				LineXYChart<Number, Number> specChart = createSpectrumGraph(spectList.get(i),seriesList.get(i));
		    	chartBox.getChildren().add(specChart);
			}
			break;
		case OVERLAY:
			if(spectList.size() > 0){
				LineXYChart<Number, Number> specChart = createSpectrumGraph(spectList.get(0),null);	//always consider first as unknown spect
				double xUnit = calculateAutoRange(xMin,xMax,15);
	         	double newXMin = xUnit * Math.floor(xMin / xUnit); double newXMax = xUnit * Math.ceil(1 + xMax/xUnit);
				Platform.runLater(()->{
					chartBox.getChildren().clear();
					specChart.getData().addAll(seriesList);
					VBox.setVgrow(specChart, Priority.ALWAYS);
					NumberAxis xAxis = (NumberAxis) specChart.getXAxis();
		        	xAxis.setTickUnit(xUnit);
		        	xAxis.setLowerBound(newXMin); //xAxis.setUpperBound(newXMax);
			    	chartBox.getChildren().add(specChart);
				});
			}
			break;
		default:
			break;
		}
    	setXAxisRange(xMin, xMax);
     	setYAxisRange(yMin, yMax);
    }

    @FXML public void onBtnClickSelection(){
    	modeState = eModes.SELECTION;
    }

    @FXML public void onBtnClickHorzZoom(){
    	modeState = eModes.HORZ_ZOOM;
    }

    @FXML public void onBtnClickVertZoom(){
    	modeState = eModes.VERT_ZOOM;
    }

    @FXML public void onBtnClickStackedSpectra(){
    	if(displayMode == eDisplayMode.STACKED){
    		return;
    	}
    	displayMode = eDisplayMode.STACKED;
    	displayLineCharts();
    }

    @FXML public void onBtnClickOverlaySpectra(){
    	if(displayMode == eDisplayMode.OVERLAY){
    		return;
    	}
    	displayMode = eDisplayMode.OVERLAY;
    	displayLineCharts();
    }

    @FXML public void onBtnClickPeaksAll(){

    }

    @FXML public void onBtnClickPeaksActive(){

    }

   public void onLButtonClick(MouseEvent event,LineXYChart<Number, Number> spec){
    	Point2D mouseSceneCoords = new Point2D(event.getSceneX(), event.getSceneY());
    	double x = spec.getXAxis().sceneToLocal(mouseSceneCoords).getX();
    	double y = spec.getYAxis().sceneToLocal(mouseSceneCoords).getY();
    	oldX = x;
    	switch(modeState){
    	case HORZ_ZOOM:
    		rangeEnd1 = (double) spec.getXAxis().getValueForDisplay(x);
    		break;
    	case VERT_ZOOM:
    		rangeEnd1 = (double) spec.getYAxis().getValueForDisplay(y);
    		break;
		default:
			break;
    	}
    }

    public void onMouseDragged(MouseEvent event,LineXYChart<Number, Number> spec){
    	Point2D mouseSceneCoords = new Point2D(event.getSceneX(), event.getSceneY());
    	NumberAxis xAxis = (NumberAxis)spec.getXAxis();
    	NumberAxis yAxis = (NumberAxis)spec.getYAxis();
    	double x = xAxis.sceneToLocal(mouseSceneCoords).getX();
    	double y = yAxis.sceneToLocal(mouseSceneCoords).getY();
    	double delta = 0.0;
    	if((x - oldX) < 0){
    		delta = Math.floor(xAxis.getTickUnit() / 20);
    	}else{
    		delta = -Math.floor(xAxis.getTickUnit() / 20);
    	}
    	switch (modeState) {
		case HORZ_ZOOM:
		case VERT_ZOOM:
			drawSelRectangle(x,y,spec);
			break;
		case PANE:
			xAxis.setLowerBound(xAxis.getLowerBound() + delta); xAxis.setUpperBound(xAxis.getUpperBound() + delta);
			break;
		default:
			break;
		}
    }

    public void onLButtonRelease(MouseEvent event,LineXYChart<Number, Number> spec){
    	NumberAxis xAxis = (NumberAxis)spec.getXAxis();
    	NumberAxis yAxis = (NumberAxis)spec.getYAxis();
    	Point2D mouseSceneCoords = new Point2D(event.getSceneX(), event.getSceneY());
    	double x = xAxis.sceneToLocal(mouseSceneCoords).getX();
    	double y = yAxis.sceneToLocal(mouseSceneCoords).getY();
    	if(data != null){
    		spec.resetverticalRect(data);
    		spec.resetHorizontalRect(data);
    	}
    	switch(modeState){
    	case HORZ_ZOOM:
    		rangeEnd2 = (double) xAxis.getValueForDisplay(x);
    		if(rangeEnd1 > rangeEnd2){
       			setXAxisRange(rangeEnd2, rangeEnd1);
    		}else{
    			setXAxisRange(rangeEnd1, rangeEnd2);
    		}
   			break;
    	case VERT_ZOOM:
    		rangeEnd2 = (double) yAxis.getValueForDisplay(y);
    		if(rangeEnd1 > rangeEnd2){
    			setYAxisRange(rangeEnd2, rangeEnd1);
    		}else{
    			setYAxisRange(rangeEnd1, rangeEnd2);
    		}
    		break;
		default:
			break;
    	}
    }

    private void setChartEventHandlers(LineXYChart<Number, Number> unknownSpec){
    	unknownSpec.setOnMousePressed(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent e) {
            	onLButtonClick(e,unknownSpec);
              }
            });
    	unknownSpec.setOnMouseDragged(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent e) {
            	onMouseDragged(e,unknownSpec);
              }
            });
    	unknownSpec.setOnMouseReleased(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent e) {
            	onLButtonRelease(e,unknownSpec);
              }
            });
    }

    private void drawSelRectangle(double x,double y,LineXYChart<Number, Number> unknownSpec){
    	NumberAxis xAxis = (NumberAxis)unknownSpec.getXAxis();
    	NumberAxis yAxis = (NumberAxis)unknownSpec.getYAxis();
    	if(data != null){
    		unknownSpec.resetverticalRect(data);
    		unknownSpec.resetHorizontalRect(data);
    	}
    	switch(modeState){
    	case HORZ_ZOOM:
    		rangeEnd2 = (double) xAxis.getValueForDisplay(x);
   			data = (rangeEnd2 > rangeEnd1)?new Data<>(rangeEnd1,rangeEnd2):new Data<>(rangeEnd2,rangeEnd1);
   			unknownSpec.setVerticalRect(data);
   			break;
    	case VERT_ZOOM:
    		rangeEnd2 = (double) yAxis.getValueForDisplay(y);
    		data = (rangeEnd2 > rangeEnd1)?new Data<>(rangeEnd1,rangeEnd2):new Data<>(rangeEnd2,rangeEnd1);
    		unknownSpec.setHorizontalRect(data);
    		break;
		default:
			break;
    	}
    }

    @FXML public void onBtnClickViewOrig(){
    	modeState = eModes.ORIGINAL;
    	setXAxisRange(xMin, xMax);
    	setYAxisRange(yMin, yMax);
    }

    @FXML public void onBtnClickPaneMode(){
    	modeState = eModes.PANE;
    }

    @FXML public void onBtnClickFlipXAxis(){
    	ObservableList<Node> specList = chartBox.getChildren();
    	for(Node node:specList){
    		LineXYChart<Number, Number> unknownSpec = (LineXYChart<Number, Number>)node;
        	NumberAxis xAxis = (NumberAxis)unknownSpec.getXAxis();
        	double temp = xAxis.getLowerBound();
        	xAxis.setLowerBound(xAxis.getUpperBound()); xAxis.setUpperBound(temp); //need to reolve the bug of not getting grid lines and related issues like zooming
    	}
    }

    private double calculateAutoRange(double lBound,double uBound,int nTicks){
    	if(lBound == uBound){
    		lBound -= 10;
    		uBound += 10;
    	}
    	if(nTicks < 2){
    		nTicks = 2;
    	}else{
    		nTicks -= 1;
    	}
    	double range = Math.abs(uBound - lBound);
    	double tempTickSize = range /nTicks;
    	double pow10x = Math.pow(10, Math.ceil(Math.log10(tempTickSize)-1));
    	double tickUnit = Math.ceil(tempTickSize / pow10x) * pow10x;
    	return tickUnit;
    }

    private void setXAxisRange(double xMin,double xMax){
    	ObservableList<Node> specList = chartBox.getChildren();
    	for(Node node:specList){
    		LineXYChart<Number, Number> unknownSpec = (LineXYChart<Number, Number>)node;
        	NumberAxis xAxis = (NumberAxis)unknownSpec.getXAxis();
        	double xUnit = calculateAutoRange(xMin,xMax,15);
         	double newXMin = xUnit * Math.floor(xMin / xUnit); double newXMax = xUnit * Math.ceil(1 + xMax/xUnit);
        	xAxis.setTickUnit(xUnit);
        	xAxis.setLowerBound(newXMin); xAxis.setUpperBound(newXMax);
    	}
    }

    private void setYAxisRange(double yMin,double yMax){
    	ObservableList<Node> specList = chartBox.getChildren();
    	for(Node node:specList){
    		LineXYChart<Number, Number> unknownSpec = (LineXYChart<Number, Number>)node;
    		NumberAxis yAxis = (NumberAxis)unknownSpec.getYAxis();
           	double yUnit = calculateAutoRange(yMin,yMax,10);
        	double newYMin = yUnit * Math.floor(yMin / yUnit); double newYMax = yUnit * Math.ceil(1 + yMax/yUnit);
        	yAxis.setTickUnit(yUnit);
        	yAxis.setLowerBound(newYMin); yAxis.setUpperBound(newYMax);
    	}
    }
}
