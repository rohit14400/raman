package in.gov.barc.drhr.raman.spectaAcquire.spectrometer.ui;

import in.gov.barc.drhr.raman.spectaAcquire.spectrometer.CMeasurementSettings;
import in.gov.barc.drhr.raman.spectaAcquire.spectrometer.Spectrometer;
import in.gov.barc.drhr.raman.spectaAcquire.spectrometer.SpectrometerFactory;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Spinner;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.SpinnerValueFactory.DoubleSpinnerValueFactory;
import javafx.scene.control.SpinnerValueFactory.IntegerSpinnerValueFactory;
import javafx.stage.Stage;

public class SpectaAcquireController {
	@FXML private Spinner<Double> integrationTimeSpinner;
	@FXML private Spinner<Integer> nAvgsSpinner;
	@FXML private Spinner<Integer> smoothingSpinner;
	@FXML private Spinner<Integer> laserPowerSpinner;
	//
	private Stage dialogStage;
	
	public void setDialogStage(Stage dialogStage) {
		this.dialogStage = dialogStage;
	}
	
	@FXML private void initialize() {
		DoubleSpinnerValueFactory intTimeFactory = new DoubleSpinnerValueFactory(0, 30000, 1);
		integrationTimeSpinner.setValueFactory(intTimeFactory);
		IntegerSpinnerValueFactory avgsFactory = new IntegerSpinnerValueFactory(0, 10, 1);
		nAvgsSpinner.setValueFactory(avgsFactory);
		IntegerSpinnerValueFactory smoothingFactory = new IntegerSpinnerValueFactory(0, 10, 1);
		smoothingSpinner.setValueFactory(smoothingFactory);
		IntegerSpinnerValueFactory laserPowerFactory = new IntegerSpinnerValueFactory(0, 100, 10, 10);
		laserPowerSpinner.setValueFactory(laserPowerFactory);

	}
	
	@FXML private void onBtnClickSaveSettings() {
		Spectrometer spectrometer = SpectrometerFactory.getSpectrometer();
		if(spectrometer != null) {
			CMeasurementSettings measurementSettings = spectrometer.readConfigFromDevice();
			measurementSettings.setIntegrationTime(integrationTimeSpinner.getValue());
			measurementSettings.setNrAverages(nAvgsSpinner.getValue());
			measurementSettings.setSmoothPix(smoothingSpinner.getValue());
			spectrometer.writeConfigToDevice(measurementSettings);
			//for laser power
			spectrometer.setLaserPower(laserPowerSpinner.getValue());
		}else {
			Alert alert = new Alert(AlertType.ERROR);
			alert.initOwner(dialogStage);
			alert.setTitle("Save measurement settings");
			alert.setHeaderText("No spectrometer found!!!");
			alert.showAndWait();
		}
	}
}
