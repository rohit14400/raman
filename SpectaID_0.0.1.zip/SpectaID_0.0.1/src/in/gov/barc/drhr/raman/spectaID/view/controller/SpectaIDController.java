package in.gov.barc.drhr.raman.spectaID.view.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import in.gov.barc.drhr.raman.spectaAcquire.spectrometer.Spectrometer;
import in.gov.barc.drhr.raman.spectaAcquire.spectrometer.SpectrometerFactory;
import in.gov.barc.drhr.raman.spectaAcquire.spectrometer.ui.SpectaAcquireController;
import in.gov.barc.drhr.raman.spectaID.Main;
import in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Main.HitSpectrum;
import in.gov.barc.drhr.raman.spectaID.model.Spectrum;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TitledPane;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;

public class SpectaIDController {
	@FXML private Button btnOpen;
	@FXML private VBox centerSpcViewPane;
	@FXML private Accordion accrPane;
	@FXML private TabPane searchTabs;
	@FXML private Button settingsButton;
	private Main mainApp;
	private SpectrumViewController specViewController;
	//spectrometer functions
	@FXML private Button startAcqButton;
	@FXML private Button stopAcqButton;
	@FXML private Button singleAcqButton;
	@FXML private ToggleButton signalDarkButton;
	@FXML private Button saveDarkBtn; 
	@FXML private Button saveSpectrumButton;
	@FXML private ToggleButton laserOnOffButton;
	@FXML private ToggleButton spectrometerOnOffButton;
	private double[] darkSpectrum;
	private ScheduledExecutorService spectrumPoller;
	private Spectrum displaySpectrum = new Spectrum();
	private AtomicBoolean isSignalDarkEnable = new AtomicBoolean();
	private SpectaAcquireController spectaAcquireController;
	//end
	@FXML private BorderPane rootPane;
	 /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
    	Image image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/open.png"));
		btnOpen.setGraphic(new ImageView(image));
		image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/settings.png"));
		settingsButton.setGraphic(new ImageView(image));
    	//rootPane.setCenter(loadSpectrumView());
		centerSpcViewPane.getChildren().add(loadSpectrumView());
    	initializeSpectrometerCtrls();
    }

	//member functions
	@FXML private void handleOpenButton(){
		openSpecParamsDlg();
	}
	
	private void initializeSpectrometerCtrls() {
		Image image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/start.png"));
		startAcqButton.setGraphic(new ImageView(image));
		image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/stop.png"));
		stopAcqButton.setGraphic(new ImageView(image));
		image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/save.png"));
		saveSpectrumButton.setGraphic(new ImageView(image));
		image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/singleSpec.png"));
		singleAcqButton.setGraphic(new ImageView(image));
		image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/dark.png"));
		saveDarkBtn.setGraphic(new ImageView(image));
		image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/spectrometer.png"));
		spectrometerOnOffButton.setGraphic(new ImageView(image));
		image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/laser.png"));
		laserOnOffButton.setGraphic(new ImageView(image));
		startAcqButton.setDisable(true);
		stopAcqButton.setDisable(true);
		laserOnOffButton.setDisable(true);
		disableSpectrometerAcqButtons(true);
	}

	public void showProcessedSpectrum(Spectrum spc,boolean isView){
		specViewController.removeSpectrumData(spc);
		specViewController.addSpectrumData(spc, isView, false);
	}

	public void setMainApp(Main mainApp){
		this.mainApp = mainApp;
		//mind the sequence
    	loadSpectometerSettingsPanel();
    	loadPreprocessingPane();
    	loadDatabaseOptionsPane();
    	loadFullSpcSearchPane();
    	loadPeakSearchPane();
    	accrPane.setExpandedPane(accrPane.getPanes().get(0));
	}
	
	@FXML
	private boolean onBtnClickConnectSpectrometer() {
		Spectrometer spectrometer = SpectrometerFactory.getSpectrometer();
		List<String> ls = spectrometer.getDeviceListTest(1);
		if(spectrometer != null) {
			if(spectrometerOnOffButton.isSelected()) {
				if(!spectrometer.isConnected()) {
					int nDevices = spectrometer.initialize();
					if(nDevices > 0) {
						List<String> connectedDevices = spectrometer.getDeviceList(nDevices);
						if(!spectrometer.connect(connectedDevices.get(0))) {
							Alert errAlert = new Alert(AlertType.ERROR);
							errAlert.setTitle("Connect to spectrometer");
							errAlert.setHeaderText("Couldn't connect to spectrometer!!");
							errAlert.setContentText(spectrometer.getLastError());
							errAlert.initOwner(mainApp.getPrimaryStage());
							errAlert.showAndWait();
							spectrometerOnOffButton.setSelected(false);
							return false;
						}
						//initialize laser
						if(!spectrometer.initializeLaser()) {
							Alert errAlert = new Alert(AlertType.ERROR);
							errAlert.setTitle("Connect to spectrometer");
							errAlert.setHeaderText("Laser initialization failed!!");
							errAlert.setContentText(spectrometer.getLastError());
							errAlert.initOwner(mainApp.getPrimaryStage());
							errAlert.showAndWait();
							return false;
						}
						laserOnOffButton.setDisable(false);
						startAcqButton.setDisable(false);
					}else {
						Alert errAlert = new Alert(AlertType.ERROR);
						errAlert.setTitle("Connect to spectrometer");
						errAlert.setHeaderText("No spectrometer found!!");
						//errAlert.setContentText(spectrometer.getLastError());
						errAlert.initOwner(mainApp.getPrimaryStage());
						errAlert.showAndWait();
						spectrometerOnOffButton.setSelected(false);
						return false;
					}
				}
				return true;
			}else {
				if(spectrometer.isConnected()) {
					if(!spectrometer.disconnect()) {
						Alert errAlert = new Alert(AlertType.ERROR);
						errAlert.setTitle("Disconnect from spectrometer");
						errAlert.setHeaderText("Couldn't disconnect from spectrometer!!");
						errAlert.setContentText(spectrometer.getLastError());
						errAlert.showAndWait();
						spectrometerOnOffButton.setSelected(true);
						return false;
					}
				}
				startAcqButton.setDisable(true);
				disableSpectrometerAcqButtons(true);
				return true;
			}
		}
		return false;
	}
	
	@FXML private void onBtnClickConnectLaser() {
		Spectrometer spectrometer = SpectrometerFactory.getSpectrometer();
		if(spectrometer != null && spectrometer.isConnected()) {
			if(!spectrometer.laserOnOff(!laserOnOffButton.isSelected())) {
				Alert errAlert = new Alert(AlertType.ERROR);
				errAlert.setTitle(laserOnOffButton.isSelected()?"Connect to laser":"Disconnect from laser");
				errAlert.setHeaderText(laserOnOffButton.isSelected()?"Laser can't be started!!":"Laser can't be stopped!!");
				errAlert.setContentText(spectrometer.getLastError());
				errAlert.showAndWait();
				laserOnOffButton.setSelected(!laserOnOffButton.isSelected());
			}
		}
	}
	
	@FXML private void onBtnClickStartAcquisition() {
		Spectrometer spectrometer = SpectrometerFactory.getSpectrometer();
		if(spectrometer != null && spectrometer.isConnected()) {
			startSpectrumPoller();
			spectrometerOnOffButton.setDisable(true);
			startAcqButton.setDisable(true);
			disableSpectrometerAcqButtons(true);
			stopAcqButton.setDisable(false);
		}
	}
	
	@FXML private void onBtnClickStopAcquisition() {
		stopSpectrumPoller();
		spectrometerOnOffButton.setDisable(false);
		stopAcqButton.setDisable(true);
		startAcqButton.setDisable(false);
		disableSpectrometerAcqButtons(false);
	}
	
	@FXML private void onBtnClickSingleSpectrum() {
		if(spectrumPoller != null) {
			stopSpectrumPoller();
		}
		specViewController.clearData();
		new Thread(spectrumPollerThread()).start();
	}
	
	@FXML private void onBtnClickSignalDark() {
		isSignalDarkEnable.set(signalDarkButton.isSelected());
	}
	
	@FXML private void onBtnClickSaveDarkSpectrum() {
		Task<double[]> getSpectrumTask = createSpectrumTask();
		getSpectrumTask.setOnSucceeded(new EventHandler<WorkerStateEvent>() {
			@Override
			public void handle(WorkerStateEvent arg0) {
				double[] spectrum = null;
				spectrum = getSpectrumTask.getValue();
				if(spectrum != null) {
					darkSpectrum = spectrum;
					Alert errAlert = new Alert(AlertType.ERROR);
					errAlert.setTitle("Save dark spectrum");
					errAlert.setHeaderText("Dark spectrum saved!!");
					errAlert.initOwner(mainApp.getPrimaryStage());
					errAlert.showAndWait();
				}
			}
		});
		new Thread(getSpectrumTask).start();
	}
	
	@FXML private void onBtnClickSettings() {
		try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(Main.class.getResource("/in/gov/barc/drhr/raman/spectaID/view/fxml/Settings.fxml"));
            Node node = loader.load();
            Stage stage = new Stage();
            stage.setTitle("Settings window");
            stage.setScene(new Scene((Parent)node));
            stage.initOwner(mainApp.getPrimaryStage());
            stage.initModality(Modality.APPLICATION_MODAL);
            SettingsUIController controller = loader.getController(); 
            controller.setDialogStage(stage);
            stage.setResizable(false);
            stage.showAndWait();
        } catch (IOException e) {
        	// Show the error message.
    		Alert alert = new Alert(AlertType.ERROR);
    		alert.initOwner(mainApp.getPrimaryStage());
    		alert.setTitle("Load Error");
    		alert.setHeaderText("Dialog Load Error");
    		alert.setContentText(e.getMessage());
    		alert.showAndWait();
    		e.printStackTrace();
        }
	}
	
	@FXML private void onBtnClickSaveSpectrum() {
		if(displaySpectrum != null) {
			FileChooser fileChooser = new FileChooser();
			fileChooser.setTitle("Save Spectrum");
			File f = fileChooser.showSaveDialog(mainApp.getPrimaryStage());
			if(f == null){
				return;
			}
			displaySpectrum.saveSpectrum(f.getAbsolutePath() + ".csv");
		}
	}
	
	public void startSpectrumPoller(){
		if(spectrumPoller == null){
			specViewController.clearData();
			spectrumPoller = Executors.newSingleThreadScheduledExecutor();
			spectrumPoller.scheduleAtFixedRate(spectrumPollerThread(), 0, 300, TimeUnit.MILLISECONDS);
		}
	}
	
	public void stopSpectrumPoller(){
		if (spectrumPoller!=null && !spectrumPoller.isShutdown())
		{
			try
			{
				// stop the timer
				spectrumPoller.shutdown();
				while(!spectrumPoller.isTerminated()){
					spectrumPoller.awaitTermination(33, TimeUnit.MILLISECONDS);
				}
				spectrumPoller = null;
			}
			catch (InterruptedException e)
			{
				System.out.println("Exception in stopping the spectrometer poller, trying to release the spectrometer now... ");
			}
		}
	}

	public Runnable spectrumPollerThread(){
		return new Runnable() {
			@Override
			public void run() {
				Spectrometer spectrometer = SpectrometerFactory.getSpectrometer();
				if(spectrometer != null && spectrometer.isDataAvailable()){
					int[] wavelengthRange = new int[2048];
					double[] yData = spectrometer.getSpectrumData(wavelengthRange);
					double xData[] = spectrometer.getWavellength();
					if(yData != null && yData.length > 0 && wavelengthRange.length == yData.length) {
						//double[] xData = Arrays.stream(wavelengthRange).asDoubleStream().toArray();
						if(isSignalDarkEnable.get() && darkSpectrum != null && darkSpectrum.length == yData.length ) {
							for(int i=0;i<yData.length;i++) {
								yData[i] = yData[i] - darkSpectrum[i];
							}
						}
						displaySpectrum(xData, yData);
					}
				}
			}
		};
	}
	
	private Task<double[]> createSpectrumTask() {
		return new Task<double[]>() {
			@Override
			protected double[] call() throws Exception {
				Spectrometer spectrometer = SpectrometerFactory.getSpectrometer();
				if(spectrometer.isConnected()) {
					int[] timeAxis = new int[100];
					double[] spectrum = spectrometer.getSpectrumData(timeAxis);
					return spectrum;
				}
				return null;
			}
		};
	}
	
	private void displaySpectrum(double[] xData, double[] yData) {
		double yMin=0, yMax = 0;
		for(int i=0;i<yData.length;i++) {
			if(yMin > yData[i]){
	    		yMin = yData[i];
	    	}
	    	if(yMax < yData[i]){
	    		yMax = yData[i];
	    	}
		}
		displaySpectrum.getOriginalData().setyMin(yMin);
		displaySpectrum.getOriginalData().setyMax(yMax);
		displaySpectrum.getOriginalData().setxStart(xData[0]);
		displaySpectrum.getOriginalData().setxEnd(xData[xData.length - 1]);
		displaySpectrum.getOriginalData().setXYData(xData, yData);
		displaySpectrum.getCompound().setCompoundName("Unknown");
		specViewController.addSpectrumData(displaySpectrum, false, true);
		mainApp.setUnknownSpectra(displaySpectrum);
	}
		
	public void loadSpectometerSettingsPanel() {
		try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(Main.class.getResource("/in/gov/barc/drhr/raman/spectaAcquire/spectrometer/ui/SpectaAcquire.fxml"));
            TitledPane spectrometerView = (TitledPane) loader.load();
            // Give the controller access to the main app.
            spectaAcquireController = loader.getController();
            spectaAcquireController.setDialogStage(mainApp.getPrimaryStage());
            accrPane.getPanes().add(spectrometerView);
        } catch (IOException e) {
        	// Show the error message.
    		Alert alert = new Alert(AlertType.ERROR);
    		//alert.initOwner(mainApp.getPrimaryStage());
    		alert.setTitle("Load Error");
    		alert.setHeaderText("Dialog Load Error");
    		alert.setContentText(e.getMessage());
    		alert.showAndWait();
        }
	}

	public VBox loadSpectrumView(){
		VBox spectrumView = null;
    	try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(Main.class.getResource("/in/gov/barc/drhr/raman/spectaID/view/fxml/SpectrumView.fxml"));
            spectrumView = (VBox) loader.load();
            // Give the controller access to the main app.
            specViewController = loader.getController();
            specViewController.setMainApp(mainApp);
        } catch (IOException e) {
        	// Show the error message.
    		Alert alert = new Alert(AlertType.ERROR);
    		//alert.initOwner(mainApp.getPrimaryStage());
    		alert.setTitle("Load Error");
    		alert.setHeaderText("Dialog Load Error");
    		alert.setContentText(e.getMessage());
    		alert.showAndWait();
        }
    	VBox.setVgrow(spectrumView, Priority.ALWAYS);
    	return spectrumView;
    }

	public void loadDatabaseOptionsPane(){
		TitledPane dbOptionsPane = null;
    	try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(Main.class.getResource("/in/gov/barc/drhr/raman/spectaID/view/fxml/DatabaseOptionsPane.fxml"));
            dbOptionsPane = (TitledPane) loader.load();
            accrPane.getPanes().add(dbOptionsPane);
            // Give the controller access to the main app.
            DBOptionsPaneController dbOptionsController = loader.getController();
            dbOptionsController.setMainApp(mainApp);
        } catch (IOException e) {
            e.printStackTrace();
        }
	}

	public void loadPreprocessingPane(){
		TitledPane preprocessPane = null;
    	try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(Main.class.getResource("/in/gov/barc/drhr/raman/spectaID/view/fxml/PreprocessingPane.fxml"));
            preprocessPane = (TitledPane) loader.load();
            accrPane.getPanes().add(preprocessPane);
            // Give the controller access to the main app
            PreprocessPaneController preprocessController = loader.getController();
            preprocessController.setMainApp(mainApp);
        } catch (IOException e) {
            e.printStackTrace();
        }
	}

	public void loadFullSpcSearchPane(){
		TitledPane fullSpcPane = null;
    	try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(Main.class.getResource("/in/gov/barc/drhr/raman/spectaID/view/fxml/FullSpcSearchPane.fxml"));
            fullSpcPane = (TitledPane) loader.load();
            accrPane.getPanes().add(fullSpcPane);
            // Give the controller access to the main app.
            FullSpcSearchController fullSpcController = loader.getController();
            fullSpcController.setMainApp(mainApp);
        } catch (IOException e) {
            e.printStackTrace();
        }
	}

	public void loadPeakSearchPane(){
		TitledPane peakPane = null;
    	try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(Main.class.getResource("/in/gov/barc/drhr/raman/spectaID/view/fxml/PeakSearchPane.fxml"));
            peakPane = (TitledPane) loader.load();
            accrPane.getPanes().add(peakPane);
            // Give the controller access to the main app.
            PeakSearchController peakSearchController = loader.getController();
            peakSearchController.setMainApp(mainApp);
        } catch (IOException e) {
            e.printStackTrace();
        }
	}

	private void openSpecParamsDlg(){
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("/in/gov/barc/drhr/raman/spectaID/view/fxml/SpectraParameters.fxml"));
		AnchorPane spectrumParam;
		try {
			spectrumParam = (AnchorPane) loader.load();
			// Create the dialog Stage.
			Stage dialogStage = new Stage();
			dialogStage.setTitle("Spectrum Parameters");
			dialogStage.initModality(Modality.WINDOW_MODAL);
			dialogStage.initOwner(mainApp.getPrimaryStage());
			Scene scene = new Scene(spectrumParam);
			dialogStage.setScene(scene);
			SpectraParamsController controller = loader.getController();
			controller.setDialogStage(dialogStage);
			controller.setMainApp(mainApp);
			// Show the dialog and wait until the user closes it
			dialogStage.showAndWait();
			if(controller.getSpectrum() != null) {
				displaySpectrum = controller.getSpectrum();
				specViewController.clearData();
				specViewController.addSpectrumData(displaySpectrum,false, false);
			}
    	} catch (IOException e) {
    		// Show the error message.
    		Alert alert = new Alert(AlertType.ERROR);
    		alert.initOwner(mainApp.getPrimaryStage());
    		alert.setTitle("Load Error");
    		alert.setHeaderText("Dialog Load Error");
    		alert.setContentText(e.getMessage());
    		alert.showAndWait();
    	}
	}

	@SuppressWarnings("unchecked")
	public void addHitList(List<HitSpectrum> spcList){
		Tab tab = new Tab("1-Component Results");
		TableView<HitSpectrum> hitTable = new TableView<>();
		TableColumn<HitSpectrum, Integer> srNoCol = new TableColumn<>("Sr. No");
		TableColumn<HitSpectrum, Double> scoreCol = new TableColumn<>("Score");
		TableColumn<HitSpectrum, String> nameCol = new TableColumn<>("Spectrum");
		TableColumn<HitSpectrum, String> idCol = new TableColumn<>("ID");
		hitTable.getColumns().addAll(srNoCol,scoreCol,nameCol,idCol);
		scoreCol.setCellValueFactory(new Callback<CellDataFeatures<HitSpectrum, Double>, ObservableValue<Double>>() {
		     public ObservableValue<Double> call(CellDataFeatures<HitSpectrum, Double> p) {
		         return new SimpleDoubleProperty(p.getValue().getScore()).asObject();
		     }
		  });

		scoreCol.setCellFactory(tc -> new TableCell<HitSpectrum, Double>() {
		    @Override
		    protected void updateItem(Double value, boolean empty) {
		        super.updateItem(value, empty) ;
		        if (empty) {
		            setText(null);
		        } else {
		            setText(String.format("%.2f", value.doubleValue()));
		        }
		    }
		});

		nameCol.setCellValueFactory(new Callback<CellDataFeatures<HitSpectrum, String>, ObservableValue<String>>() {
		     public ObservableValue<String> call(CellDataFeatures<HitSpectrum, String> p) {
		         return new SimpleStringProperty(p.getValue().getSpc().getCompound().getCompoundName());
		     }
		  });

		idCol.setCellValueFactory(new Callback<CellDataFeatures<HitSpectrum, String>, ObservableValue<String>>() {
		     public ObservableValue<String> call(CellDataFeatures<HitSpectrum, String> p) {
		         return new SimpleStringProperty(p.getValue().getSpc().getSpectrumId());
		     }
		  });

		srNoCol.setCellValueFactory(new Callback<CellDataFeatures<HitSpectrum, Integer>, ObservableValue<Integer>>() {
			  @Override public ObservableValue<Integer> call(CellDataFeatures<HitSpectrum, Integer> p) {
				    return new ReadOnlyObjectWrapper<Integer>(hitTable.getItems().indexOf(p.getValue()) + 1);
				  }
				});
			srNoCol.setSortable(false);

		hitTable.getSelectionModel().getSelectedItems().addListener(new ListChangeListener<HitSpectrum>() {
	          @Override
	          public void onChanged(ListChangeListener.Change<? extends HitSpectrum> c) {
	            while (c.next()) {
	              if (c.wasAdded()) {
	            	  for(int i=0;i<c.getAddedSubList().size();i++){
	            		Spectrum spc = c.getAddedSubList().get(i).getSpc();
	            		if(spc != null){
	            			specViewController.addSpectrumData(spc,false, false);
	            		}
	                  	//System.out.println("Added:"+spc);
	            	  }
	              }
	              if (c.wasRemoved()) {
	                c.getRemoved().stream().forEach((item) -> {
	                	if(item != null){
	                		specViewController.removeSpectrumData(item.getSpc());
	                	}
	                	//System.out.println("removed:"+item);
	                });
	              }
	            }
	          }
	        });
		hitTable.getItems().addAll(spcList);
		tab.setClosable(true);
		tab.setContent(hitTable);
		searchTabs.getTabs().add(tab);
	}
	
	private void disableSpectrometerAcqButtons(boolean isDisable) {
		singleAcqButton.setDisable(isDisable);
		saveSpectrumButton.setDisable(isDisable);
		//btnOpen.setDisable(isDisable);
		saveDarkBtn.setDisable(isDisable);
		settingsButton.setDisable(isDisable);
	}
	
	public void closeSafely() {
		stopSpectrumPoller();
		if(SpectrometerFactory.getSpectrometer() != null && SpectrometerFactory.getSpectrometer().isConnected()) {
			SpectrometerFactory.getSpectrometer().stopMeasure();
			SpectrometerFactory.getSpectrometer().disconnect();
		}
	}
}
