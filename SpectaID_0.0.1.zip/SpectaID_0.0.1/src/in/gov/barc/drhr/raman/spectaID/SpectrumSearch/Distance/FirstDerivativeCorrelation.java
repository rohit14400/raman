package in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Distance;

import java.util.Arrays;

import in.gov.barc.drhr.raman.spectaID.model.SpectrumData;

public class FirstDerivativeCorrelation extends SpectralDistance {

	@Override
	public double getDistance(SpectrumData spcUnk, SpectrumData spcLib) {
		calculateRange(spcUnk,spcLib);
		double[] xDataLib = spcLib.getXData();
		double[] yDataLib = spcLib.getYData();
		double meanLib = 0.0, meanUnk = 0.0;
		int k=0;
		interpolate.interpolate(Arrays.copyOfRange(spcUnk.getXData(), startIdx, endIdx),
				Arrays.copyOfRange(spcUnk.getYData(), startIdx, endIdx));
		for(int i=0;i<xDataLib.length;i++){
			if(xDataLib[i] < xStart){
				continue;
			}
			if(xDataLib[i] > xEnd){
				break;
			}
			double currUnkVal = interpolate.getValue(xDataLib[i]);
			double currLibVal = yDataLib[i];
			meanUnk += currUnkVal;
			meanLib += currLibVal;
			k++;
		}
		meanUnk /= k;
		meanLib /= k;
		double dotLibUnk = 0.0,dotLibLib = 0.0,dotUnkUnk = 0.0;
		double prevUnkVal = 0.0,prevLibVal = 0.0;
		int count = 0;
		for(int i=0;i<xDataLib.length;i++){
			if(xDataLib[i] < xStart){
				continue;
			}
			if(xDataLib[i] > xEnd){
				break;
			}
			double currUnkVal = interpolate.getValue(xDataLib[i]);
			double currLibVal = yDataLib[i];
			if(count == 0){
				prevUnkVal = currUnkVal;
				prevLibVal = currLibVal;
			}
			double derivativeLib = (currLibVal - meanLib) - prevLibVal;
			double derivativeUnk = (currUnkVal - meanUnk) - prevUnkVal;
			dotLibUnk += ( derivativeLib * derivativeUnk);
			dotLibLib += (derivativeLib * derivativeLib);
			dotUnkUnk += (derivativeUnk * derivativeUnk);
			prevUnkVal = currUnkVal;
			prevLibVal = currLibVal;
			count++;
		}
		return ((dotLibUnk * dotLibUnk) / (dotLibLib * dotUnkUnk)) * 100;
	}

}
