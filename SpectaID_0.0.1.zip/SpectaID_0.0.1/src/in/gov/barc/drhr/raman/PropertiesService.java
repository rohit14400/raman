package in.gov.barc.drhr.raman;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesService {
	private static final String confFile = "settings.conf";
	private static final String homeDir = System.getProperty("user.home");
	private static Properties prop = new Properties();
	
	public static void setRamanDbPath(String path) {
		prop.setProperty(SettingsTags.RAMAN_DB_PATH, path);
	}
	
	public static String getRamanDbPath() {
		if(load("")) {
			return prop.getProperty(SettingsTags.RAMAN_DB_PATH);
		}
		return "";
	}
		
	public static boolean load(String dir){
		if(dir.length() == 0) {
			dir = homeDir;
		}
		String path = dir + "\\" + confFile;
		InputStream io;
		try {
			io = new FileInputStream(path);
			if(io != null){
				try {
					prop.load(io);
					return true;
				} catch (IOException e) {
					//logger.error("Load Conf file "+e);
				}
			}
		} catch (FileNotFoundException e1) {
		}
		return false;
	}

	public static boolean save(String dir){
		if(dir.length() == 0) {
			dir = homeDir;
		}
		String path = dir + "//" + confFile;
		try {
			prop.store(new FileOutputStream(path), null);
			return true;
		} catch (IOException e) {
			//logger.error("Save  Conf file "+e);
		}
		return false;
	}
}
