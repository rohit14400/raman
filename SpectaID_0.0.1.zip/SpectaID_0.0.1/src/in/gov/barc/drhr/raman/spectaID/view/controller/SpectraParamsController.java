package in.gov.barc.drhr.raman.spectaID.view.controller;

import java.io.File;

import in.gov.barc.drhr.raman.spectaID.Main;
import in.gov.barc.drhr.raman.spectaID.Util.LoadSpectrum;
import in.gov.barc.drhr.raman.spectaID.model.Spectrum;
import in.gov.barc.drhr.raman.spectaID.model.SpectrumParams;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Callback;

public class SpectraParamsController {
	@FXML private Button btnOpen;
	@FXML private TextField txtPath;
	@FXML private ComboBox<String> specType;
	@FXML private ComboBox<String> xUnit;
	@FXML private ComboBox<String> yUnit;
	@FXML private Button btnOk;
	@FXML private Button btnCancel;
	@FXML private TableView<XYChart.Data<Number, Number>> spectTable;
	@FXML private TableColumn<XYChart.Data<Number, Number>, Number> xDataCol;
	@FXML private TableColumn<XYChart.Data<Number, Number>, Number> yDataCol;
	@FXML private LineChart<Number, Number> specPreview;
	@FXML private NumberAxis xAxis;
	@FXML private NumberAxis yAxis;

	private Stage dialogStage;
	private SpectrumParams specParams;
	private Main mainApp;
	private Spectrum unknownSpc = null;

	public SpectraParamsController() {
		 specParams = new SpectrumParams();
	}

	@FXML
    private void initialize() {
		Image image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/open_16.png"));
		btnOpen.setGraphic(new ImageView(image));
		specPreview.setTitle("Spectrum Preview");
		specType.getItems().addAll(specParams.GetTypes());
		xDataCol.setCellValueFactory(new Callback<CellDataFeatures<XYChart.Data<Number, Number>, Number>, ObservableValue<Number>>() {
		     public ObservableValue<Number> call(CellDataFeatures<XYChart.Data<Number, Number>, Number> p) {
		         return p.getValue().XValueProperty();
		     }
		  });
		yDataCol.setCellValueFactory(new Callback<CellDataFeatures<XYChart.Data<Number, Number>, Number>, ObservableValue<Number>>() {
		     public ObservableValue<Number> call(CellDataFeatures<XYChart.Data<Number, Number>, Number> p) {
		         return p.getValue().YValueProperty();
		     }
		  });
		specType.getSelectionModel().selectFirst();
		populateUnitsList(specType.getSelectionModel().getSelectedItem());
	}

	@FXML void selectTypeOnAction(){
		String selType = specType.getSelectionModel().getSelectedItem();
		populateUnitsList(selType);
	}
	
	@FXML void onBtnClickedOK(){
		createSpectra();
		dialogStage.close();
	}
	
	@FXML void onBtnClickCancel(){
		unknownSpc = null;
		dialogStage.close();
	}
	 /**
     * Sets the stage of this dialog.
     *
     * @param dialogStage
     */
    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    private void populateUnitsList(String selType){
		String[] xUnits = specParams.GetXUnits(selType);
		String[] yUnits = specParams.GetyUnits(selType);
		xUnit.getItems().clear();
		yUnit.getItems().clear();
		xUnit.getItems().addAll(xUnits);
		yUnit.getItems().addAll(yUnits);
		xUnit.getSelectionModel().selectFirst();
		yUnit.getSelectionModel().selectFirst();
    }

	private void updateLineChart(){
		XYChart.Series<Number, Number> series = new XYChart.Series<Number, Number>();
		double[] xData = unknownSpc.getOriginalData().getXData();
		double[] yData = unknownSpc.getOriginalData().getYData();
		ObservableList<XYChart.Data<Number,Number>> oData = FXCollections.observableArrayList();
		for(int i=0;i<xData.length;i++){
			oData.add(new XYChart.Data<Number,Number>(xData[i],yData[i]));
		}
		series.getData().clear();
		specPreview.getData().clear();
		spectTable.getItems().clear();
		series.getData().addAll(oData);
		spectTable.getItems().addAll(oData);
		
		specPreview.getData().add(series);
	}

	@FXML void onBtnClickOpen(){
		FileChooser fileChooser = new FileChooser();
		configureFileChooser(fileChooser);
		File f = fileChooser.showOpenDialog(dialogStage);
		if(f == null){
			return;
		}
		txtPath.setText(f.getAbsolutePath());
		LoadSpectrum spectLoad = new LoadSpectrum();
		unknownSpc = spectLoad.loadSpectrum(f);
        updateLineChart();
	}

	private void configureFileChooser(final FileChooser fileChooser) {
		fileChooser.setTitle("Open Spectrum");
		fileChooser.setInitialDirectory(
			new File(System.getProperty("user.home")));
			fileChooser.getExtensionFilters().addAll(
			new FileChooser.ExtensionFilter("Txt Files", "*.txt"),
			new FileChooser.ExtensionFilter("Txt Files", "*.csv"),
			new FileChooser.ExtensionFilter("rruff Files", "*.rruff"),
			new FileChooser.ExtensionFilter("rruff Files", "*.sdbx")
			);
	}

	public void setMainApp(Main mainApp){
		this.mainApp = mainApp;
	}

	private void createSpectra(){
		unknownSpc.getCompound().setCompoundName("Unknown");
		mainApp.setUnknownSpectra(unknownSpc);
	}
	
	public Spectrum getSpectrum() {
		return unknownSpc;
	}
}
