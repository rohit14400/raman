package in.gov.barc.drhr.raman.spectaID.view.controller;

import java.io.IOException;

import in.gov.barc.drhr.raman.spectaID.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class DBOptionsPaneController {
	@FXML private Button dbMgmtBtn;
	@FXML private Button dbSelectBtn;

	private Main mainApp;

	public void setMainApp(Main mainApp){
		this.mainApp = mainApp;
	}

	@FXML private void initialize() {
		Image image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/DbSettings.png"));
		dbMgmtBtn.setGraphic(new ImageView(image));
		image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/DBSelect.png"));
		dbSelectBtn.setGraphic(new ImageView(image));
    }

	@FXML private void onBtnClickDBMgmt(){
		FXMLLoader createDBloader = new FXMLLoader();
		createDBloader.setLocation(Main.class.getResource("/in/gov/barc/drhr/raman/spectaID/view/fxml/DatabaseMgmt.fxml"));
		BorderPane dbMgmtPane;
		try {
			dbMgmtPane = (BorderPane) createDBloader.load();
			// Create the dialog Stage.
			Stage dialogStage = new Stage();
			dialogStage.setTitle("Spectrum Database Management");
			dialogStage.initModality(Modality.WINDOW_MODAL);
			dialogStage.initOwner(mainApp.getPrimaryStage());
			Scene scene = new Scene(dbMgmtPane);
			dialogStage.setScene(scene);
			// Set the person into the controller.
			DBMgmtController dbMgmtController = createDBloader.getController();
			dbMgmtController.setDialogStage(dialogStage);
			// Show the dialog and wait until the user closes it
			FXMLLoader spcViewloader = new FXMLLoader();
			spcViewloader.setLocation(Main.class.getResource("/in/gov/barc/drhr/raman/spectaID/view/fxml/SpectrumView.fxml"));
			VBox spectrumView = (VBox) spcViewloader.load();
			// Give the controller access to the main app.
            SpectrumViewController specViewController = spcViewloader.getController();
            specViewController.setMainApp(mainApp);
            //set to center
            dbMgmtPane.setCenter(spectrumView);
			dbMgmtController.setSpectrumViewController(specViewController);
			dialogStage.showAndWait();
    	} catch (IOException e) {
    		e.printStackTrace();
    		// Show the error message.
    		Alert alert = new Alert(AlertType.ERROR);
    		alert.initOwner(mainApp.getPrimaryStage());
    		alert.setTitle("Load Error");
    		alert.setHeaderText("Dialog Load Error");
    		alert.setContentText(e.getMessage());
    		alert.showAndWait();
    	}
	}

	@FXML public void onBtnClickSelectDB(){
		FXMLLoader selectDBloader = new FXMLLoader();
		selectDBloader.setLocation(Main.class.getResource("/in/gov/barc/drhr/raman/spectaID/view/fxml/DatabaseSearch.fxml"));
		AnchorPane selectDBPane;
		try {
			selectDBPane = (AnchorPane) selectDBloader.load();
			// Create the dialog Stage.
			Stage dialogStage = new Stage();
			dialogStage.setTitle("Spectrum Database Selection Window");
			dialogStage.initModality(Modality.WINDOW_MODAL);
			dialogStage.initOwner(mainApp.getPrimaryStage());
			dialogStage.setResizable(false);
			Scene scene = new Scene(selectDBPane);
			dialogStage.setScene(scene);
            DBSearchController dbSearchController = selectDBloader.getController();
            dbSearchController.setDialogStage(dialogStage);
            dbSearchController.setMainApp(mainApp);
			dialogStage.showAndWait();
    	}catch (IOException e) {
    		e.printStackTrace();
    		// Show the error message.
    		Alert alert = new Alert(AlertType.ERROR);
    		alert.initOwner(mainApp.getPrimaryStage());
    		alert.setTitle("Load Error");
    		alert.setHeaderText("Dialog Load Error");
    		alert.setContentText(e.getMessage());
    		alert.showAndWait();
    	}
	}
}
