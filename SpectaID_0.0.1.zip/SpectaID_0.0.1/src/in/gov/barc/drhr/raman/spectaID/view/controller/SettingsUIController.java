package in.gov.barc.drhr.raman.spectaID.view.controller;

import java.io.IOException;

import in.gov.barc.drhr.raman.spectaAcquire.spectrometer.ui.MeasurementSettingsUIController;
import in.gov.barc.drhr.raman.spectaID.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.TabPane;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Tab;
import javafx.stage.Stage;

public class SettingsUIController {
	@FXML private TabPane settingsPane;
	private Stage dialogStage;
	
	@FXML private void initialize() {
		loadGeneralSettingsPane();
		loadMeasurementSettingsPane();
	}
	
	public void setDialogStage(Stage dialogStage) {
		this.dialogStage = dialogStage;
	}
	
	private void loadGeneralSettingsPane() {
		try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(Main.class.getResource("/in/gov/barc/drhr/raman/spectaID/view/fxml/GeneralSettings.fxml"));
            Node settingsView = loader.load();
            GeneralSettingsUIController controller = (GeneralSettingsUIController) loader.getController();
			controller.setDialogStage(dialogStage);
			settingsPane.getTabs().add(new Tab("General", settingsView));
        } catch (IOException e) {
        	// Show the error message.
    		Alert alert = new Alert(AlertType.ERROR);
    		//alert.initOwner(mainApp.getPrimaryStage());
    		alert.setTitle("Load Settings window");
    		alert.setHeaderText("Couldn't load settings window");
    		alert.setContentText(e.getMessage());
    		alert.showAndWait();
        }
	}
	
	private void loadMeasurementSettingsPane() {
		try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(Main.class.getResource("/in/gov/barc/drhr/raman/spectaAcquire/spectrometer/ui/MeasurementSettings.fxml"));
            Node node = loader.load();
            MeasurementSettingsUIController controller = loader.getController(); 
            controller.setDialogStage(dialogStage);
            settingsPane.getTabs().add(new Tab("Measurement", node));
		} catch (IOException e) {
        	// Show the error message.
    		Alert alert = new Alert(AlertType.ERROR);
    		alert.initOwner(dialogStage);
    		alert.setTitle("Load Error");
    		alert.setHeaderText("Dialog Load Error");
    		alert.setContentText(e.getMessage());
    		alert.showAndWait();
    		e.printStackTrace();
        }
	}
}
