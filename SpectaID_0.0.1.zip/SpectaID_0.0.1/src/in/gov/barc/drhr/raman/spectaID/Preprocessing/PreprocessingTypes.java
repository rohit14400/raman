package in.gov.barc.drhr.raman.spectaID.Preprocessing;

import java.util.ArrayList;
import java.util.List;

public enum PreprocessingTypes {
	ALL("All"),
	DENOSING("Denoising"),
	BASELINE("Baseline"),
	NORMALIZE("Normalize"),
	BKGRND_SUBSTRACT("Background Substraction")
	;
	private final String text;
	PreprocessingTypes(final String type){
		this.text = type;
	}

	@Override
    public String toString() {
        return text;
    }

    public List<String> getPreprocessNames(){
    	//mind the sequence (same as above)
    	List<String> names = new ArrayList<String>();
    	names.add(DENOSING.toString());
    	names.add(BASELINE.toString());
    	names.add(NORMALIZE.toString());
    	names.add(BKGRND_SUBSTRACT.toString());
    	return names;
    }
}
