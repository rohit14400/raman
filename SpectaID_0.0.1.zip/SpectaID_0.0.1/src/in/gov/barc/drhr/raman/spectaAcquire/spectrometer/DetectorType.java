package in.gov.barc.drhr.raman.spectaAcquire.spectrometer;

public class DetectorType {
	private String sensorType; 
	private int nrPixels; 
	private float fit[]; 
	private boolean nLEnable;
	private double nLCorrect[];
	private double lowNLCounts;
	private double highNLCounts; 
	private float gain[];
	private float reserved; 
	private float offset[]; 
	private float extOffset;
	private short defectivePixels[];
	
	public DetectorType() {
		fit = new float[5];
		nLCorrect = new double[8];
		gain = new float[2];
		offset = new float[2];
		defectivePixels = new short[30];
	}

	public String getSensorType() {
		return sensorType;
	}

	public int getNrPixels() {
		return nrPixels;
	}

	public float[] getFit() {
		return fit;
	}

	public boolean isnLEnable() {
		return nLEnable;
	}

	public double[] getnLCorrect() {
		return nLCorrect;
	}

	public double getLowNLCounts() {
		return lowNLCounts;
	}

	public double getHighNLCounts() {
		return highNLCounts;
	}

	public float[] getGain() {
		return gain;
	}

	public float getReserved() {
		return reserved;
	}

	public float[] getOffset() {
		return offset;
	}

	public float getExtOffset() {
		return extOffset;
	}

	public short[] getDefectivePixels() {
		return defectivePixels;
	}

	public void setSensorType(String sensorType) {
		this.sensorType = sensorType;
	}

	public void setNrPixels(int nrPixels) {
		this.nrPixels = nrPixels;
	}

	public void setFit(float[] fit) {
		this.fit = fit;
	}

	public void setnLEnable(boolean nLEnable) {
		this.nLEnable = nLEnable;
	}

	public void setnLCorrect(double[] nLCorrect) {
		this.nLCorrect = nLCorrect;
	}

	public void setLowNLCounts(double lowNLCounts) {
		this.lowNLCounts = lowNLCounts;
	}

	public void setHighNLCounts(double highNLCounts) {
		this.highNLCounts = highNLCounts;
	}

	public void setGain(float[] gain) {
		this.gain = gain;
	}

	public void setReserved(float reserved) {
		this.reserved = reserved;
	}

	public void setOffset(float[] offset) {
		this.offset = offset;
	}

	public void setExtOffset(float extOffset) {
		this.extOffset = extOffset;
	}

	public void setDefectivePixels(short[] defectivePixels) {
		this.defectivePixels = defectivePixels;
	}
}
