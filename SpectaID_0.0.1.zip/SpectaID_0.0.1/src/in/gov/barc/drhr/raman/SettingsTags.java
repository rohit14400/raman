package in.gov.barc.drhr.raman;

public class SettingsTags {
	public static final String RAMAN_DB_PATH = "RAMAN_DB_PATH";
}
