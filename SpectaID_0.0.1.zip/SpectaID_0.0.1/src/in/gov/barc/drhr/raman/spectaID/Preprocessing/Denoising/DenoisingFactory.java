package in.gov.barc.drhr.raman.spectaID.Preprocessing.Denoising;

public class DenoisingFactory {
	public IFilter getDenoisingAlgo(DenoisingAlgo algoNames){
		switch(algoNames){
		case SAVITZKY_GOLAY:
			return new SGFilter();
		default:
			return new SGFilter();
		}
	}
}
