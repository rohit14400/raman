package in.gov.barc.drhr.raman.spectaID.view.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.io.FilenameUtils;

import in.gov.barc.drhr.raman.PropertiesService;
import in.gov.barc.drhr.raman.spectaID.Main;
import in.gov.barc.drhr.raman.spectaID.Util.LoadSpectrum;
import in.gov.barc.drhr.raman.spectaID.model.SpectraDatabase;
import in.gov.barc.drhr.raman.spectaID.model.Spectrum;
import in.gov.barc.drhr.raman.spectaID.model.dao.ISpectraDatabaseDAO;
import in.gov.barc.drhr.raman.spectaID.model.dao.SpcDatabaseDAOImpl;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.DirectoryChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;

public class DBMgmtController {
	@FXML private Button newDBtn;
	@FXML private Button openBtn;
	@FXML private Button importFilesBtn;
	@FXML private TabPane propertiesPane;
	@FXML private TabPane dbSpecListPane;
	@FXML private TableView<Spectrum> spcTable;
	@FXML private TableColumn<Spectrum, String> spcNameCol;
	@FXML private TableColumn<Spectrum, String> spcId;
	@FXML private TableColumn<Spectrum, String> chemFormula;
	@FXML private TableColumn<Spectrum, Image> chemStructure;
	@FXML private TableColumn<Spectrum, Image> specImg;
	@FXML private Button removeFilesBtn;
	@FXML private Button removeAllFilesBtn;
	@FXML private Button delDBBtn;
	@FXML private Button prevSpecViewBtn;
	@FXML private Button nextSpecViewBtn;
	@FXML private TextField newViewCntText;
	@FXML private Text recordDispTxt;

	private Stage dialogStage;
	private SpectraDatabase spcDatabase;
	private ObservableList<Spectrum> oSpcList = null;
	private SpectrumViewController spcViewController;
	private ISpectraDatabaseDAO spcDatabaseDAO = new SpcDatabaseDAOImpl();
	private int nPrevFile = 0,nOffset = 100;
	private Long spectrumCount = (long) 0;

	public void setSpectrumViewController(SpectrumViewController spcViewController){
		this.spcViewController = spcViewController;
	}

	@FXML private void initialize() {
	Image image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/DBAdd.png"));
	newDBtn.setGraphic(new ImageView(image));
	image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/DBDelete.png"));
	delDBBtn.setGraphic(new ImageView(image));
	image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/open_16.png"));
	openBtn.setGraphic(new ImageView(image));
	image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/ImportFile.png"));
	importFilesBtn.setGraphic(new ImageView(image));
	image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/deleteFile.png"));
	removeFilesBtn.setGraphic(new ImageView(image));
	image = new Image(getClass().getResourceAsStream("/in/gov/barc/drhr/raman/resources/images/Clear.png"));
	removeAllFilesBtn.setGraphic(new ImageView(image));
	  setDBButtonStatus(true);
	  setDBFilesBtnStatus(true);
	  newViewCntText.setText(Integer.toString(nOffset));
	  recordDispTxt.setText("");
      //spcTable.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
      spcNameCol.setCellValueFactory(new Callback<CellDataFeatures<Spectrum, String>, ObservableValue<String>>() {
		     public ObservableValue<String> call(CellDataFeatures<Spectrum, String> p) {
		         return new SimpleStringProperty(p.getValue().getCompound().getCompoundName());
		     }
		  });

      spcId.setCellValueFactory(new Callback<CellDataFeatures<Spectrum, String>, ObservableValue<String>>() {
		     public ObservableValue<String> call(CellDataFeatures<Spectrum, String> p) {
		         return new SimpleStringProperty(p.getValue().getSpectrumId());
		     }
		  });

      chemFormula.setCellValueFactory(new Callback<CellDataFeatures<Spectrum, String>, ObservableValue<String>>() {
		     public ObservableValue<String> call(CellDataFeatures<Spectrum, String> p) {
		         return new SimpleStringProperty(p.getValue().getCompound().getChemFormula());
		     }
		  });

      spcTable.getSelectionModel().getSelectedItems().addListener(new ListChangeListener<Spectrum>() {
          @Override
          public void onChanged(ListChangeListener.Change<? extends Spectrum> c) {
            while (c.next()) {
              if (c.wasAdded()) {
            	  for(int i=0;i<c.getAddedSubList().size();i++){
            		Spectrum spc = c.getAddedSubList().get(i);
            		if(spc != null){
            			spcViewController.addSpectrumData(spc,false, false);
            		}
                  	//System.out.println("Added:"+spc);
            	  }
              }
              if (c.wasRemoved()) {
                c.getRemoved().stream().forEach((item) -> {
                	if(item != null){
                		spcViewController.removeSpectrumData(item);
                	}
                	//System.out.println("removed:"+item);
                });
              }
            }
          }
        });

      newViewCntText.textProperty().addListener(new ChangeListener<String>() {
          @Override
          public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
              if (!newValue.matches("\\d*")) {
            	  newViewCntText.setText(newValue.replaceAll("[^\\d]", ""));
              }
          }
      });
	}

	public void setDialogStage(Stage dialogStage) {
		this.dialogStage = dialogStage;
		if(null != dialogStage){
		 this.dialogStage.setOnCloseRequest(new EventHandler<javafx.stage.WindowEvent>() {
				@Override
				public void handle(javafx.stage.WindowEvent arg0) {
					onClose();
				}
		      });
		}
	}

	@FXML public void onBtnClickNewDB(){
		if(spcDatabase != null){
			Alert errDlg = new Alert(AlertType.CONFIRMATION,"Open Database",ButtonType.YES,ButtonType.NO);
			errDlg.setTitle("Open Database");
			errDlg.setContentText(spcDatabase.getDbName()+ " database already opened");
			errDlg.setHeaderText("Do you want to close current database and load another database?");
			errDlg.initOwner(this.dialogStage);
			if(errDlg.showAndWait().get() == ButtonType.NO){
				return;
			}
			spcDatabase = null;
		}
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("/in/gov/barc/drhr/raman/spectaID/view/fxml/DatabaseNew.fxml"));
		Stage dlgCreate = loadDialog(loader, "New Spectrum Database");
		if(dlgCreate != null){
			DBNewController controller = loader.getController();
			controller.setDialogStage(dlgCreate);
			// Show the dialog and wait until the user closes it
			dlgCreate.showAndWait();
			//get database values
			spcDatabase = controller.getNewSpectraDatabase();
			if(spcDatabase != null){
				createDatabase();
				setDBButtonStatus(false);
				dialogStage.setTitle("Current Database:'"+spcDatabase.getDbName()+"'");
			}
		}
	}

	private void setDBButtonStatus(boolean isDisable){
		importFilesBtn.setDisable(isDisable);
	    delDBBtn.setDisable(isDisable);
	}

	private void setDBFilesBtnStatus(boolean isDisable){
		removeAllFilesBtn.setDisable(isDisable);
	    removeFilesBtn.setDisable(isDisable);
	    prevSpecViewBtn.setDisable(isDisable);
	    nextSpecViewBtn.setDisable(isDisable);
	    newViewCntText.setDisable(isDisable);
	}

	@FXML public void onBtnClickOpenDB(){
		if(spcDatabase != null){
			Alert errDlg = new Alert(AlertType.CONFIRMATION,"Open Database",ButtonType.YES,ButtonType.NO);
			errDlg.setTitle("Open Database");
			errDlg.setContentText(spcDatabase.getDbName()+ " database already opened");
			errDlg.setHeaderText("Do you want to close current database and load another database?");
			errDlg.initOwner(this.dialogStage);
			if(errDlg.showAndWait().get() == ButtonType.NO){
				return;
			}
			spcDatabase = null;
		}
		File absolutePath = PropertiesService.getRamanDbPath().length() > 0? new File(PropertiesService.getRamanDbPath()):null;
    	if(absolutePath == null) {
        	DirectoryChooser fileChooser = new DirectoryChooser();
    		fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));
    		File chosenFile = fileChooser.showDialog(dialogStage);
    		if(chosenFile == null) {
    			return;
    		}
    		absolutePath = chosenFile;
    	}
		final File dbPath = absolutePath;
		Task<List<SpectraDatabase>> fetchDbTask = new Task<List<SpectraDatabase>>() {
			@Override
			protected List<SpectraDatabase> call() throws Exception {
				return spcDatabaseDAO.getAll(dbPath);
			}
		};
		Stage progressStage = showProgressBar();
		fetchDbTask.setOnSucceeded(new EventHandler<WorkerStateEvent>() {
			@Override
			public void handle(WorkerStateEvent arg0) {
				progressStage.close();
				List<SpectraDatabase> spcDBList = fetchDbTask.getValue();
				if(spcDBList == null || spcDBList.size() == 0){
					Alert errDlg = new Alert(AlertType.CONFIRMATION,"Open Database",ButtonType.YES,ButtonType.NO);
					errDlg.setTitle("Open Database Failed");
					errDlg.setHeaderText("Spectral database doesn't exist, Do you want to create new database?");
					errDlg.setContentText("No Spectrum database exists in Filesystem, please create new database to continue...");
					errDlg.initOwner(dialogStage);
					if(errDlg.showAndWait().get() == ButtonType.NO){
						return;
					}else{
						onBtnClickNewDB();
						return;
					}
				}
				Platform.runLater(()->{
					loadOpenDatabaseWindow(spcDBList);
				});
			}
		});
		new Thread(fetchDbTask).start();
		progressStage.showAndWait();
	}
	
	private void loadOpenDatabaseWindow(List<SpectraDatabase> spcDBList) {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("/in/gov/barc/drhr/raman/spectaID/view/fxml/DatabaseOpen.fxml"));
		Stage dlgOpen = loadDialog(loader, "Open Spectrum Database");
		dlgOpen.setResizable(false);
		if(dlgOpen != null){
			DBOpenController controller = loader.getController();
			controller.setDialogStage(dlgOpen);
			controller.setSpectraDatabaseList(spcDBList);
			// Show the dialog and wait until the user closes it
			dlgOpen.showAndWait();
			//get database values
			spcDatabase = controller.getSelectedDatabase();
			if(spcDatabase == null){
				setDBButtonStatus(true);
				setDBFilesBtnStatus(true);
				Alert errDlg = new Alert(AlertType.ERROR);
				errDlg.setTitle("Database open failed");
				errDlg.setHeaderText("Database open error");
				errDlg.setHeaderText("No database loaded...");
				errDlg.initOwner(dialogStage);
				errDlg.showAndWait();
				return;
			}
			dialogStage.setTitle("Current Database:'"+spcDatabase.getDbName()+"'");
			spectrumCount = spcDatabaseDAO.getSpectrumCount(spcDatabase);
			setDBButtonStatus(false);
			getSpcsFromDB();
		}
	}
	
	private Stage showProgressBar() {
		ProgressBar bar = new ProgressBar();
		Button stopButton = new Button("Stop");
		stopButton.setPrefWidth(80);
		stopButton.setPrefHeight(25);
		VBox vbox = new VBox(bar, stopButton);
		vbox.setAlignment(Pos.CENTER);
		vbox.setSpacing(10.0);
		bar.prefWidthProperty().bind(vbox.widthProperty());
//		stopButton.setOnAction(new EventHandler<ActionEvent>() {
//			@Override
//			public void handle(ActionEvent arg0) {
//				stopSearchTask();
//			}
//		});
		Stage stage = new Stage();
		stage.setScene(new Scene(vbox));
		stage.setTitle("Loading database...");
		stage.setHeight(100);
		stage.setWidth(400);
		stage.setResizable(false);
		stage.initOwner(dialogStage);
		stage.initModality(Modality.APPLICATION_MODAL);
		return stage;
	}

	@FXML public void onBtnClickImportFiles(){
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("/in/gov/barc/drhr/raman/spectaID/view/fxml/DatabaseSpectraImport.fxml"));
		Stage dlgImport = loadDialog(loader, "Import Spectrum files");
		if(dlgImport != null){
			DBSpecImportCtrl controller = loader.getController();
			controller.setDialogStage(dlgImport);
			dlgImport.showAndWait();
			List<File> filesList = controller.getSelectedSpectraList();
			LoadSpectrum lpsc = new LoadSpectrum();
			List<Spectrum> spcList = new ArrayList<>();
			//insert imported spectrum into database
			//ISpectrumDAO spcDAO = new SpectrumDAOImpl();
			//int i=1;
			//int batchSize = 300;
			for(File file:filesList){
				if(FilenameUtils.getExtension(file.getAbsolutePath()).compareToIgnoreCase("TXT") == 0){
					Spectrum spc = lpsc.loadSpectrum(file);
					spcList.add(spc);
					/*if(i++%batchSize == 0){
						if(!spcDAO.batchInsertSpectrum(spcList)  ||  !importSPCstoDB(spcList)){
							Alert errDlg = new Alert(AlertType.ERROR);
							errDlg.setTitle("Database Insert Error");
							errDlg.setContentText("Could not insert spectrum to databse");
							errDlg.setHeaderText("Spectrum data persistence error");
							break;
						}
						spcList.clear();
					} */
				}
			}
			if(spcList.size() > 0){
				if(/*!spcDAO.batchInsertSpectrum(spcList) || */!importSPCstoDB(spcList)){
					Alert errDlg = new Alert(AlertType.ERROR);
					errDlg.setTitle("Database Insert Error");
					errDlg.setContentText("Could not insert spectrum to databse");
					errDlg.setHeaderText("Spectrum data persistence error");
				}
				spcList.clear();
			}
			spectrumCount = spcDatabaseDAO.getSpectrumCount(spcDatabase);
			getSpcsFromDB();
		}
	}

	private void getSpcsFromDB(){
		List<Spectrum> spcList = spcDatabaseDAO.getSpcsFromDB(spcDatabase, nPrevFile, nOffset);
		if(spcList != null && spcList.size() > 0){
			spcTable.getItems().clear();
			if(oSpcList != null && oSpcList.size() > 0){
				oSpcList.clear();
			}
			oSpcList = FXCollections.observableArrayList(spcList);
			spcTable.setItems(oSpcList);
			setDBButtonStatus(false);
			setDBFilesBtnStatus(false);
		}
		recordDispTxt.setText("Displaying "+nPrevFile+"-"+ (nPrevFile + nOffset) + " of "+Long.toString(spectrumCount));
	}

	@FXML public void onBtnClickRemoveFiles(){
		if(!spcDatabaseDAO.removeSPCsFromDB(spcDatabase, spcTable.getSelectionModel().getSelectedItems())){
			Alert errDialog = new Alert(AlertType.ERROR);
			errDialog.initOwner(this.dialogStage);
			errDialog.setTitle("Database Error");
			errDialog.setHeaderText("Selected Spectrums can't be removed");
			errDialog.setContentText("Database error while deleting new record");
			errDialog.showAndWait();
		}
		oSpcList.removeAll(spcTable.getSelectionModel().getSelectedItems());
		if(oSpcList.size() == 0){
			setDBFilesBtnStatus(true);
		}
	}

	@FXML public void onBtnClickRemoveAllFiles(){
		if(!spcDatabaseDAO.removeSPCsFromDB(spcDatabase, spcTable.getItems())){
			Alert errDialog = new Alert(AlertType.ERROR);
			errDialog.initOwner(this.dialogStage);
			errDialog.setTitle("Database Error");
			errDialog.setHeaderText("Spectrum can't be deleted from database");
			errDialog.setContentText("Database error while removing all records");
			errDialog.showAndWait();
		}
		oSpcList.removeAll(spcTable.getItems());
		setDBFilesBtnStatus(true);
	}

	@FXML public void onBtnClickDeleletDB(){
		if(!spcDatabaseDAO.removeDatabase(spcDatabase)){
			Alert errDialog = new Alert(AlertType.ERROR);
			errDialog.initOwner(this.dialogStage);
			errDialog.setTitle("Database Delete Error");
			errDialog.setHeaderText("Database can't be deleted");
			errDialog.setContentText("Database error while removing all records");
			errDialog.showAndWait();
		}
		oSpcList.clear();
		spcTable.getItems().clear();
		setDBButtonStatus(true);
		setDBFilesBtnStatus(true);
		dialogStage.setTitle("Spectral Database Management");
	}

	@FXML public void onBtnClickPrevSpecView(){
		nOffset = Integer.parseInt(newViewCntText.getText());
		nPrevFile = Math.max(nPrevFile - nOffset,0);
		if(nPrevFile == 0){
			prevSpecViewBtn.setDisable(true);
		}else{
			nextSpecViewBtn.setDisable(false);
		}
		getSpcsFromDB();
	}

	@FXML public void onBtnClickNextSpecView(){
		nOffset = Integer.parseInt(newViewCntText.getText());
		if(nPrevFile == 0){
			prevSpecViewBtn.setDisable(false);
		}
		nPrevFile = (int) Math.min(nPrevFile + nOffset, spectrumCount - nOffset);
		if(nPrevFile > spectrumCount){
			nextSpecViewBtn.setDisable(true);
		}
		getSpcsFromDB();
	}

	private void onClose(){
		spcDatabaseDAO.close();
	}

	private void createDatabase(){
		if(!spcDatabaseDAO.insertDatabase(spcDatabase)){
			Alert errDialog = new Alert(AlertType.ERROR);
			errDialog.initOwner(this.dialogStage);
			errDialog.setTitle("Database Error");
			errDialog.setHeaderText("New Spectrum database create error");
			errDialog.setContentText("Database error while inserting new record");
			errDialog.showAndWait();
		}
	}

	private boolean importSPCstoDB(List<Spectrum> spcList){
		if(!spcDatabaseDAO.addSPCsToDB(spcDatabase, spcList)){
			Alert errDialog = new Alert(AlertType.ERROR);
			errDialog.initOwner(this.dialogStage);
			errDialog.setTitle("Database Error");
			errDialog.setHeaderText("Specturm couldn't be loaded to database:"+spcDatabase.getDbName());
			errDialog.setContentText("Database error while inserting new spectrums");
			errDialog.showAndWait();
			return false;
		}
		return true;
	}

	private Stage loadDialog(FXMLLoader loader,String title){
		AnchorPane pane;
		Stage dialogStage = null;
		try {
			pane = (AnchorPane) loader.load();
			// Create the dialog Stage.
			dialogStage = new Stage();
			dialogStage.setTitle(title);
			dialogStage.initModality(Modality.WINDOW_MODAL);
			dialogStage.initOwner(this.dialogStage);
			Scene scene = new Scene(pane);
			dialogStage.setScene(scene);
    	} catch (IOException e) {
    		// Show the error message.
    		e.printStackTrace();
    		Alert alert = new Alert(AlertType.ERROR);
    		alert.initOwner(this.dialogStage);
    		alert.setTitle("Load Error");
    		alert.setHeaderText("Dialog Load Error");
    		alert.setContentText(e.getMessage());
    		alert.showAndWait();
    	}
		return dialogStage;
	}
}
