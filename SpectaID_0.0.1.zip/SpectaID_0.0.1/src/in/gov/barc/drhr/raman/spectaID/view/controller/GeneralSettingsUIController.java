package in.gov.barc.drhr.raman.spectaID.view.controller;

import java.io.File;

import in.gov.barc.drhr.raman.PropertiesService;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;

public class GeneralSettingsUIController {
	@FXML private TextField ramanDBPathField;
	@FXML private Button saveBtn;
	private Stage dialogStage;
	
	public void setDialogStage(Stage dialogStage) {
		this.dialogStage = dialogStage;
	}
	
	@FXML private void initialize() {
		ramanDBPathField.setEditable(false);
		if(PropertiesService.load("")) {
			ramanDBPathField.setText(PropertiesService.getRamanDbPath());
		}
		saveBtn.disableProperty().bind(ramanDBPathField.textProperty().isEmpty());
	}
	
	@FXML private void onBtnClickSave() {
		PropertiesService.setRamanDbPath(ramanDBPathField.getText());
		if(PropertiesService.save("")) {
			dialogStage.close();
		}else {
			Alert errAlert = new Alert(AlertType.ERROR);
			errAlert.setTitle("Save settings");
			errAlert.setHeaderText("Settings save error!!!");
			errAlert.initOwner(dialogStage);
			errAlert.showAndWait();
		}
	}
	
	@FXML private void onBtnClickCancel() {
		dialogStage.close();
	}
	
	@FXML private void onBtnClickRamanPathBrowse() {
		DirectoryChooser chooser = new DirectoryChooser();
		File f = chooser.showDialog(dialogStage);
		if(f !=  null) {
			ramanDBPathField.setText(f.getAbsolutePath());
		}
	}
}
