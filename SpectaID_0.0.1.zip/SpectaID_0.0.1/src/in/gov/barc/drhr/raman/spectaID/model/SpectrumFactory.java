package in.gov.barc.drhr.raman.spectaID.model;

public class SpectrumFactory {
	public Spectrum GetSpectrum(String specType){
		if(specType == null){
			return null;
		}
		if(specType.equalsIgnoreCase("RAMAN")){
	         return new Spectrum();
	     }
		return null;
	}
}
