package in.gov.barc.drhr.raman.spectaID.model;

import java.io.Serializable;

public class Instrument implements Serializable{
	/**
	 *
	 */
	private static final long serialVersionUID = 7317509348072709901L;
	private String instrumentName;
    private String sampleSource;
    private String spectSource;

    public String getInstrumentName() {
		return instrumentName;
	}

	public void setInstrumentName(String instrumentName) {
		this.instrumentName = instrumentName;
	}

	public String getSampleSource() {
		return sampleSource;
	}

	public void setSampleSource(String sampleSource) {
		this.sampleSource = sampleSource;
	}

	public String getSpectSource() {
		return spectSource;
	}

	public void setSpectSource(String spectSource) {
		this.spectSource = spectSource;
	}
}
