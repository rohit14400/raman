package in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections.BaseLine;

import java.util.Iterator;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

import in.gov.barc.drhr.raman.spectaID.model.Point;
import in.gov.barc.drhr.raman.spectaID.model.Spectrum;

public class Linear implements IBaseLineCorrection {

	@Override
	public void correctSpectrum(Spectrum spc,List<Point<Double>> pts) {
		//points should also be sorted in x as well as in spectrum dataList
		SortedMap<Double, Double> baseLineMap = new TreeMap<Double, Double>();
		double[] xData = spc.getCorrectedData().getXData();
		double[] yData = spc.getCorrectedData().getYData();
		for(int i=0;i<xData.length;i++){
			baseLineMap.put(xData[i], 0.0);
		}
		//add first and last points
		pts.add(0, new Point<Double>(xData[0], yData[0]));
		pts.add(new Point<Double>(xData[xData.length - 1], yData[xData.length - 1]));
		Iterator<Point<Double>> ptsIt = pts.iterator();
		Iterator<Double> keySetIt = baseLineMap.keySet().iterator();
		while(ptsIt.hasNext()){
			Point<Double> pt1 = ptsIt.next();
			Point<Double> pt2 = ptsIt.next();
			double slope = (pt2.getY() - pt1.getY()) / (pt2.getX() - pt1.getX());
			double baseLine = pt1.getY() - slope * pt1.getX();
			while(keySetIt.hasNext()){
				double key = keySetIt.next();
				if(key <= pt2.getX()){
					baseLineMap.put(key,(slope * key + baseLine));
				}else{
					break;
				}
			}
		}
		double[] yCorrectedData = new double[xData.length];
		for(int i=0;i<xData.length;i++){
			yCorrectedData[i] = (yData[i] - baseLineMap.get(xData[i]));
		}
		spc.getCorrectedData().setYData(yCorrectedData);
		spc.setBaselineCorrected(true);
	}
}
