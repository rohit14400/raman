package in.gov.barc.drhr.raman.spectaID;


import java.io.IOException;
import java.util.List;

import in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Main.HitSpectrum;
import in.gov.barc.drhr.raman.spectaID.model.SpectraDatabase;
import in.gov.barc.drhr.raman.spectaID.model.Spectrum;
import in.gov.barc.drhr.raman.spectaID.model.SpectrumFactory;
import in.gov.barc.drhr.raman.spectaID.view.controller.SpectaIDController;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;


public class Main extends Application {

	private Stage primaryStage;
    private BorderPane rootLayout;
    private Spectrum unknownSpect;
    private List<SpectraDatabase> spcDbList;
    private SpectaIDController spcIDController;
    
    public Main(){
    }

	@Override
	public void start(Stage primaryStage) {
		this.primaryStage = primaryStage;
	    this.primaryStage.setTitle("SCOR (Raman spectroscopy for Cancer diagnosis)");
	    initRootLayout();
	}

	/**
     * Initializes the root layout.
     */
    public void initRootLayout() {
        try {
        	if(!loadSpectrometerLibrary()) {
        		//DO NOTHING
        	}
            // Load root layout from fxml file.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(Main.class.getResource("/in/gov/barc/drhr/raman/spectaID/view/fxml/SpectaID.fxml"));
            rootLayout = (BorderPane) loader.load();
            spcIDController = loader.getController();
            spcIDController.setMainApp(this);
            // Show the scene containing the root layout.
            Scene scene = new Scene(rootLayout);
            primaryStage.setScene(scene);
            primaryStage.setMaximized(true);
            primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
				@Override
				public void handle(WindowEvent arg0) {
					spcIDController.closeSafely();
				}
			});
            primaryStage.show();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Returns the main stage.
     * @return
     */
    public Stage getPrimaryStage() {
        return primaryStage;
    }

	public static void main(String[] args) {
		launch(args);
	}

	public Spectrum createSpectrum(String type){
		SpectrumFactory specFactory = new SpectrumFactory();
		Spectrum spectra = specFactory.GetSpectrum(type);
		return spectra;
	}

	public void setUnknownSpectra(Spectrum spectra){
		unknownSpect = spectra;
	}

	public Spectrum getUnknownSpectrum(){
		return unknownSpect;
	}

	public void setSpectrumLibrary(List<SpectraDatabase> spcDbList){
		this.spcDbList = spcDbList;
	}

	public List<SpectraDatabase> getSpectrumLibrary(){
		return spcDbList;
	}

	public void setHitList(List<HitSpectrum> spcHitList){
		spcIDController.addHitList(spcHitList);
	}

	public void showProcessedSpecturm(boolean isShow){
		spcIDController.showProcessedSpectrum(unknownSpect,isShow);
	}
	
	private boolean loadSpectrometerLibrary() {
		try {
			System.loadLibrary("avaspecx64");
			System.loadLibrary("AvantesJNI");
			return true;
		}catch(UnsatisfiedLinkError e) {
			e.printStackTrace();
			Alert err = new Alert(AlertType.ERROR);
    		err.setTitle("Load spectrometer library");
    		err.setHeaderText("Library can't be loaded!!!");
    		err.setContentText(e.getLocalizedMessage());
    		err.showAndWait();
		}
		return false;
	}
}
