package in.gov.barc.drhr.raman.spectaID.view.controller;

import java.io.File;

import in.gov.barc.drhr.raman.spectaID.model.SpectraDatabase;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;

public class DBNewController {
	@FXML private TextField dbNameField;
	@FXML private TextField dbIdField;
	@FXML private TextField versionField;
	@FXML private TextArea descField;
	@FXML private TextField pathField;
	@FXML private Button okBtn;
	@FXML private Button cancelBtn;
	@FXML private Button browseBtn;
	private Stage dialogStage;
	private SpectraDatabase spcDatabase;

	public void setDialogStage(Stage dialogStage) {
		this.dialogStage = dialogStage;
	}

	@FXML public void onBtnClickOk(){
		spcDatabase = new SpectraDatabase();
		spcDatabase.setDbName(dbNameField.getText());
		spcDatabase.setDbId(dbIdField.getText());
		spcDatabase.setDbVersion(versionField.getText());
		spcDatabase.setDbDesc(descField.getText());
		spcDatabase.setDbPath(pathField.getText());
		dialogStage.close();
	}

	@FXML public void onBtnClickCancel(){
		dialogStage.close();
	}

	@FXML public void onBtnClickBrowse(){
		DirectoryChooser dirChooser = new DirectoryChooser();
		File f = dirChooser.showDialog(dialogStage);
		if(f == null){
			return;
		}
		pathField.setText(f.getAbsolutePath());
	}

	public SpectraDatabase getNewSpectraDatabase(){
		return spcDatabase;
	}
}
