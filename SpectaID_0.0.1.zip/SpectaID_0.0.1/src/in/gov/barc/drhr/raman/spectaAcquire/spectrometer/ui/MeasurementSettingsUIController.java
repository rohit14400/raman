package in.gov.barc.drhr.raman.spectaAcquire.spectrometer.ui;

import in.gov.barc.drhr.raman.spectaAcquire.spectrometer.CMeasurementSettings;
import in.gov.barc.drhr.raman.spectaAcquire.spectrometer.DetectorType;
import in.gov.barc.drhr.raman.spectaAcquire.spectrometer.Spectrometer;
import in.gov.barc.drhr.raman.spectaAcquire.spectrometer.SpectrometerFactory;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory.DoubleSpinnerValueFactory;
import javafx.scene.control.SpinnerValueFactory.IntegerSpinnerValueFactory;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class MeasurementSettingsUIController {
	@FXML private TextField serialNoField;
	@FXML private TextField detectorTypeField;
	@FXML private TextField wavelengthRangeField;
	@FXML private TextField nPixelsField;
	
	@FXML private Spinner<Double> integrationTimeSpinner;
	@FXML private Spinner<Integer> nAvgsSpinner;
	@FXML private Spinner<Integer> nSmoothingPixelsSpinner;
	@FXML private TextField startWavelengthField;
	@FXML private TextField endWavelengthField;
	@FXML private CheckBox enableDarkBox;
	//laser settings
	@FXML private TextField flashesPerScanField;
	@FXML private TextField laserDelayField;
	@FXML private TextField laserWavelengthField;
	@FXML private TextField laserWidthField;
	@FXML private TextField spectraStoreField;
	
	private Stage dialogStage;
	
	public void setDialogStage(Stage dialogStage) {
		this.dialogStage = dialogStage;
	}
	

	@FXML private void initialize() {
		DoubleSpinnerValueFactory factory = new DoubleSpinnerValueFactory(0, 600000, 0.001);
		integrationTimeSpinner.setValueFactory(factory);
		IntegerSpinnerValueFactory avgFactory = new IntegerSpinnerValueFactory(0, 10, 1);
		nAvgsSpinner.setValueFactory(avgFactory);
		IntegerSpinnerValueFactory smoothingFactory = new IntegerSpinnerValueFactory(0, 10);
		nSmoothingPixelsSpinner.setValueFactory(smoothingFactory);
		populateSpectrometerInfo();
		readMeasurementSettings();
	}
	
	private void populateSpectrometerInfo() {
		Spectrometer spectrometer = SpectrometerFactory.getSpectrometer();
		if(spectrometer.isConnected()) {
			DetectorType detectorParams = spectrometer.getDetectorParams();
			if(detectorParams != null) {
				detectorTypeField.setText(detectorParams.getSensorType());
				nPixelsField.setText(""+detectorParams.getNrPixels());
			}
		}		
	}
	
	private void readMeasurementSettings() {
		Spectrometer spectrometer = SpectrometerFactory.getSpectrometer();
		if(spectrometer.isConnected()) {
			CMeasurementSettings measurementSettings = spectrometer.readConfigFromDevice();
			if(measurementSettings != null) {
				integrationTimeSpinner.getValueFactory().setValue(measurementSettings.integrationTime());
				nAvgsSpinner.getValueFactory().setValue(measurementSettings.nrAverages());
				nSmoothingPixelsSpinner.getValueFactory().setValue(measurementSettings.smoothPix());
				//
				startWavelengthField.setText(""+measurementSettings.startPixel());
				endWavelengthField.setText(""+measurementSettings.stopPixel());
				enableDarkBox.setSelected(measurementSettings.corDynDark());
				//laser
				flashesPerScanField.setText(""+measurementSettings.nrScans());
				laserWidthField.setText(""+measurementSettings.laserWidth());
				laserDelayField.setText(""+measurementSettings.laserDelay());
				laserWavelengthField.setText(""+measurementSettings.laserWaveLength());
				spectraStoreField.setText(""+measurementSettings.storeToRam());
			}
		}
		
	}
	
	@FXML private void saveMeasurementSettings() {
		Spectrometer spectrometer = SpectrometerFactory.getSpectrometer();
		if(spectrometer.isConnected()) {
			CMeasurementSettings measurementSettings = spectrometer.readConfigFromDevice();
			if(measurementSettings == null) {
				measurementSettings = new CMeasurementSettings();
			}
			measurementSettings.setIntegrationTime(integrationTimeSpinner.getValue());
			measurementSettings.setNrAverages(nAvgsSpinner.getValue());
			measurementSettings.setSmoothPix(nSmoothingPixelsSpinner.getValue());
			measurementSettings.setStartPixel(Integer.parseInt(startWavelengthField.getText()));
			measurementSettings.setStopPixel(Integer.parseInt(endWavelengthField.getText()));
			measurementSettings.setCorDynDark(enableDarkBox.isSelected());
			//laser
			measurementSettings.setLaserDelay(Double.parseDouble(laserDelayField.getText()));
			measurementSettings.setLaserWidth(Integer.parseInt(laserWidthField.getText()));
			measurementSettings.setLaserWaveLength(Double.parseDouble(laserWavelengthField.getText()));
			measurementSettings.setNrScans(Integer.parseInt(flashesPerScanField.getText()));
			measurementSettings.setStoreToRam(Integer.parseInt(spectraStoreField.getText()));
			spectrometer.writeConfigToDevice(measurementSettings);
		}
	}
	
	@FXML private void onBtnClickCancel() {
		if(dialogStage != null) {
			dialogStage.close();
		}
	}
}
