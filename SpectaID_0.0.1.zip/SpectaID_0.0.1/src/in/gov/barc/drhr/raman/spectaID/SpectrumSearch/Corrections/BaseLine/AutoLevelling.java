package in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections.BaseLine;

import java.util.List;

import in.gov.barc.drhr.raman.spectaID.model.Point;
import in.gov.barc.drhr.raman.spectaID.model.Spectrum;

public class AutoLevelling implements IBaseLineCorrection {

	@Override
	public void correctSpectrum(Spectrum spc,List<Point<Double>> pts) {
		// TODO Auto-generated method stub
	}

}
