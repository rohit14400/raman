package in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections.BaseLine;

import java.util.ArrayList;
import java.util.List;

public enum BaselineNames {
	ALL("All"),
	LINEAR("Linear"),
	AUTO_LEVEL("Auto (GIFTS)");

	private final String text;
	private BaselineNames(final String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return text;
    }

    public List<String> getBaselineNames(){
    	//mind the sequence (same as above)
    	List<String> baselineList = new ArrayList<String>();
    	baselineList.add(LINEAR.toString());
    	return baselineList;
    }
}
