package in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections;

import in.gov.barc.drhr.raman.spectaID.model.SpectrumData;

public class VerticalOffset implements ICorrection{
	private double offset;

	public void setVerticalOffset(SpectrumData spc){
		double[] yData = spc.getYData();
		for(int i=0;i<yData.length;i++){
			yData[i] += offset;
		}
	}

	@Override
	public void applyCorrection(SpectrumData spc) {
		setVerticalOffset(spc);
	}

	@Override
	public void setCorrectionValues(double val){
		this.offset = val;
	}

	@Override
	public double[] getInitialInterval() {
		double[] initialIntervals = {-0.07,-0.04,-0.01,0.03,0.07};
		return initialIntervals;
	}

	@Override
	public double getMinimumVal() {
		return -0.07;
	}

	@Override
	public double getCorrectionValue() {
		return offset;
	}
}
