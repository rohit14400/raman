package in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Distance;

public class SpectralDistanceFactory {
	private SpectralDistanceFactory(){

	}

	public static SpectralDistanceFactory createSpectralDistanceFactory(){
		return new SpectralDistanceFactory();
	}

	public SpectralDistance getSpectralDistance(DistanceMetrics distType){
		switch(distType){
		case EUCLIDEAN:
			return new EuclideanDistance();
		case ABSOLUTE_VALUE:
			return new AbsoluteValue();
		case CORRELATION:
			return new Correlation();
		case FIRSTDERIVATIVE_CORRELATION:
			return new FirstDerivativeCorrelation();
		case LEASTSQUARES:
			return new LeastSquares();
		case FIRSTDERIVATIVE_LEASTSQUARES:
			return new FirstDerivativeLeastSquares();
		default:
			return new EuclideanDistance();
		}
	}
}
