package in.gov.barc.drhr.raman.spectaID.model;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class SpectrumParams {
	private String[] rTypesX = {"cm-1","m","mm","um","nm","pm"};
	private String[] rTypesY = {"Intensity","counts","%"};
	private Map<String, String[]> sTypesMapX,sTypesMapY;
	public SpectrumParams(){
		sTypesMapX = new HashMap<>();
		sTypesMapX.put("Raman", rTypesX);
		sTypesMapY = new HashMap<>();
		sTypesMapY.put("Raman", rTypesY);
	}
	public Set<String> GetTypes(){
		return sTypesMapX.keySet();
	}
	public String[] GetXUnits(String type){
		return sTypesMapX.get(type);
	}
	public String[] GetyUnits(String type){
		return sTypesMapY.get(type);
	}
}
