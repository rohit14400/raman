package in.gov.barc.drhr.raman.spectaAcquire.spectrometer;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class AvantesSpectrometer implements Spectrometer {
	private AtomicBoolean isConnected = new AtomicBoolean(); 
	private AtomicBoolean isLaserConnected = new AtomicBoolean();
	private int laserPower = 0;

	@Override
	public int initialize() {
		return Initialize_jni();
	}

	@Override
	public boolean uninitialize() {
		return Uninitialize_jni();
	}

	@Override
	public List<String> getDeviceList(int nDevices) {
		return GetDeviceList_jni(nDevices);
	}

	@Override
	public boolean connect(String serialNo) {
		isConnected.set(Connect_jni(serialNo));
		return isConnected.get();
	}
	
	@Override
	public boolean isConnected() {
		return isConnected.get();
	}

	@Override
	public boolean disconnect() {
		boolean status = Disconnect_jni();
		isConnected.set(!status);
		return status;
	}

	@Override
	public int getNoOfPixels() {
		return GetNoOfPixels_jni();
	}

	@Override
	public CMeasurementSettings readConfigFromDevice() {
		return ReadConfigFromDevice_jni();
	}

	@Override
	public int writeConfigToDevice(CMeasurementSettings deviceConfig) {
		return WriteConfigToDevice_jni(deviceConfig);
	}

	@Override
	public boolean isDataAvailable() {
		return IsDataAvailable_jni();
	}

	@Override
	public boolean prepareMeasure(CMeasurementSettings settings) {
		return PrepareMeasure_jni(settings);
	}

	@Override
	public double[] getWavellength() {
		return GetWavellength_jni();
	}

	@Override
	public double[] getSpectrumData(int[] a_pTimeLabel) {
		return GetSpectrumData_jni();
	}

	@Override
	public boolean stopMeasure() {
		return StopMeasure_jni();
	}

	@Override
	public char[] getSaturatedPixels() {
		return GetSaturatedPixels_jni();
	}
	
	public DetectorType getDetectorParams() {
		return getDetectorParams_jni();
	}
	
	@Override
	public String getLastError() {
		return getLastError_jni();
	}
	
	@Override
	public boolean laserOnOff(boolean isOff) {
		boolean status = LaserOnOff_jni(isOff);
		if(status) {
			isLaserConnected.set(isOff);
			return true;
		}
		return false;
	}

	@Override
	public boolean initializeLaser() {
		return InitializeLaser_jni();
	}

	@Override
	public boolean setLaserPower(int percent) {
		if(SetLaserPower_jni(percent)) {
			 laserPower = percent;
			 return true;
		 }
		return false;
	}
	
	@Override
	public boolean isLaserConnected() {
		return isLaserConnected.get();
	}

	@Override
	public int getLaserPower() {
		return laserPower;
	}
	
	@Override
	public List<String> getDeviceListTest(int nDevices) {
		return GetDeviceListTest_jni(nDevices);
	}
	
	private native int Initialize_jni();
	private native boolean Uninitialize_jni();
	private native List<String> GetDeviceList_jni(int nDevices);
	private native boolean Connect_jni(String serialNo);
	private native boolean Disconnect_jni();
	private native int GetNoOfPixels_jni();
	private native CMeasurementSettings ReadConfigFromDevice_jni();
	private native int WriteConfigToDevice_jni(CMeasurementSettings l_pDeviceConfig);
	private native boolean IsDataAvailable_jni();
	private native boolean PrepareMeasure_jni(CMeasurementSettings settings);
	private native double[] GetWavellength_jni();
	private native double[] GetSpectrumData_jni();
	private native boolean StopMeasure_jni();
	private native char[] GetSaturatedPixels_jni();
	private native DetectorType getDetectorParams_jni();
	private native String getLastError_jni();
	private native boolean LaserOnOff_jni(boolean isOff);
	private native boolean SetLaserPower_jni(int percent);
	private native boolean InitializeLaser_jni();
	private native List<String> GetDeviceListTest_jni(int nDevices);
}
