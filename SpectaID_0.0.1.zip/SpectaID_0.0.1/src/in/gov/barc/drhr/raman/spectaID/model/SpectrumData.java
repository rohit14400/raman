package in.gov.barc.drhr.raman.spectaID.model;

import java.io.Serializable;

import in.gov.barc.drhr.raman.spectaID.Preprocessing.Normalize;

public class SpectrumData implements Serializable{
	/**
	 *
	 */
	private static final long serialVersionUID = 8329563677294974085L;
	private double xStart;
	private double xEnd;
	private String xUnit,yUnit;
	private double yMin,yMax;
    private double[] xData;
    private double[] yData;
	private transient boolean isNormalized = false;

    public SpectrumData(){
    }

    public SpectrumData(SpectrumData spcData){
    	xData = spcData.xData.clone();
    	yData = spcData.yData.clone();
    	xStart = spcData.xStart;
    	xEnd = spcData.xEnd;
    	yMin = spcData.yMin;
    	yMax = spcData.yMax;
    	normalizeData();
    }

	public void setXYData(double[] xData,double[] yData){
		this.xData = xData;
		this.yData = yData;
		normalizeData();
	}

	public void copySpectrumData(SpectrumData spcData){
		if(this.xData != null || this.yData != null){
			this.xData = null; this.yData = null;
		}
		this.xData = spcData.getXData().clone();
		this.yData = spcData.getYData().clone();
		this.xStart = spcData.getxStart(); this.xEnd = spcData.getxEnd();
		this.xUnit = spcData.getxUnit(); this.yUnit = spcData.getyUnit();
		this.yMin = spcData.getyMin(); this.yMax = spcData.getyMax();
	}

	public double[] getXData(){
		return xData;
	}

	public void setXData(double[] xData){
		this.xData = xData;
	}

	public double[] getYData(){
		return yData;
	}

	public void setYData(double[] yData){
		this.yData = yData;
	}

	public String getxUnit() {
		return xUnit;
	}

	public void setxUnit(String xUnit) {
		this.xUnit = xUnit;
	}

	public String getyUnit() {
		return yUnit;
	}

	public void setyUnit(String yUnit) {
		this.yUnit = yUnit;
	}

	public double getMaxY() {
		double maxY = 0.0;
		for (double d : yData) {
			if(d > maxY){
				maxY = d;
			}
		}
		return maxY;
	}

	public double getMaxX() {
		double maxX = 0.0;
		for (double d : xData) {
			if(d > maxX){
				maxX = d;
			}
		}
		return maxX;
	}

	public double getxStart() {
		return xStart;
	}

	public void setxStart(double xStart) {
		this.xStart = xStart;
	}

	public double getxEnd() {
		return xEnd;
	}

	public void setxEnd(double xEnd) {
		this.xEnd = xEnd;
	}

	public double getyMin() {
		return yMin;
	}

	public void setyMin(double yMin) {
		this.yMin = yMin;
	}

	public double getyMax() {
		return yMax;
	}

	public void setyMax(double yMax) {
		this.yMax = yMax;
	}

	public void normalizeData(){
		Normalize normalize = new Normalize();
		setYData(normalize.normalizeData(yData, yMin, yMax));
		isNormalized = true;
		yMin = 0; yMax = 1.0;
	}

	public boolean isNormalized() {
		return isNormalized;
	}

	public void setNormalized(boolean isNormalized) {
		this.isNormalized = isNormalized;
	}
}
