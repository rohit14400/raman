package in.gov.barc.drhr.raman.spectaAcquire.spectrometer.ui;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SpectrumInfoController {
	@FXML private TextField timeStampField;
	@FXML private TextField integrationTimeField;
	@FXML private TextField nAvgsField;
	@FXML private TextField nSmoothingPixelsField;
	@FXML private TextArea descriptionArea;
	private Stage dialogStage;
	
	public void setDialogStage(Stage dialogStage) {
		this.dialogStage = dialogStage;
	}
	
	@FXML private void initialize() {
		//TODO
	}
	
	@FXML private void onBtnClickSave() {
		//TODO
	}
	
	@FXML private void onBtnClickCancel() {
		if(dialogStage != null) {
			dialogStage.close();
		}
	}
}
