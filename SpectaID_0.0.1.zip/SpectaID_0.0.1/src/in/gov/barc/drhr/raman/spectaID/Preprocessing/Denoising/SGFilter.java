package in.gov.barc.drhr.raman.spectaID.Preprocessing.Denoising;

import java.util.Arrays;
import org.apache.commons.math3.linear.DecompositionSolver;
import org.apache.commons.math3.linear.LUDecomposition;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealVector;

public class SGFilter implements IFilter {
	private int nl = 4,nr = 4;
	private int nDegree;

	public SGFilter(){
		nDegree = nl + nr - 1;
	}

	public SGFilter(int nl,int nr) {
		this.nl = nl;
		this.nr = nr;
		nDegree = nl + nr - 1;
	}

	@Override
	public double[] smooth(double[] data) {
		double[] coeffs = computeSGCoefficients(nl, nr, nDegree);
		if(coeffs != null){
			return smooth(data, coeffs);
		}
		return null;
	}

	public void setNl(int nl){
		this.nl = nl;
	}

	public void setNr(int nr){
		this.nr = nr;
	}

	public void setDegree(int nDegree){
		this.nDegree = nDegree;
	}

	public double[] computeSGCoefficients(int nl, int nr, int degree) {
		if (nl < 0 || nr < 0 || (nl + nr) < degree)
			throw new IllegalArgumentException("Bad arguments");

		RealMatrix matrix = MatrixUtils.createRealMatrix(degree + 1, degree + 1);
		double[] b = new double[degree + 1];
		b[0] = 1;
		RealVector bVect = MatrixUtils.createRealVector(b);
		double sum;
		for (int i = 0; i <= degree; i++) {
			for (int j = 0; j <= degree; j++) {
				sum = (i == 0 && j == 0) ? 1 : 0;
				for (int k = 1; k <= nr; k++){
					sum += Math.pow(k, i + j);
				}
				for (int k = 1; k <= nl; k++){
					sum += Math.pow(-k, i + j);
				}
				matrix.setEntry(i, j, sum);
			}
		}
		DecompositionSolver solver = new LUDecomposition(matrix).getSolver();
		bVect = solver.solve(bVect);
		b = bVect.toArray();
		double[] coeffs = new double[nl + nr + 1];
		for (int n = -nl; n <= nr; n++) {
			sum = b[0];
			for (int m = 1; m <= degree; m++)
				sum += b[m] * Math.pow(n, m);
			coeffs[n + nl] = sum;
		}
		return coeffs;
	}

	private double[] smooth(double[] data, double[] coeffs) {
		return smooth(data, 0, data.length, coeffs);
	}

	public double[] smooth(double[] data, int from, int to, double[] coeffs) {
		return smooth(data, from, to, 0, new double[][] { coeffs });
	}

	public double[] smooth(double[] data, int from, int to, int bias, double[][] coeffs) {
		double[] leftPad = Arrays.copyOfRange(data, 0, from);
		double[] rightPad = Arrays.copyOfRange(data, to, data.length);
		double[] dataCopy = Arrays.copyOfRange(data, from, to);
		return smooth(dataCopy, leftPad, rightPad, bias, coeffs);
	}

	public double[] smooth(double[] data, double[] leftPad, double[] rightPad, double[] coeffs) {
		return smooth(data, leftPad, rightPad, 0, new double[][] { coeffs });
	}

	public double[] smooth(double[] data, double[] leftPad, double[] rightPad, int bias, double[][] coeffs) {
		if (bias < 0 || bias > nr || bias > nl){
			throw new IllegalArgumentException("bias < 0 or bias > nr or bias > nl");
		}
		int dataLength = data.length;
		if (dataLength == 0){
			return null;
		}
		int n = dataLength + nl + nr;
		double[] dataCopy = new double[n];
		// copy left pad reversed
		int leftPadOffset = nl - leftPad.length;
		if (leftPadOffset >= 0){
			for (int i = 0; i < leftPad.length; i++) {
				dataCopy[leftPadOffset + i] = leftPad[i];
			}
		}else{
			for (int i = 0; i < nl; i++) {
				dataCopy[i] = leftPad[i - leftPadOffset];
			}
		}
		// copy actual data
		for (int i = 0; i < dataLength; i++) {
			dataCopy[i + nl] = data[i];
		}

		// copy right pad
		int rightPadOffset = nr - rightPad.length;
		if (rightPadOffset >= 0){
			for (int i = 0; i < rightPad.length; i++) {
				dataCopy[i + dataLength + nl] = rightPad[i];
			}
		}else{
			for (int i = 0; i < nr; i++) {
				dataCopy[i + dataLength + nl] = rightPad[i];
			}
		}
		//symmteric boundary condition RS
		for(int i=0;i<nr;i++){
			dataCopy[i+dataLength+nl] = data[dataLength-i-1];
		}
		for(int i=0;i<nl;i++){
			dataCopy[i] = data[nl-i-1];
		}
		// convolution (with savitzky-golay coefficients)
		double[] sdata = new double[dataLength];
		double[] sg;
		for (int b = bias; b > 0; b--) {
			sg = coeffs[coeffs.length - b];
			int x = (nl + bias) - b;
			double sum = 0;
			for (int i = -nl + b; i <= nr; i++) {
				sum += dataCopy[x + i] * sg[nl - b + i];
			}
			sdata[x - nl] = sum;
		}
		sg = coeffs[0];
		for (int x = nl + bias; x < n - nr - bias; x++) {
			double sum = 0;
			for (int i = -nl; i <= nr; i++) {
				sum += dataCopy[x + i] * sg[nl + i];
			}
			sdata[x - nl] = sum;
		}
		for (int b = 1; b <= bias; b++) {
			sg = coeffs[b];
			int x = (n - nr - bias) + (b - 1);
			double sum = 0;
			for (int i = -nl; i <= nr - b; i++) {
				sum += dataCopy[x + i] * sg[nl + i];
			}
			sdata[x - nl] = sum;
		}
		return sdata;
	}
}
