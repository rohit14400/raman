package in.gov.barc.drhr.raman.spectaID.view.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import in.gov.barc.drhr.raman.spectaID.Main;
import in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections.CorrectionNames;
import in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Distance.DistanceMetrics;
import in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Main.HitSpectrum;
import in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Main.SearchSpectrum;
import in.gov.barc.drhr.raman.spectaID.model.Spectrum;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.Slider;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.util.Callback;

public class FullSpcSearchController {
	@FXML private ComboBox<String> distanceMetrics;
	@FXML private TableView<String> correctionsTable;
	@FXML private TableColumn<String, String> nameCol;
	@FXML private TableColumn<String, Boolean> selCol;
	@FXML private Slider hitListSize;
	private Map<String, Boolean> correctionsMap = new TreeMap<String, Boolean>();
	private Main mainApp;
	private List<HitSpectrum> hitList;
	private Task<List<HitSpectrum>> spectrumSearchTask;
	private SearchSpectrum spcSearch;

	public void setMainApp(Main mainApp){
		this.mainApp = mainApp;
	}

	@FXML private void initialize(){
		List<String> corrList = CorrectionNames.ALL.getCorrectionNames();
		for(String str:corrList){
			correctionsMap.put(str, false);
		}
		distanceMetrics.getItems().addAll(DistanceMetrics.ALL.getDistanceMetrics());
		distanceMetrics.getSelectionModel().selectFirst();
		selCol.setCellValueFactory( new PropertyValueFactory<String,Boolean>( "checkBoxValue" ) );
		selCol.setCellFactory(CheckBoxTableCell.forTableColumn(selCol));
		selCol.setCellValueFactory(new Callback<CellDataFeatures<String, Boolean>, ObservableValue<Boolean>>() {
            @Override
            public ObservableValue<Boolean> call(CellDataFeatures<String, Boolean> param) {
                String corrStr = param.getValue();
                SimpleBooleanProperty booleanProp = new SimpleBooleanProperty(correctionsMap.get(corrStr));
                // CheckBoxTableCell..
                booleanProp.addListener(new ChangeListener<Boolean>() {
                    @Override
                    public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue,
                            Boolean newValue) {
                    	correctionsMap.replace(corrStr, newValue);
                    }
                });
                return booleanProp;
            }
        });

		selCol.setEditable(true);
		nameCol.setCellValueFactory(new Callback<CellDataFeatures<String, String>, ObservableValue<String>>() {
		     public ObservableValue<String> call(CellDataFeatures<String, String> p) {
		         return new SimpleStringProperty(p.getValue());
		     }
		  });
		correctionsTable.setEditable(true);
		correctionsTable.setItems(FXCollections.observableArrayList(corrList));
	}

	@FXML public void onBtnClickSearch(){
		Spectrum unknownSpect = mainApp.getUnknownSpectrum();
		if(unknownSpect == null){
			Alert errDlg = new Alert(AlertType.ERROR);
			errDlg.setTitle("Spectrum Search");
			errDlg.setHeaderText("Spectrum search failed!! No spectrum is active or opened");
			errDlg.setContentText("Please open unknown spectum for searching by clicking on \"Open\" button in toolbar");
			errDlg.initOwner(mainApp.getPrimaryStage());
			errDlg.showAndWait();
			return;
		}
		if(mainApp.getSpectrumLibrary() == null || mainApp.getSpectrumLibrary().size() == 0){
			Alert errDlg = new Alert(AlertType.ERROR);
			errDlg.setTitle("Spectrum Search");
			errDlg.setHeaderText("Spectrum search failed!! No spectrum library selected for searching");
			errDlg.setContentText("Please select spectrum library for searching from \"Database\" tab");
			errDlg.initOwner(mainApp.getPrimaryStage());
			errDlg.showAndWait();
			return;
		}
		spcSearch = new SearchSpectrum();
		spectrumSearchTask = new Task<List<HitSpectrum>>() {
			@Override
			protected List<HitSpectrum> call() throws Exception {
				List<HitSpectrum> hitList = new ArrayList<>();
				spcSearch.setDistanceMode(DistanceMetrics.ALL.getDistanceMetric(distanceMetrics.getSelectionModel().getSelectedIndex()));
				spcSearch.setSpectraLibrary(mainApp.getSpectrumLibrary());
				spcSearch.setCorrections(correctionsMap);
				hitList = spcSearch.getHitList(unknownSpect,(int)hitListSize.getValue());
				return hitList;
			}
		};
		Stage stage = showProgressBar();
		
		spectrumSearchTask.setOnSucceeded(new EventHandler<WorkerStateEvent>() {
			@Override
			public void handle(WorkerStateEvent arg0) {
				hitList = spectrumSearchTask.getValue();
				if(hitList != null && hitList.size() > 0) {
					mainApp.setHitList(hitList);
				}
				stage.close();
			}
		});
		new Thread(spectrumSearchTask).start();
		stage.showAndWait();
	}
	
	private void stopSearchTask() {
		if(spcSearch != null && spectrumSearchTask.isRunning()) {
			spcSearch.stopSearch();
		}
	}
	
	private Stage showProgressBar() {
		ProgressBar bar = new ProgressBar();
		Button stopButton = new Button("Stop");
		stopButton.setPrefWidth(80);
		stopButton.setPrefHeight(25);
		VBox vbox = new VBox(bar, stopButton);
		vbox.setAlignment(Pos.CENTER);
		vbox.setSpacing(10.0);
		bar.prefWidthProperty().bind(vbox.widthProperty());
		stopButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent arg0) {
				stopSearchTask();
			}
		});
		Stage stage = new Stage();
		stage.setScene(new Scene(vbox));
		stage.setTitle("Search spectrum");
		stage.setHeight(100);
		stage.setWidth(400);
		stage.setResizable(false);
		stage.initOwner(mainApp.getPrimaryStage());
		stage.initModality(Modality.APPLICATION_MODAL);
		return stage;
	}
}
