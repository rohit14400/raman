package in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections.BaseLine;

public class BaselineFactory {
	public BaselineFactory(){

	}

	public IBaseLineCorrection getBaselineObj(BaselineNames baselineType){
		switch(baselineType){
		case LINEAR:
			return new Linear();
		case AUTO_LEVEL:
			return new AutoLevelling();
		default:
			return new Linear();
		}
	}
}
