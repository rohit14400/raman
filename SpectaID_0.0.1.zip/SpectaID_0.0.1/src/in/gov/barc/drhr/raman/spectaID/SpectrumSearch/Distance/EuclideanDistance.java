package in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Distance;

import java.util.Arrays;

import in.gov.barc.drhr.raman.spectaID.model.SpectrumData;

public class EuclideanDistance extends SpectralDistance {

	@Override
	public double getDistance(SpectrumData spcUnk, SpectrumData spcLib) {
		double[] yUnkNormalized = spcUnk.isNormalized()?spcUnk.getYData():normalizeData(spcUnk);
		double[] yLibNormalized = spcLib.isNormalized()?spcLib.getYData():normalizeData(spcLib);
		calculateRange(spcUnk, spcLib);
		interpolate.interpolate(Arrays.copyOfRange(spcUnk.getXData(), startIdx, endIdx),
				Arrays.copyOfRange(yUnkNormalized, startIdx, endIdx));
		double[] xDataLib = spcLib.getXData();

		double dotLibUnk = 0.0,dotLibLib = 0.0,dotUnkUnk = 0.0;
		for(int i=0;i<xDataLib.length;i++){
			if(xDataLib[i] < xStart){
				continue;
			}
			if(xDataLib[i] > xEnd){
				break;
			}
			double currUnkVal = interpolate.getValue(xDataLib[i]);
			double currLibVal = yLibNormalized[i];
			dotLibUnk += (currLibVal * currUnkVal);
			dotLibLib += (currLibVal * currLibVal);
			dotUnkUnk += (currUnkVal * currUnkVal);
		}
		yUnkNormalized = null; yLibNormalized = null; xDataLib = null;
		return (Math.sqrt(2) - Math.sqrt(Math.max(1.0 - dotLibUnk / (Math.sqrt(dotLibLib) * Math.sqrt(dotUnkUnk)),0.0))) * 100;
	}
}
