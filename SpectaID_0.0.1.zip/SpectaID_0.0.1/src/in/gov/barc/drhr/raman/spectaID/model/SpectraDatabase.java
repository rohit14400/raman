package in.gov.barc.drhr.raman.spectaID.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SpectraDatabase implements Serializable{
	/**
	 *
	 */
	private static final long serialVersionUID = -4534992069739336504L;
	private String dbName;
	private String dbId;
	private String dbVersion;
	private String dbDesc;
	private String dbPath;

	private List<Spectrum> spcList = new ArrayList<>();

	public String getDbName() {
		return dbName;
	}

	public void setDbName(String dbName) {
		this.dbName = dbName;
	}

	public String getDbId() {
		return dbId;
	}

	public void setDbId(String dbId) {
		this.dbId = dbId;
	}

	public String getDbVersion() {
		return dbVersion;
	}

	public void setDbVersion(String dbVersion) {
		this.dbVersion = dbVersion;
	}

	public String getDbDesc() {
		return dbDesc;
	}

	public void setDbDesc(String dbDesc) {
		this.dbDesc = dbDesc;
	}

	public String getDbPath() {
		return dbPath;
	}

	public void setDbPath(String dbPath) {
		this.dbPath = dbPath;
	}

	public void addSpectrum(Spectrum spc){
		spcList.add(spc);
	}

	public List<Spectrum> getSpectrums(){
		return spcList;
	}

	public int getSpectrumCount(){
		return spcList.size();
	}

	@Override
	public String toString() {
		return dbName;
	}
}
