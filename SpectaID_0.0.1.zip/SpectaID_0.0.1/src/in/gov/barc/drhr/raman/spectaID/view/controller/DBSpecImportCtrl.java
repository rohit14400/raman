package in.gov.barc.drhr.raman.spectaID.view.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.control.cell.CheckBoxListCell;
import javafx.stage.Stage;
import javafx.util.Callback;

public class DBSpecImportCtrl {
	@FXML TreeView<File> directoryTree;
	@FXML ListView<File> fileView;
	@FXML ListView<File> selFilesView;
	@FXML ComboBox<String> fileTypes;
	@FXML Button applyBtn;
	@FXML Button cancelBtn;
	@FXML Button addAllBtn;
	@FXML Button addSelBtn;
	@FXML Button removeSpecBtn;
	@FXML Button clearSpcListBtn;
	private Stage dialogStage;
	private ObservableList<File> selectedFiles = FXCollections.observableArrayList();
	private List<File> selCheckboxFileList = new ArrayList<>();

	public void setDialogStage(Stage dialogStage) {
		this.dialogStage = dialogStage;
	}
	/**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
    	fileView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    	selFilesView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    	fileTypes.getItems().addAll("*.*","*.txt","*.rruff");
    	fileTypes.getSelectionModel().selectFirst();
    	File[] rootListPaths = File.listRoots();
    	TreeItem<File> rootItem = new TreeItem<>();
    	rootItem.setExpanded(true);
    	directoryTree.setRoot(rootItem);
    	for(File f:rootListPaths){
        	TreeItem<File> childItem = createDirectoryTree(f);
        	rootItem.getChildren().add(childItem);
    	}
    	directoryTree.setShowRoot(false);
    	directoryTree.setCellFactory(tv -> {
            TreeCell<File> cell = new TreeCell<File>() {
                @Override
                public void updateItem(File f,boolean empty){
                    super.updateItem(f, empty);
                    if (empty) {
                        setText(null);
                    } else {
                    	if(f.getName().compareTo("") == 0){
                    		setText(f.getPath());
                    	}else{
                    		setText(f.getName());
                    	}
                    }
                }
            };
            return cell;
        });

    	directoryTree.getSelectionModel().selectedItemProperty().addListener( new ChangeListener<TreeItem<File>>() {
            @Override
            public void changed(ObservableValue<? extends TreeItem<File>> observable, TreeItem<File> oldValue, TreeItem<File> newValue) {
                TreeItem<File> selectedItem =  newValue;
                if(selectedItem != null){
    				//Add to file view
    				File[] files = selectedItem.getValue().listFiles();
    				fileView.getItems().clear();
    				if(files == null){
    					return;
    				}
    				for (File file : files) {
    					String selectedType = fileTypes.getSelectionModel().getSelectedItem();
    					if((!file.isDirectory()) &&
    							((FilenameUtils.getExtension(file.getAbsolutePath()).compareTo(FilenameUtils.getExtension(selectedType)) == 0)
    							|| (selectedType.compareTo("*.*") == 0))){
    						fileView.getItems().add(file);
    					}
    				}
    			}
            }
          });

    	fileView.setCellFactory(tv -> {
            CheckBoxListCell<File> cell = new CheckBoxListCell<File>() {
                @Override
                public void updateItem(File f,boolean empty){
                    super.updateItem(f, empty);
                    if (empty) {
                        setText(null);
                    } else {
                    	if(f.getName().compareTo("") == 0){
                    		setText(f.getPath());
                    	}else{
                    		setText(f.getName());
                    	}
                    }
                }
            };

            cell.setSelectedStateCallback( new Callback<File, ObservableValue<Boolean>>() {
                @Override
                public ObservableValue<Boolean> call(File item) {
                    BooleanProperty observable = new SimpleBooleanProperty();
                    observable.addListener((obs, wasSelected, isNowSelected) ->{
	                    	if(isNowSelected){
	                    		selCheckboxFileList.add(item);
	                    	}else{
	                    		selCheckboxFileList.remove(item);
	                    	}
	                    }
                    );
                    return observable;
                }
            }
            );
            return cell;
        });

    	selFilesView.setCellFactory(tv -> {
            ListCell<File> cell = new ListCell<File>() {
                @Override
                public void updateItem(File f,boolean empty){
                    super.updateItem(f, empty);
                    if (empty) {
                        setText(null);
                    } else {
                    	if(f.getName().compareTo("") == 0){
                    		setText(f.getPath());
                    	}else{
                    		setText(f.getName());
                    	}
                    }
                }
            };
            return cell;
        });

    	selFilesView.setItems(selectedFiles);
    }

	@FXML void onBtnClickApply(){
	/*	LoadSpectrum lpsc = new LoadSpectrum();
		//insert imported spectrum into database
		ISpectrumDAO spcDAO = new SpectrumDAOImpl();
		for(File file:selectedFiles){
			if(FilenameUtils.getExtension(file.getAbsolutePath()).compareToIgnoreCase("TXT") == 0){
				Spectrum spc = lpsc.LoadSpectrumRRUFF(file);
				spcList.add(spc);
			}
		}
		if(!spcDAO.batchInsertSpectrum(spcList)){
			Alert errDlg = new Alert(AlertType.ERROR);
			errDlg.setTitle("Database Insert Error");
			errDlg.setContentText("Could not insert spectrum to databse");
			errDlg.setHeaderText("Spectrum data persistence error");
		} */
		dialogStage.close();
	}

	@FXML void onBtnClickCancel(){
		dialogStage.close();
	}

	@FXML public void onBtnClickAddAll(){
		Iterator<File> fileIt = fileView.getItems().iterator();
		while(fileIt.hasNext()){
			selectedFiles.add(fileIt.next());
		}
	}

	@FXML public void onBtnClickRemoveSpc(){
		Iterator<File> fileIt = selFilesView.getSelectionModel().getSelectedItems().iterator();
		while(fileIt.hasNext()){
			selectedFiles.remove(fileIt.next());
		}
	}

	@FXML public void onBtnClickClearSpcList(){
		selectedFiles.clear();
	}

	@FXML public void onBtnClickAddSel(){
		Iterator<File> spcListIt = selCheckboxFileList.iterator();
		while(spcListIt.hasNext()){
			selectedFiles.add(spcListIt.next());
		}
	}

	private TreeItem<File> createDirectoryTree(File f){
		return new TreeItem<File>(f) {
	          private boolean isLeaf;
	          private boolean isFirstTimeChildren = true;
	          private boolean isFirstTimeLeaf = true;

	          @Override public ObservableList<TreeItem<File>> getChildren() {
	              if (isFirstTimeChildren) {
	                  isFirstTimeChildren = false;
	                  super.getChildren().setAll(buildChildren(this));
	              }
	              return super.getChildren();
	          }

	          @Override public boolean isLeaf() {
	              if (isFirstTimeLeaf) {
	                  isFirstTimeLeaf = false;
	                  File f = (File) getValue();
	                  isLeaf = f.isFile();
	              }
	              return isLeaf;
	          }

	          private ObservableList<TreeItem<File>> buildChildren(TreeItem<File> TreeItem) {
	              File f = TreeItem.getValue();
	              if (f != null && f.isDirectory()) {
	                  File[] files = f.listFiles();
	                  if (files != null) {
	                      ObservableList<TreeItem<File>> children = FXCollections.observableArrayList();
	                      for (File childFile : files) {
	                    	  if(childFile.isDirectory()){
	                    		  children.add(createDirectoryTree(childFile));
	                    	  }
	                      }

	                      return children;
	                  }
	              }
	              return FXCollections.emptyObservableList();
	          }
	      };
	}


	public List<File> getSelectedSpectraList(){
		return selectedFiles.subList(0, selectedFiles.size());
	}
}
