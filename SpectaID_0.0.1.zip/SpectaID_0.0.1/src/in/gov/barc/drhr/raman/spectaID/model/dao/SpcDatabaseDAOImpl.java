package in.gov.barc.drhr.raman.spectaID.model.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import in.gov.barc.drhr.raman.spectaID.model.SpectraDatabase;
import in.gov.barc.drhr.raman.spectaID.model.Spectrum;

public class SpcDatabaseDAOImpl implements ISpectraDatabaseDAO {
	@Override
	public List<SpectraDatabase> getAll(File path) {
		List<SpectraDatabase> dbList = new ArrayList<SpectraDatabase>();
		File[] files = path.listFiles((dir, name) -> name.toLowerCase().endsWith(".rspx"));
		for (int i = 0; i < files.length; i++) {
			SpectraDatabase e = null;
			try {
				 FileInputStream fileIn = new FileInputStream(files[i].getAbsolutePath());
				 ObjectInputStream in = new ObjectInputStream(fileIn);
				 e = (SpectraDatabase) in.readObject();
				 in.close();
				 fileIn.close();
				 dbList.add(e);
			  }catch(IOException ex) {
			  }catch(ClassNotFoundException c) {
			  }
		}
		return dbList;
	}

	@Override
	public List<SpectraDatabase> getByName() {
		return null;
	}

	@Override
	public List<SpectraDatabase> getById() {

		return null;
	}

	@Override
	public boolean insertDatabase(SpectraDatabase spcDatabase){
		try {
	         FileOutputStream fileOut = new FileOutputStream(spcDatabase.getDbPath() + "\\" + spcDatabase.getDbName());
	         ObjectOutputStream out = new ObjectOutputStream(fileOut);
	         out.writeObject(spcDatabase);
	         out.close();
	         fileOut.close();
	      }catch(IOException i) {
	         i.printStackTrace();
	      }
	    return true;
	}

	@Override
	public boolean updateDatabase(SpectraDatabase spcDatabase) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean removeDatabase(SpectraDatabase spcDatabase) {
		return false;
	}

	@Override
	public boolean addSPCsToDB(SpectraDatabase spcDatabase,List<Spectrum> spcList){
		spcDatabase.getSpectrums().addAll(spcList);
		try {
	         FileOutputStream fileOut = new FileOutputStream(spcDatabase.getDbPath() + "\\" + spcDatabase.getDbName());
	         ObjectOutputStream out = new ObjectOutputStream(fileOut);
	         out.writeObject(spcDatabase);
	         out.close();
	         fileOut.close();
	      }catch(IOException i) {
	         i.printStackTrace();
	      }
		return true;
	}

	@Override
	public boolean removeSPCsFromDB(SpectraDatabase spcDatabase, List<Spectrum> spcList) {
		spcDatabase.getSpectrums().removeAll(spcList);
		try {
	         FileOutputStream fileOut = new FileOutputStream(spcDatabase.getDbPath() + "\\" + spcDatabase.getDbName());
	         ObjectOutputStream out = new ObjectOutputStream(fileOut);
	         out.writeObject(spcDatabase);
	         out.close();
	         fileOut.close();
	      }catch(IOException i) {
	         i.printStackTrace();
	      }
		return true;
	}

	@Override
	public void close(){
		//PersistenceManager.INSTANCE.close();
	}

	@Override
	public List<Spectrum> getSpcsFromDB(SpectraDatabase spcDatabase,int offset,int limit){
		return spcDatabase.getSpectrums();
	}

	@Override
	public Long getSpectrumCount(SpectraDatabase spcDatabase){
		return (long) spcDatabase.getSpectrumCount();
	}
}
