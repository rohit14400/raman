package in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections;

import in.gov.barc.drhr.raman.spectaID.model.SpectrumData;

public class HorizontalOffset implements ICorrection{
	private double offset;

	private void setHorizontalOffset(SpectrumData spc){
		double[] xData = spc.getXData();
		for(int i=0;i<xData.length;i++){
			xData[i] += offset;
		}
	}

	@Override
	public void applyCorrection(SpectrumData spc) {
		setHorizontalOffset(spc);
	}

	@Override
	public void setCorrectionValues(double val){
		this.offset = val;
	}

	@Override
	public double[] getInitialInterval() {
		double[] intervalValues = {-3.0,-1.8,0.6,1.8,3.0};
		return intervalValues;
	}

	@Override
	public double getMinimumVal() {
		return -3.0;
	}

	@Override
	public double getCorrectionValue() {
		return offset;
	}

}
