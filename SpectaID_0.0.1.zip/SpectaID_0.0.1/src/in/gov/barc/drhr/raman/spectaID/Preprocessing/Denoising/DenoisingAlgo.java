package in.gov.barc.drhr.raman.spectaID.Preprocessing.Denoising;

import java.util.ArrayList;
import java.util.List;

public enum DenoisingAlgo {
	SAVITZKY_GOLAY("Savitzky-Golay"),
	;
	private final String text;
	DenoisingAlgo(final String type){
		this.text = type;
	}

	@Override
    public String toString() {
        return text;
    }

    public List<String> getAlgoNames(){
    	//mind the sequence (same as above)
    	List<String> names = new ArrayList<String>();
    	names.add(SAVITZKY_GOLAY.toString());
    	return names;
    }
}
