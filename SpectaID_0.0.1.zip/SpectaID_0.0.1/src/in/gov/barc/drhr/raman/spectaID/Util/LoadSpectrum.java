package in.gov.barc.drhr.raman.spectaID.Util;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.Map.Entry;

import in.gov.barc.drhr.raman.spectaID.model.Spectrum;

import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.io.FilenameUtils;

public class LoadSpectrum {
	
	public Spectrum loadSpectrum(File f) {
		String ext = FilenameUtils.getExtension(f.getAbsolutePath());
		if(ext.equalsIgnoreCase("rruff") || ext.equalsIgnoreCase("txt") ) {
			return loadSpectrumRRUFF(f);
		}else {
			return loadCSVFiles(f);
		}
	}

	public Spectrum loadSpectrumRRUFF(File f){
		SortedMap<Double, Double> spcData = new TreeMap<Double, Double>();
		Spectrum spc = new Spectrum();
		try{
    		FileInputStream fstream = new FileInputStream(f.getAbsolutePath());
    	    DataInputStream in = new DataInputStream(fstream);
    	    BufferedReader br = new BufferedReader(new InputStreamReader(in));
    	    String strLine;
    	    while ((strLine = br.readLine()) != null)   {
    	    	if(strLine.startsWith("##")){
    	    		String[] tokens = strLine.substring(2).split("=");
    	    		try{
	    	    		if(tokens[0].compareTo("NAMES") == 0){
	    	    			spc.getCompound().setCompoundName(tokens[1]);
	    	    		}else if(tokens[0].compareTo("RRUFFID") == 0){
	    	    			spc.setSpectrumId(tokens[1]);
	    	    		}else if(tokens[0].compareTo("LOCALITY") == 0){
	    	    			spc.getInstrument().setSampleSource(tokens[1]);
	    	    		}else if(tokens[0].compareTo("CHEMISTRY") == 0){
	    	    			spc.getCompound().setChemFormula(tokens[1]);
	    	    		}else if(tokens[0].compareTo("IDEAL CHEMISTRY") == 0){
	    	    			spc.getCompound().setChemFormula(tokens[1]);
	    	    		}else if(tokens[0].compareTo("DESCRIPTION") == 0){
	    	    			spc.setSpectrumDescription(tokens[1]);
	    	    		}else if(tokens[0].compareTo("SOURCE") == 0){
	    	    			spc.getInstrument().setSpectSource(tokens[1]);
	    	    		}else if(tokens[0].compareTo("URL") == 0){
	    	    			spc.setFilePath(tokens[1]);
	    	    		}else if(tokens[0].compareTo("END") == 0){
	    	    			break;
	    	    		}
    	    		}catch(ArrayIndexOutOfBoundsException e){
    	    			//can occur when tokens[1] is null
    	    			continue;
    	    		}
    	    	}else{
    	    		String[] tokens = strLine.split("[,\t]+");
    	    		spcData.put(Double.parseDouble(tokens[0]), Double.parseDouble(tokens[1]));
    	    	}
    	    }
    	    double[] xData = new double[spcData.size()];
    	    double[] yData = new double[spcData.size()];
    	    Iterator<Entry<Double, Double>> mapEntry = spcData.entrySet().iterator();
    	    int i=0;
    	    double yMin = Double.POSITIVE_INFINITY,yMax = Double.NEGATIVE_INFINITY;
    	    while(mapEntry.hasNext()){
    	    	Entry<Double,Double> keyValue = mapEntry.next();
    	    	xData[i] = keyValue.getKey();
    	    	yData[i] = keyValue.getValue();
    	    	if(yMin > yData[i]){
    	    		yMin = yData[i];
    	    	}
    	    	if(yMax < yData[i]){
    	    		yMax = yData[i];
    	    	}
    	    	i++;
    	    }
    	    if(spcData.size() == 0){
    	    	spc = null;
    	    }else{
    	    	spc.getOriginalData().setyMin(yMin);
	   	    	spc.getOriginalData().setyMax(yMax);
	   	    	spc.getOriginalData().setxStart(spcData.firstKey());
	   	    	spc.getOriginalData().setxEnd(spcData.lastKey());
	   	    	spc.getOriginalData().setXYData(xData, yData);
    	    }
   	    	in.close();
    	}catch (Exception e){
    		e.printStackTrace();
    	}
		return spc;
	}
	
	public Spectrum loadCSVFiles(File f) {
		SortedMap<Double, Double> spcData = new TreeMap<Double, Double>();
		Spectrum spc = new Spectrum();
		try{
    		FileInputStream fstream = new FileInputStream(f.getAbsolutePath());
    	    DataInputStream in = new DataInputStream(fstream);
    	    BufferedReader br = new BufferedReader(new InputStreamReader(in));
    	    String strLine;
    	    while ((strLine = br.readLine()) != null)   {
	    		String[] tokens = strLine.split("[,\t]+");
	    		spcData.put(Double.parseDouble(tokens[0]), Double.parseDouble(tokens[1]));
    	    }
    	    double[] xData = new double[spcData.size()];
    	    double[] yData = new double[spcData.size()];
    	    Iterator<Entry<Double, Double>> mapEntry = spcData.entrySet().iterator();
    	    int i=0;
    	    double yMin = Double.POSITIVE_INFINITY,yMax = Double.NEGATIVE_INFINITY;
    	    while(mapEntry.hasNext()){
    	    	Entry<Double,Double> keyValue = mapEntry.next();
    	    	xData[i] = keyValue.getKey();
    	    	yData[i] = keyValue.getValue();
    	    	if(yMin > yData[i]){
    	    		yMin = yData[i];
    	    	}
    	    	if(yMax < yData[i]){
    	    		yMax = yData[i];
    	    	}
    	    	i++;
    	    }
    	    if(spcData.size() == 0){
    	    	spc = null;
    	    }else{
    	    	spc.getOriginalData().setyMin(yMin);
	   	    	spc.getOriginalData().setyMax(yMax);
	   	    	spc.getOriginalData().setxStart(spcData.firstKey());
	   	    	spc.getOriginalData().setxEnd(spcData.lastKey());
	   	    	spc.getOriginalData().setXYData(xData, yData);
    	    }
        	return spc;
		}catch (Exception e){
			e.printStackTrace();
			return null;
        }
	}
}
