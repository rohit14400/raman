package in.gov.barc.drhr.raman.spectaID.model;

import java.io.Serializable;

public class Compound implements Serializable{
	/**
	 *
	 */
	private static final long serialVersionUID = -3520902591140047330L;
	private String compoundId;
    private String compoundName;
	private String chemFormula;
	private byte[] chemStructure;

	public String getCompoundId() {
		return compoundId;
	}

	public void setCompoundId(String compoundId) {
		this.compoundId = compoundId;
	}

	public String getCompoundName() {
		return compoundName;
	}

	public void setCompoundName(String compoundName) {
		this.compoundName = compoundName;
	}

	public String getChemFormula() {
		return chemFormula;
	}

	public void setChemFormula(String chemFormula) {
		this.chemFormula = chemFormula;
	}

	public byte[] getChemStructure() {
		return chemStructure;
	}

	public void setChemStructure(byte[] chemStructure) {
		this.chemStructure = chemStructure;
	}
}
