package in.gov.barc.drhr.raman.spectaAcquire.spectrometer;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class DummySpectrometer implements Spectrometer{
	private AtomicBoolean isConnected = new AtomicBoolean(); 
	private AtomicBoolean isLaserConnected = new AtomicBoolean();
	private int laserPowerPercent = 0;

	@Override
	public int initialize() {
		return 1;
	}

	@Override
	public boolean uninitialize() {
		return true;
	}

	@Override
	public List<String> getDeviceList(int nDevices) {
		List<String> list = new ArrayList<>();
		list.add("123");
		return list;
	}

	@Override
	public boolean connect(String serialNo) {
		isConnected.set(true);
		return isConnected.get();
	}
	
	@Override
	public boolean isConnected() {
		return isConnected.get();
	}

	@Override
	public boolean disconnect() {
		isConnected.set(false);
		return true;
	}

	@Override
	public int getNoOfPixels() {
		return 2048;
	}

	@Override
	public CMeasurementSettings readConfigFromDevice() {
		CMeasurementSettings measurementSettings = new CMeasurementSettings();
		measurementSettings.setIntegrationTime(20.0);
		measurementSettings.setCorDynDark(false);
		measurementSettings.setIntegrationDelay(10);
		measurementSettings.setLaserDelay(1);
		measurementSettings.setForgetPercentage(10);
		measurementSettings.setLaserWaveLength(200);
		measurementSettings.setLaserWidth(10);
		measurementSettings.setNrAverages(1);
		measurementSettings.setNrScans(1);
		measurementSettings.setSaturationDetection(1);
		measurementSettings.setSmoothModel(1);
		measurementSettings.setSmoothPix(1);
		measurementSettings.setStartPixel(0);
		measurementSettings.setStopPixel(2048);
		measurementSettings.setStoreToRam(0);
		return measurementSettings;
	}

	@Override
	public int writeConfigToDevice(CMeasurementSettings deviceConfig) {
		return 0;
	}

	@Override
	public boolean isDataAvailable() {
		return true;
	}

	@Override
	public boolean prepareMeasure(CMeasurementSettings settings) {
		return true;
	}

	@Override
	public double[] getWavellength() {
		double[] wavelength = new double[2048];
		for(int i=0;i<wavelength.length;i++) {
			wavelength[i] = i;
		}
		return wavelength;
	}

	@Override
	public double[] getSpectrumData(int[] a_pTimeLabel) {
		a_pTimeLabel = new int[2048];
		double[] data = new double[2048];
		for(int i=0;i<a_pTimeLabel.length;i++) {
			a_pTimeLabel[i] = i;
			data[i] = Math.random();
		}
		return data;
	}

	@Override
	public boolean stopMeasure() {
		return true;
	}

	@Override
	public char[] getSaturatedPixels() {
		char[] saturatedPixels = new char[2048];
		for(int i=0;i<saturatedPixels.length;i++) {
			saturatedPixels[i] = 0;
		}
		return saturatedPixels;
	}
	
	@Override
	public DetectorType getDetectorParams() {
		DetectorType detectorType = new DetectorType();
		detectorType.setSensorType("Dummy");
		detectorType.setNrPixels(2048);
		return detectorType;
	}
	
	@Override
	public String getLastError() {
		return "No error";
	}

	@Override
	public boolean laserOnOff(boolean isOff) {
		if(isOff) {
			isLaserConnected.set(false);
		}else {
			isLaserConnected.set(true);
		}
		return true;
	}

	@Override
	public boolean initializeLaser() {
		return true;
	}

	@Override
	public boolean setLaserPower(int percent) {
		laserPowerPercent = percent;
		return true;
	}

	@Override
	public boolean isLaserConnected() {
		return isLaserConnected.get();
	}

	@Override
	public int getLaserPower() {
		return laserPowerPercent;
	}

	@Override
	public List<String> getDeviceListTest(int nDevices) {
		// TODO Auto-generated method stub
		return null;
	}
}
