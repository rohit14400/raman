package in.gov.barc.drhr.raman.spectaID.view.util;

import javafx.collections.ObservableList;
import javafx.scene.chart.Axis;
import javafx.scene.chart.XYChart.Series;

public class LineXYChartBuilder<X,Y> {
	private Axis<X> xAxis ;
    private Axis<Y> yAxis ;
    private ObservableList<Series<X,Y>> data ;

    public static LineXYChartBuilder<?, ?> create() {
        return new LineXYChartBuilder();
    }

    public LineXYChartBuilder<X, Y> XAxis(Axis<X> xAxis) {
        this.xAxis = xAxis ;
        return this ;
    }

    public LineXYChartBuilder<X, Y> YAxis(Axis<Y> yAxis) {
        this.yAxis = yAxis ;
        return this ;
    }

    public LineXYChartBuilder<X, Y> data(Series<X, Y> series) {
        this.data.add(series);
        return this ;
    }

    public LineXYChart<X, Y> build() {
        if (data == null) {
            return new LineXYChart<X, Y>(xAxis, yAxis);
        } else {
            return new LineXYChart<X, Y>(xAxis, yAxis, data);
        }
    }
}
