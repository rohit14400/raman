package in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Distance;

import in.gov.barc.drhr.raman.spectaID.Preprocessing.Interpolate;
import in.gov.barc.drhr.raman.spectaID.Preprocessing.Normalize;
import in.gov.barc.drhr.raman.spectaID.model.SpectrumData;

public abstract class SpectralDistance {
	protected double xStart = 0.0, xEnd = 0.0;
	protected int startIdx = 0,endIdx = 0;
	protected Interpolate interpolate = new Interpolate();

	abstract public double getDistance(SpectrumData spcUnk, SpectrumData spcLib);

	protected void calculateRange(SpectrumData spcUnkData, SpectrumData spcLibData){
		double xDataUnk[] = spcUnkData.getXData();
		int k=0;
		int i;
		for(i=0;i<xDataUnk.length;i++){
			if(xDataUnk[i] < spcLibData.getxStart()){
				continue;
			}
			if(xDataUnk[i] >= spcLibData.getxEnd()){
				endIdx = i;
				break;
			}
			if(k==0){
				startIdx = i;
			}
			k++;
		}
		endIdx = i;
		xStart = xDataUnk[startIdx];
		xEnd = xDataUnk[endIdx - 1];
	}

	protected double[] normalizeData(SpectrumData spcData){
		Normalize normalize = new Normalize();
		return normalize.normalizeData(spcData.getYData(), spcData.getyMin(), spcData.getyMax());
	}
}
