package in.gov.barc.drhr.raman.spectaID.Preprocessing.Denoising;

public interface IFilter {
	public double[] smooth(double[] data);
}
