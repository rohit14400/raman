package in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Distance;

import java.util.ArrayList;
import java.util.List;

public enum DistanceMetrics {
	ALL("All"),
	EUCLIDEAN("Euclidean"),
	CORRELATION("Correlation"),
	ABSOLUTE_VALUE("Absolute Value"),
	FIRSTDERIVATIVE_CORRELATION("First derivative correlation"),
	LEASTSQUARES("Least Squares"),
	FIRSTDERIVATIVE_LEASTSQUARES("First derivative least squares")
	;
	private final String text;

    private DistanceMetrics(final String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return text;
    }

    public List<String> getDistanceMetrics(){
    	//mind the sequence (same as above)
    	List<String> distMetric = new ArrayList<String>();
    	distMetric.add(EUCLIDEAN.toString());
    	distMetric.add(CORRELATION.toString());
    	distMetric.add(ABSOLUTE_VALUE.toString());
    	distMetric.add(FIRSTDERIVATIVE_CORRELATION.toString());
    	distMetric.add(LEASTSQUARES.toString());
    	distMetric.add(FIRSTDERIVATIVE_LEASTSQUARES.toString());
    	return distMetric;
    }

    public DistanceMetrics getDistanceMetric(int id){
    	switch(id){
    	case 0:
    		return EUCLIDEAN;
    	case 1:
    		return CORRELATION;
    	case 2:
    		return ABSOLUTE_VALUE;
    	case 3:
    		return FIRSTDERIVATIVE_CORRELATION;
    	case 4:
    		return LEASTSQUARES;
    	case 5:
    		return FIRSTDERIVATIVE_LEASTSQUARES;
    	default:
    		return EUCLIDEAN;
    	}
    }
}
