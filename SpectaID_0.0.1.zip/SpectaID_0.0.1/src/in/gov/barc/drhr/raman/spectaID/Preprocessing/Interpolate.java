package in.gov.barc.drhr.raman.spectaID.Preprocessing;

import org.apache.commons.math3.analysis.interpolation.SplineInterpolator;
import org.apache.commons.math3.analysis.polynomials.PolynomialSplineFunction;

public class Interpolate {
	private PolynomialSplineFunction psf;

	public void interpolate(double[] xData,double[] yData){
		//interpolate data
		SplineInterpolator li = new SplineInterpolator();
		psf = li.interpolate(xData,yData);
		xData = null; yData = null;
	}

	public double getValue(double x){
		return psf.value(x);
	}
}
