package in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections;

import java.util.Iterator;
import java.util.List;

import in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Distance.SpectralDistance;
import in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Main.HitSpectrum;
import in.gov.barc.drhr.raman.spectaID.model.Spectrum;
import in.gov.barc.drhr.raman.spectaID.model.SpectrumData;

public class OptimizeCorrectionsThread implements Runnable{
	private List<ICorrection> correctionList;
	private SpectralDistance distance;
	private Spectrum unkSpc;
	private HitSpectrum libSpc;

	public OptimizeCorrectionsThread(List<ICorrection> corrTypes,SpectralDistance spcDistance, Spectrum unkSpc, HitSpectrum libSpc){
		this.correctionList = corrTypes;
		this.distance = spcDistance;
		this.unkSpc = unkSpc;
		this.libSpc = libSpc;
	}

	@Override
	public void run() {
		double hqv = runOptimizationAlgo();
		libSpc.setScore(hqv);
	}

	private double runOptimizationAlgo(){
		double maxHqv = distance.getDistance(unkSpc.getOriginalData(), libSpc.getSpc().getOriginalData());
		if(maxHqv < 30){	//don't process all the records, consider only that have matching over 30
			return maxHqv;
		}
		initializeCorrections();
		double initialHqv = getMaxHQV(unkSpc, libSpc.getSpc());
		if(initialHqv > maxHqv){
			maxHqv = initialHqv;
		}
		double newOptimalHqv = maxHqv + 0.000000002;
		int nIterations = 0;
		while((newOptimalHqv - maxHqv) > 0.000000001 && nIterations <= 5){
			double prevHqv = maxHqv;
			maxHqv = newOptimalHqv;
			Iterator<ICorrection> correctionIt = correctionList.iterator();
			while(correctionIt.hasNext()){
				ICorrection correction = correctionIt.next();
				double oldVal = correction.getCorrectionValue();
				double optimalVal = findOptimalCorrection(correction,unkSpc,libSpc.getSpc());
				correction.setCorrectionValues(optimalVal);
				newOptimalHqv = getMaxHQV(unkSpc, libSpc.getSpc());
				if(newOptimalHqv < prevHqv){
					correction.setCorrectionValues(oldVal);
					newOptimalHqv = prevHqv;
					continue;
				}
				prevHqv = newOptimalHqv;
			}
			nIterations++;
			//System.out.println("Iterations:"+nIterations+" Hqv:"+newOptimalHqv);
		}
	/*	System.out.println("Correction Parameters:First:"+correctionList.get(0).getCorrectionValue()+" Second:"+correctionList.get(1).getCorrectionValue()+
				" Third:"+correctionList.get(2).getCorrectionValue()+" MaxHQV:"+maxHqv); */
		return maxHqv;
	}

	private void initializeCorrections(){
		Iterator<ICorrection> correctionIt = correctionList.iterator();
		while(correctionIt.hasNext()){
			ICorrection correction = correctionIt.next();
			if(correction instanceof VerticalClipping){
				correction.setCorrectionValues(1);
			}else if(correction instanceof HorizontalOffset){
				correction.setCorrectionValues(0);
			}else if(correction instanceof VerticalOffset){
				correction.setCorrectionValues(0);
			}
		}
	}

	private double findOptimalCorrection(ICorrection correction,Spectrum unkSpc,Spectrum libSpc){
		double[] intervalVals = correction.getInitialInterval();
		double maxHqv1 = -10000.0,maxHqv2 = -10000.0;
		double optimalVal = 0;
		double intervalStart = 0,intervalEnd = 0;
		for(int i=0;i < intervalVals.length;i++){
			correction.setCorrectionValues(intervalVals[i]);
			double newHqv = getMaxHQV(unkSpc, libSpc);
			if(newHqv > maxHqv1){
				maxHqv2 = maxHqv1;
				intervalEnd = intervalStart;
				maxHqv1 = newHqv;
				intervalStart = intervalVals[i];
				optimalVal = intervalVals[i];
			}else if(newHqv > maxHqv2){
				maxHqv2 = newHqv;
				intervalEnd = intervalVals[i];
			}
		}
		if(intervalStart > intervalEnd){
			double temp;
			temp = intervalStart;
			intervalStart = intervalEnd;
			intervalEnd = temp;
		}
		double intervalDiff = Math.abs(intervalEnd - intervalStart);
		//run binary algorithm
		while(intervalDiff > 0.00000001 && optimalVal > correction.getMinimumVal()){
			double midVal = (intervalStart + intervalEnd) / 2;
			double[] interval = {(intervalStart + midVal) / 2, midVal, (intervalEnd + midVal) / 2};
			maxHqv1 = maxHqv2 = 0.0;
			for(double d:interval){
				correction.setCorrectionValues(d);
				double newHqv = getMaxHQV(unkSpc, libSpc);
				if(newHqv > maxHqv1){
					maxHqv2 = maxHqv1;
					maxHqv1 = newHqv;
					intervalEnd = intervalStart;
					intervalStart =  d;
					optimalVal = d;
				}else if(newHqv > maxHqv2){
					maxHqv2 = newHqv;
					intervalEnd = d;
				}
			}
			if(intervalStart > intervalEnd){
				double temp;
				temp = intervalStart;
				intervalStart = intervalEnd;
				intervalEnd = temp;
			}
			intervalDiff = Math.abs(intervalEnd - intervalStart);
		}
		intervalVals = null;
		return optimalVal;
	}

	private double getMaxHQV(Spectrum unkSpc,Spectrum libSpc){
		Iterator<ICorrection> correctionIt = correctionList.iterator();
		SpectrumData unkData = new SpectrumData(unkSpc.getCorrectedData());
		SpectrumData libData = new SpectrumData(libSpc.getCorrectedData());
		while(correctionIt.hasNext()){
			ICorrection correction = correctionIt.next();
			correction.applyCorrection(unkData);
			correction.applyCorrection(libData);	//may be applied different corrections
		}
		//four cases of HQV generation
		double hqv[] =new double[3];
		hqv[0] = distance.getDistance(unkData, libSpc.getOriginalData());
		hqv[1] = distance.getDistance(unkSpc.getOriginalData(), libData);
		hqv[2] = distance.getDistance(unkData, libData);
		double maxHqv = -10000.0;
		for(double d:hqv){
			if(d > maxHqv){
				maxHqv = d;
			}
		}
		unkData = null; libData = null;
		return maxHqv;
	}
}
