package in.gov.barc.drhr.raman.spectaID.model.dao;

import java.util.List;

import in.gov.barc.drhr.raman.spectaID.model.Spectrum;

public interface ISpectrumDAO {
	List<Spectrum> getAll();
	List<Spectrum> getByName();
	List<Spectrum> getById();
	boolean insertSpectrum(Spectrum spc);
	boolean updateSpectrum(Spectrum spc);
	boolean removeSpectrum(Spectrum spc);
	boolean batchInsertSpectrum(List<Spectrum> spcList);
}
