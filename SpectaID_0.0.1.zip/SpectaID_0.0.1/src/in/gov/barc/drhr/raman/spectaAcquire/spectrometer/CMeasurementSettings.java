package in.gov.barc.drhr.raman.spectaAcquire.spectrometer;

public class CMeasurementSettings {
	private int m_startPixel, m_stopPixel;
	private double m_integrationTime, m_integrationDelay;
	private int m_nrAverages, m_nrScans;
	private boolean m_trigger_mode, m_trigger_source, m_trigger_sourceType;
	private  int m_saturationDetection;
	private boolean m_corDynDark;
	private int m_forgetPercentage;
	private int m_smoothPix,m_smoothModel;
	private int m_strobeControl;
	private double m_laserDelay;
	private int m_laserWidth;
	private double m_laserWaveLength;
	private int m_storeToRam;
	   
	
	public CMeasurementSettings() {
	
	}
	
	public void setStartPixel(int startPixel)
	{
	    m_startPixel = startPixel;
	}

	public int stopPixel() 
	{
	    return m_stopPixel;
	}

	public void setStopPixel(int stopPixel)
	{
	    m_stopPixel = stopPixel;
	}

	public void setIntegrationTime(double integrationTime){
	    m_integrationTime = integrationTime;
	}

	public double integrationTime() 
	{
	    return m_integrationTime;
	}

	public void setIntegrationDelay(double integrationDelay){
	    m_integrationDelay = integrationDelay;
	}

	public double integrationDelay() 
	{
	    return m_integrationDelay;
	}

	public int nrAverages() 
	{
	    return m_nrAverages;
	}

	public void setNrAverages(int nrAverages)
	{
	    m_nrAverages = nrAverages;
	}

	public boolean trigger_mode() 
	{
	    return m_trigger_mode;
	}

	public void setTrigger_mode(boolean trigger_mode)
	{
	    m_trigger_mode = trigger_mode;
	}

	public boolean trigger_source() 
	{
	    return m_trigger_source;
	}

	public void setTrigger_source(boolean trigger_source)
	{
	    m_trigger_source = trigger_source;
	}

	public boolean trigger_sourceType() 
	{
	    return m_trigger_sourceType;
	}

	public void setTrigger_sourceType(boolean trigger_sourceType)
	{
	    m_trigger_sourceType = trigger_sourceType;
	}

	public int saturationDetection() 
	{
	    return m_saturationDetection;
	}

	public void setSaturationDetection(int saturationDetection)
	{
	    m_saturationDetection = saturationDetection;
	}

	public boolean corDynDark() 
	{
	    return m_corDynDark;
	}

	public void setCorDynDark(boolean corDynDark)
	{
	    m_corDynDark = corDynDark;
	}

	public int forgetPercentage() 
	{
	    return m_forgetPercentage;
	}

	public void setForgetPercentage(int forgetPercentage)
	{
	    m_forgetPercentage = forgetPercentage;
	}

	public int smoothPix() 
	{
	    return m_smoothPix;
	}

	public void setSmoothPix(int smoothPix)
	{
	    m_smoothPix = smoothPix;
	}

	public int smoothModel() 
	{
	    return m_smoothModel;
	}

	public void setSmoothModel(int smoothModel)
	{
	    m_smoothModel = smoothModel;
	}

	public int strobeControl() 
	{
	    return m_strobeControl;
	}

	public double laserDelay() 
	{
	    return m_laserDelay;
	}

	public void setLaserDelay(double laserDelay)
	{
	    m_laserDelay = laserDelay;
	}

	public int laserWidth() 
	{
	    return m_laserWidth;
	}

	public void setLaserWidth(int laserWidth)
	{
	    m_laserWidth = laserWidth;
	}

	public double laserWaveLength() 
	{
	    return m_laserWaveLength;
	}

	public void setLaserWaveLength(double laserWaveLength)
	{
	    m_laserWaveLength = laserWaveLength;
	}

	public int storeToRam() 
	{
	    return m_storeToRam;
	}

	public void setStoreToRam(int storeToRam)
	{
	    m_storeToRam = storeToRam;
	}

	public void setStrobeControl(int strobeControl)
	{
	    m_strobeControl = strobeControl;
	}

	public int nrScans() 
	{
	    return m_nrScans;
	}

	public void setNrScans(int nrScans)
	{
	    m_nrScans = nrScans;
	}

	public int startPixel() 
	{
	    return m_startPixel;
	}
}
