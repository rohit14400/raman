package in.gov.barc.drhr.raman.spectaID.SpectrumSearch.Corrections;

import java.util.ArrayList;
import java.util.List;

public enum CorrectionNames {
	ALL("All"),
	BASELINE("BaseLine"),
	HORIZONTAL_OFFSET("Horizontal Offset"),
	VERTICAL_OFFSET("Vertical Offset"),
	VERTICAL_CLIPPING("Vertical Clipping")
	;
	private final String text;

    private CorrectionNames(final String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return text;
    }

    public List<String> getCorrectionNames(){
    	//mind the sequence (same as above)
    	List<String> corrections = new ArrayList<String>();
    	corrections.add(BASELINE.toString());
    	corrections.add(HORIZONTAL_OFFSET.toString());
    	corrections.add(VERTICAL_OFFSET.toString());
    	corrections.add(VERTICAL_CLIPPING.toString());
    	return corrections;
    }
}
