package in.gov.barc.drhr.raman.spectaID.view.controller;

import java.util.List;

import in.gov.barc.drhr.raman.spectaID.model.SpectraDatabase;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

public class DBOpenController {
	@FXML private ListView<SpectraDatabase> dbList;
	@FXML private Button btnSelect;
	@FXML private Button btnCancel;

	private Stage dialogStage;
	private SpectraDatabase spcDatabase;

	@FXML private void initialize() {
	}

	@FXML public void onBtnClickSelect(){
		spcDatabase = dbList.getSelectionModel().getSelectedItem();
		dialogStage.close();
	}

	@FXML public void onBtnClickCancel(){
		dialogStage.close();
	}

	public SpectraDatabase getSelectedDatabase(){
		return spcDatabase;
	}

	public void setDialogStage(Stage dialoStage){
		this.dialogStage = dialoStage;
	}

	public void setSpectraDatabaseList(List<SpectraDatabase> spcDatabase){
		dbList.getItems().addAll(spcDatabase);
      	if(dbList.getItems().size() == 0){
      		btnSelect.setDisable(true);
      	}else{
      		dbList.getSelectionModel().selectFirst();
      	}
	}
}
